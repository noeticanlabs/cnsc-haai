# run_scaled_multi_module_sim.py
from modules_scaled.thermo_module_scaled import PhysicsModule as Thermo
from modules_scaled.fluid_module_scaled import PhysicsModule as Fluid
from modules_scaled.em_module_scaled import PhysicsModule as EM
from modules_scaled.quantum_module_scaled import PhysicsModule as Quantum
from modules_scaled.plasma_module_scaled import PhysicsModule as Plasma
from modules_scaled.acoustic_module_scaled import PhysicsModule as Acoustic

from phasedrive_module import PhaseDrive
from fusion_config import cfg
from multi_field_analytics import MultiFieldAnalytics
import numpy as np

def run_scaled_simulation(steps=100):
    print("⚙️ Initializing PhaseDrive...")
    drive = PhaseDrive(cfg)

    print("🧪 Initializing scaled physics modules...")
    thermo = Thermo(cfg)
    fluid = Fluid(cfg)
    em = EM(cfg)
    quantum = Quantum(cfg)
    plasma = Plasma(cfg)
    acoustic = Acoustic(cfg)

    print("📊 Starting analytics engine...")
    analyzer = MultiFieldAnalytics()

    for step in range(steps):
        control = drive.update(thermo.fields)

        thermo_field = thermo.step(thermo.fields, control)
        fluid_field = fluid.step(fluid.fields, control)
        em_field = em.step(em.fields, control)
        quantum_field = quantum.step(quantum.fields, control)
        plasma_field = plasma.step(plasma.fields, control)
        acoustic_field = acoustic.step(acoustic.fields, control)

        fields = {
            "thermo": thermo_field,
            "fluid": fluid_field,
            "em": em_field,
            "quantum": quantum_field,
            "plasma": plasma_field,
            "acoustic": acoustic_field
        }

        metrics = analyzer.compute_metrics(fields, control["theta"], step)

        if step % 10 == 0:
            print(f"Step {step}: θ = {metrics['theta']:.6e}")
            for key in fields:
                print(f"  → {key} norm: {metrics[key]['norm']:.4f}, coherence: {metrics[key]['coherence']}")

    print("✅ Scaled simulation complete.")
    return analyzer.summary()

if __name__ == "__main__":
    run_scaled_simulation()
