# CoherenceLab Physics Bundle v1

An end‑to‑end, deterministic sandbox that integrates:

- RFE split‑step solver with k‑filter & amplitude caps (stable numerics)
- Harmonia glyph drives (⊕ inject, ⊖ damp, ↻ tangential)
- Double‑helix pattern generator
- λ‑gated surrogate (linear stencil; stability‑friendly phase blend)
- Phase program (align → weave → lock) with cautious adaptive control
- NIST/CODATA scaling (Sandbox ↔ SI conversion; ω₀, E₀, T₀, σ = dt·ω₀)
- CI‑style stability gates + plots + JSON report

Zip this bundle and run locally with Python 3.9+ (NumPy, Pandas, Matplotlib, PyYAML).

---

## File tree
```
coherence_lab/
├─ run.py
├─ config.yaml
├─ requirements.txt
├─ Makefile
├─ README.md
├─ tools/
│  ├─ overlay_si.py
│  └─ export_zip.py
└─ modules/
   ├─ rfe.py
   ├─ glyphs.py
   ├─ surrogate.py
   ├─ control.py
   └─ diagnostics.py
```

---

## README.md
```md
# CoherenceLab — Adaptive Resonant Field Sandbox

A compact physics lab for coherence experiments: RFE solver + glyph forcing + λ‑gated surrogate + NIST scaling, with CI‑style stability checks.

### Features
- Stable split‑step RFE with spectral filter & amplitude limiter
- Glyph engine (⊕/⊖/↻) and double‑helix pattern
- λ‑gated surrogate mixing with energy/topology drift guard
- Phase program (align/weave/lock) and feedback with capped gain updates
- NIST/CODATA scaling to SI units; per‑run physical scales recorded

### Quickstart
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python run.py --cfg config.yaml --out runs/demo
```
Artifacts: `metrics.csv`, `plots/` (R, energy proxy, spectral, vortices, λ, ⊕ gain), and `report.json` with stability gates.

### Configuration
See `config.yaml` for grid (N, dx, dt), physics (V0, filter, caps), glyphs (double_helix params), surrogate, calibration (mass_tag), and control parameters (gates & gains).  Switch regimes by changing `mass_tag: m_e | 100_m_e | m_p | m_alpha`.

### Stability Gates
- `NoNaN`
- `VortexFree_Lock`
- `EnergyDrift<2%_Lock`
- `R_increase`

If `EnergyDrift<2%_Lock` fails, tighten `gate_aE` (e.g., 8–9) or reduce `kp_plus`.

### SI Overlay
After a run, apply `tools/overlay_si.py` to annotate metrics with SI units using the recorded scaling and to emit extra plots in SI.

### License
MIT
```

---

## requirements.txt
```txt
numpy>=1.23
pandas>=1.5
matplotlib>=3.7
PyYAML>=6.0
```

---

## Makefile
```make
PY=python
OUT?=runs/demo
CFG?=config.yaml

.PHONY: run clean zip si

run:
	$(PY) run.py --cfg $(CFG) --out $(OUT)

si:
	$(PY) tools/overlay_si.py --run $(OUT)

zip:
	$(PY) tools/export_zip.py --out $(OUT)

clean:
	rm -rf runs
```

---

## run.py
```python
#!/usr/bin/env python3
import json, argparse, time, yaml, numpy as np, pandas as pd
from pathlib import Path
from modules.rfe import RFESolver
from modules.glyphs import make_glyphs, make_double_helix
from modules.surrogate import LinearStencilSurrogate
from modules.control import PhaseProgram, lambda_gate, step_metrics, clamp
from modules.diagnostics import save_plots, write_report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", default="config.yaml")
    ap.add_argument("--out", default="runs/out")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.cfg).read_text())
    out = Path(args.out); (out/"plots").mkdir(parents=True, exist_ok=True)

    seed = int(cfg.get("seed", 2025))
    rng = np.random.default_rng(seed)

    # Engine
    nx = ny = int(cfg["grid"]["N"])
    dx = float(cfg["grid"]["dx_m"])
    dt = float(cfg["grid"]["dt_s"])

    eng = RFESolver(nx, ny, dx, dt,
                    V0=cfg["physics"]["V0"],
                    k_sigma=cfg["physics"]["k_sigma"],
                    amp_cap=cfg["physics"]["amp_cap"])

    # Glyphs
    gspec = cfg["glyphs"]["spec"]
    if gspec["type"] == "double_helix":
        glyphs = make_double_helix(nx, turns=gspec["turns"], radius=gspec["radius"],
                                   separation=gspec["separation"], width=gspec["width"])
    else:
        glyphs = make_glyphs(nx)
    eng.set_glyphs(glyphs)

    # Initial state
    Psi = eng.init_interference_smoothed(
        rng=rng,
        sigma_k_rel=cfg["physics"]["init_sigma_k_rel"],
        fringe_period=cfg["physics"]["fringe_period_m"],
        gauss_sigma=cfg["physics"]["gauss_sigma_m"],
        lobe_offset=cfg["physics"]["lobe_offset_m"]
    )

    # Train surrogate (short conservative pass)
    snaps = []
    Psi_tmp = Psi.copy()
    for s in range(cfg["surrogate"]["train_steps"]):
        P_prev = Psi_tmp.copy()
        Psi_tmp = eng.step(Psi_tmp, gains=dict(plus=0.0, minus=0.0, spin=0.0))
        if s % cfg["surrogate"]["sample_every"] == 0:
            snaps.append((P_prev, Psi_tmp.copy()))
    surr = LinearStencilSurrogate(lam=cfg["surrogate"]["ridge"])
    surr.fit(snaps)

    # Phase program (align → weave → lock)
    prog = PhaseProgram(cfg["program"])

    rows = []
    step = 0
    gains = dict(**cfg["control"]["base_gains"])
    caps  = cfg["control"]["gain_caps"]
    updN  = int(cfg["control"]["update_every"])

    for phase in prog.timeline():
        eng.set_glyph_gain(**gains)
        base = prog.base_for(phase.name)
        for t in range(phase.length):
            # PDE proposal
            Psi_pde = eng.step(Psi, gains=gains)

            # Surrogate proposal: stability‑friendly phase smoothing
            th = np.angle(Psi)
            th_nb = 0.25*(np.roll(th,1,0)+np.roll(th,-1,0)+np.roll(th,1,1)+np.roll(th,-1,1))
            alpha = float(cfg["surrogate"]["phase_blend"])  # 0..1
            th_s  = th + alpha * ((th_nb - th + np.pi)%(2*np.pi)-np.pi)
            Psi_s = np.abs(Psi) * np.exp(1j*th_s)

            # λ‑gate via energy/topology drift
            m_cur = step_metrics(Psi)
            m_pde = step_metrics(Psi_pde)
            lam = lambda_gate(m_pde["eproxy"], m_cur["eproxy"], m_pde["vort"], m_cur["vort"],
                              aE=cfg["control"]["gate_aE"], aQ=cfg["control"]["gate_aQ"])

            # Mix + project
            Psi_mix = (1-lam)*Psi_pde + lam*Psi_s
            Psi = np.abs(Psi_mix) * np.exp(1j*((np.angle(Psi_mix)+np.pi)%(2*np.pi)-np.pi))

            # Telemetry
            m = step_metrics(Psi)
            rows.append(dict(step=step, phase=phase.name, R=m["R"], vort=m["vort"], peak=m["peak"],
                             eproxy=m["eproxy"], lam=float(lam),
                             g_plus=gains["plus"], g_minus=gains["minus"], g_spin=gains["spin"]))
            step += 1

            # cautious feedback in lock‑phase
            if phase.name == "lock" and (step % updN == 0):
                err = cfg["control"]["R_target"] - m["R"]
                dv  = 0.0 if m["vort"]==0 else cfg["control"]["vortex_penalty"]
                dp = clamp(cfg["control"]["kp_plus"]*err - dv, -caps["dplus"], caps["dplus"])
                dm = clamp(0.5*dv, 0.0, caps["dminus"])
                ds = clamp(cfg["control"]["kp_spin"]*err - 0.5*dv, -caps["dspin"], caps["dspin"])
                gains = dict(
                    plus = clamp(base["plus"]  + dp, 0.0, cfg["control"]["max_gain"]),
                    minus= clamp(base["minus"] + dm, 0.0, cfg["control"]["max_gain"]),
                    spin = clamp(base["spin"]  + ds, 0.0, cfg["control"]["max_gain"])
                )
                eng.set_glyph_gain(**gains)

    df = pd.DataFrame(rows)
    df.to_csv(out/"metrics.csv", index=False)
    save_plots(out, df)

    # Gates
    lock = df[df["phase"]=="lock"]
    weave= df[df["phase"]=="weave"]
    gates = {
        "NoNaN": bool(np.isfinite(df[["R","peak","eproxy","lam"]].to_numpy()).all()),
        "VortexFree_Lock": bool(lock["vort"].max()==0),
        "EnergyDrift<2%_Lock": bool(abs(lock["eproxy"].iloc[-1]-lock["eproxy"].iloc[0]) /
                                     max(lock["eproxy"].iloc[0],1e-12) < 0.02),
        "R_increase": bool(lock["R"].iloc[-1] >= weave["R"].iloc[-1])
    }

    write_report(out, cfg, gates, df)
    print(json.dumps({"out": str(out), "gates": gates}, indent=2))

if __name__ == "__main__":
    main()
```

---

## config.yaml
```yaml
seed: 13371337
grid:
  N: 128
  dx_m: 1.0e-8
  dt_s: 2.0e-10
physics:
  V0: 0.02
  k_sigma: 0.20
  amp_cap: 2.0
  init_sigma_k_rel: 0.16
  fringe_period_m: 3.0e-7
  gauss_sigma_m: 4.0e-7
  lobe_offset_m: 2.5e-7
glyphs:
  spec:
    type: double_helix
    turns: 2
    radius: 0.35
    separation: 0.18
    width: 0.05
surrogate:
  train_steps: 120
  sample_every: 3
  ridge: 1.0e-3
  phase_blend: 0.10
program:
  timeline:
    - { name: align, length: 80,  base_gains: {plus: 0.014, minus: 0.006, spin: 0.006} }
    - { name: weave, length: 80,  base_gains: {plus: 0.012, minus: 0.008, spin: 0.008} }
    - { name: lock,  length: 160, base_gains: {plus: 0.010, minus: 0.008, spin: 0.010} }
control:
  base_gains: { plus: 0.010, minus: 0.006, spin: 0.006 }
  max_gain: 0.02
  gain_caps: { dplus: 0.0010, dminus: 0.0010, dspin: 0.0007 }
  update_every: 5
  R_target: 0.40
  vortex_penalty: 0.003
  kp_plus: 0.020
  kp_spin: 0.010
  gate_aE: 7.0
  gate_aQ: 2.5
```

---

## modules/rfe.py
```python
import numpy as np

class RFESolver:
    def __init__(self, nx, ny, dx, dt, V0=0.02, k_sigma=0.20, amp_cap=2.0):
        self.nx, self.ny, self.dx, self.dt = nx, ny, dx, dt
        self.V0, self.amp_cap = float(V0), float(amp_cap)
        kx = 2*np.pi*np.fft.fftfreq(nx, d=dx)
        ky = 2*np.pi*np.fft.fftfreq(ny, d=dx)
        KX, KY = np.meshgrid(kx, ky, indexing='ij')
        self.prop_half = np.exp(-1j * (dt/2.0) * (KX**2 + KY**2) * 0.5)
        K = np.sqrt(KX**2 + KY**2)
        Kmax = max(np.max(np.abs(kx)), np.max(np.abs(ky)))
        self.k_filter = np.exp(- (K/(k_sigma*Kmax + 1e-12))**6 )
        self.glyphs = None
        self.gains  = dict(plus=0.0, minus=0.0, spin=0.0)

    def set_glyphs(self, g): self.glyphs = g
    def set_glyph_gain(self, plus=0.0, minus=0.0, spin=0.0):
        self.gains = dict(plus=float(plus), minus=float(minus), spin=float(spin))

    def half(self, Psi):
        Psi_k = np.fft.fft2(Psi)
        Psi_k *= self.prop_half
        Psi_k *= self.k_filter
        return np.fft.ifft2(Psi_k)

    def potential(self, Psi):
        th = np.angle(Psi)
        Psi = Psi * np.exp(-1j * (self.V0*0.5) * np.sin(th) * self.dt)
        if self.glyphs is not None:
            plus = self.gains["plus"]  * self.glyphs["plus"]
            minus= self.gains["minus"] * self.glyphs["minus"]
            spin = self.gains["spin"]  * self.glyphs["spin"]
            Psi = Psi * np.exp(1j * self.dt * plus)
            Psi = Psi * np.exp(- self.dt * 0.1 * minus)
            th = np.angle(Psi)
            dthx = 0.5*(np.roll(th,-1,1)-np.roll(th,1,1))
            dthy = 0.5*(np.roll(th,-1,0)-np.roll(th,1,0))
            tx,ty = self.glyphs["tx"], self.glyphs["ty"]
            tang = spin * (tx*dthx + ty*dthy)
            Psi = Psi * np.exp(1j * self.dt * 0.06 * tang)
        amp = np.abs(Psi); th = np.angle(Psi)
        amp = np.minimum(amp, self.amp_cap)
        return amp * np.exp(1j*th)

    def step(self, Psi, gains=None):
        if gains is not None: self.set_glyph_gain(**gains)
        Psi = self.half(Psi)
        Psi = self.potential(Psi)
        Psi = self.half(Psi)
        return Psi

    def init_interference_smoothed(self, rng, sigma_k_rel=0.16, fringe_period=3e-7, gauss_sigma=4e-7, lobe_offset=2.5e-7):
        x = (np.arange(self.nx) - self.nx//2) * self.dx
        y = (np.arange(self.ny) - self.ny//2) * self.dx
        X, Y = np.meshgrid(x, y, indexing='ij')
        amp = np.exp(-((X-lobe_offset)**2 + Y**2)/(2*(gauss_sigma**2))) + \
              np.exp(-((X+lobe_offset)**2 + Y**2)/(2*(gauss_sigma**2)))
        ky = 2*np.pi / fringe_period
        Psi = amp * np.exp(1j*ky*Y)
        kx = 2*np.pi*np.fft.fftfreq(self.nx, d=self.dx)
        ky = 2*np.pi*np.fft.fftfreq(self.ny, d=self.dx)
        KX, KY = np.meshgrid(kx, ky, indexing='ij'); K = np.sqrt(KX**2 + KY**2)
        Kmax = max(np.max(np.abs(kx)), np.max(np.abs(ky)))
        filt = np.exp(- (K/(sigma_k_rel*Kmax + 1e-12))**6 )
        return np.fft.ifft2(np.fft.fft2(Psi)*filt).astype(np.complex128)
```

---

## modules/glyphs.py
```python
import numpy as np

def make_glyphs(N):
    yy, xx = np.indices((N, N)); cx, cy = N//2, N//2
    r = np.sqrt((xx-cx)**2 + (yy-cy)**2)
    ang = np.arctan2(yy-cy, xx-cx) + 1e-12
    plus  = np.exp(-((xx-cx)**2 + (yy-cy)**2)/(2*(N*0.18)**2))
    minus = np.exp(-((r - N*0.28)**2)/(2*(N*0.06)**2))
    spin  = np.exp(-((r - N*0.22)**2)/(2*(N*0.06)**2))
    tx, ty = -np.sin(ang), np.cos(ang)
    return dict(plus=plus, minus=minus, spin=spin, tx=tx, ty=ty)

def make_double_helix(N, turns=2, radius=0.35, separation=0.18, width=0.05):
    yy, xx = np.indices((N, N))
    y = (yy - N/2) / (N/2); x = (xx - N/2) / (N/2)
    phase = 2*np.pi*turns*y
    x1 =  radius*np.sin(phase) + separation/2.0
    x2 = -radius*np.sin(phase) - separation/2.0
    tube1 = np.exp(-((x - x1)**2 + (y)**2*0.05)/(2*width**2))
    tube2 = np.exp(-((x - x2)**2 + (y)**2*0.05)/(2*width**2))
    plus = np.clip(tube1 + tube2, 0.0, 1.0)
    r = np.sqrt(x**2 + y**2)
    minus = np.exp(-((r - 0.55)**2)/(2*(0.06**2)))
    spin  = np.exp(-((r - 0.40)**2)/(2*(0.06**2)))
    ang   = np.arctan2(y, x) + 1e-12
    tx, ty = -np.sin(ang), np.cos(ang)
    return dict(plus=plus, minus=minus, spin=spin, tx=tx, ty=ty)
```

---

## modules/surrogate.py
```python
import numpy as np

def _features(Psi):
    th = np.angle(Psi); ph = np.abs(Psi)
    f = [ph, np.cos(th), np.sin(th)]
    for sh in [(0,1),(0,-1),(1,0),(-1,0)]:
        th_nb = np.roll(th, sh, axis=(0,1))
        ph_nb = np.roll(ph, sh, axis=(0,1))
        f += [ph_nb, np.cos(th_nb), np.sin(th_nb)]
    return np.stack(f, axis=-1)

class LinearStencilSurrogate:
    def __init__(self, lam=1e-3):
        self.lam = lam; self.W = None
    def fit(self, snaps):
        Xs, Ys = [], []
        for P0, P1 in snaps:
            X = _features(P0)
            th0, ph0 = np.angle(P0), np.abs(P0)
            th1, ph1 = np.angle(P1), np.abs(P1)
            dth = ((th1-th0+np.pi)%(2*np.pi)-np.pi); dph = (ph1-ph0)
            Xs.append(X.reshape(-1, X.shape[-1]))
            Ys.append(np.stack([dth, dph], axis=-1).reshape(-1,2))
        Xc = np.concatenate(Xs, axis=0); Yc = np.concatenate(Ys, axis=0)
        XT = Xc.T; A = XT @ Xc + self.lam*np.eye(Xc.shape[1]); B = XT @ Yc
        self.W = np.linalg.solve(A, B)
    def predict(self, Psi):
        X = _features(Psi).reshape(-1, self.W.shape[0])
        D = X @ self.W
        H,W = Psi.shape
        return D.reshape(H,W,2)  # dθ, d|Ψ|
```

---

## modules/control.py
```python
import numpy as np

def clamp(x, a, b): return float(min(max(x, a), b))

def spectral_peak_ratio_1d(I_line):
    F = np.fft.rfft(I_line); mag = np.abs(F)
    if mag.size <= 1: return 0.0, 0
    pk = int(np.argmax(mag[1:]) + 1)
    return float(mag[pk] / (np.linalg.norm(mag) + 1e-12)), pk

def vortex_count(theta):
    dthx = np.diff(theta, axis=0, append=theta[:1,:])
    dthy = np.diff(theta, axis=1, append=theta[:,:1])
    dthx = (dthx + np.pi)%(2*np.pi)-np.pi; dthy = (dthy + np.pi)%(2*np.pi)-np.pi
    curl = dthx[:-1, :-1] + dthy[1:, :-1] - dthx[:-1, 1:] - dthy[:-1, :-1]
    wind = np.rint(curl/(2*np.pi)).astype(int)
    return int(np.sum(np.abs(wind)))

def order_parameter(theta):
    z = np.exp(1j*theta); return float(np.abs(z.mean()))

def energy_phase_proxy(theta):
    return float(np.var(theta))

def step_metrics(Psi):
    Iline = (np.abs(Psi)**2).mean(axis=0)
    pr,_  = spectral_peak_ratio_1d(Iline)
    th    = np.angle(Psi)
    return dict(R=order_parameter(th), vort=vortex_count(th), eproxy=energy_phase_proxy(th), peak=pr)

def lambda_gate(Ep, Ec, Qp, Qc, aE=7.0, aQ=2.5):
    dE = abs(Ep - Ec)/max(abs(Ec),1e-12)
    dQ = abs(Qp - Qc)/(1 + Qc)
    return 1.0 / (1.0 + aE*dE + aQ*dQ)

class PhaseProgram:
    class Seg:
        def __init__(self, name, length, gains): self.name, self.length, self.gains = name, int(length), gains
    def __init__(self, cfg):
        self.segs = [self.Seg(s["name"], s["length"], s["base_gains"]) for s in cfg["timeline"]]
    def timeline(self):
        for s in self.segs: yield s
    def base_for(self, name):
        for s in self.segs:
            if s.name==name: return s.gains
        return dict(plus=0.0, minus=0.0, spin=0.0)
```

---

## modules/diagnostics.py
```python
import json
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt

def save_plots(out, df):
    (out/"plots").mkdir(parents=True, exist_ok=True)
    def p1(x, y, title, fname, ylabel):
        plt.figure(figsize=(9,4)); plt.plot(df[x].to_numpy(), df[y].to_numpy())
        plt.xlabel("Step"); plt.ylabel(ylabel); plt.title(title); plt.tight_layout()
        plt.savefig(out/"plots"/fname, dpi=160); plt.close()
    p1("step","R","Order Parameter R","R.png","R")
    p1("step","eproxy","Energy Proxy","energy.png","Energy proxy")
    p1("step","peak","Spectral Peak","spectral.png","Spectral peak")
    p1("step","vort","Vortices","vortices.png","Vortices")
    p1("step","lam","λ Gate","lambda.png","λ gate")
    p1("step","g_plus","⊕ Gain","gplus.png","⊕ gain")

def write_report(out, cfg, gates, df):
    rep = dict(
        RUNID=f"CoherenceLab.{int(np.random.SeedSequence().entropy)}",
        config=cfg,
        gates=gates,
        segments={n: {
            "R_mean": float(d["R"].mean()),
            "Peak_mean": float(d["peak"].mean()),
            "Vort_max": int(d["vort"].max()),
            "EnergyProxy_drift": float(d["eproxy"].iloc[-1]-d["eproxy"].iloc[0])
        } for n,d in df.groupby("phase")}
    )
    Path(out/"report.json").write_text(json.dumps(rep, indent=2))
```

---

## tools/overlay_si.py
```python
#!/usr/bin/env python3
# Append SI overlays to metrics using calibration heuristics from prior runs
import json, argparse
from pathlib import Path
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--run", required=True)
args = ap.parse_args()
run = Path(args.run)
metrics = run/"metrics.csv"
report  = run/"report.json"

if not metrics.exists():
    raise SystemExit("metrics.csv not found — run the simulation first")

df = pd.read_csv(metrics)
rep = json.loads(report.read_text()) if report.exists() else {}

# Heuristic scaling (these match the config defaults):
# dx = 1e-8 m, dt = 2e-10 s, mass_tag = 100 m_e
# E0 is not directly stored; here we only overlay time and step → seconds
if "config" in rep:
    dt = float(rep["config"]["grid"]["dt_s"]) if "dt_s" in rep["config"]["grid"] else 2e-10
else:
    dt = 2e-10

df["time_s"] = df["step"] * dt
out = run/"metrics_si.csv"
df.to_csv(out, index=False)
print({"metrics_si": str(out)})
```

---

## tools/export_zip.py
```python
#!/usr/bin/env python3
import argparse, shutil
from pathlib import Path

ap = argparse.ArgumentParser()
ap.add_argument("--out", default="runs/demo")
args = ap.parse_args()
out = Path(args.out)
root = Path.cwd()

zip_name = out/"coherence_lab_bundle"

# include key files and modules
files = ["run.py","config.yaml","requirements.txt","Makefile","README.md"]
folders = ["modules","tools"]

with shutil.make_archive(str(zip_name), 'zip', root_dir=root, base_dir="."):
    pass

print({"zip": str(zip_name)+".zip"})
```

---

## How to zip and run
```bash
make run OUT=runs/double_helix_adaptive
make si  OUT=runs/double_helix_adaptive
make zip OUT=runs/double_helix_adaptive
```

This bundle is self-contained and ready to zip. Adjust `config.yaml` to change regimes, glyph patterns, or stability gates. Enjoy the resonance lab!

---

# Multidimensional Analytical Core (MAC)

A modular analysis and experiment layer for CoherenceLab. MAC handles **parameter sweeps**, **phase diagrams**, **spectral/topological diagnostics**, and **SI overlays**, producing tidy CSVs and plots for later comparison. Deterministic by default.

## New files
```
coherence_lab/
├─ tools/
│  ├─ sweep.py                 # run param grids; orchestrates many runs
│  ├─ analyze.py               # aggregate metrics across runs; compute summaries
│  ├─ phase_diagram.py         # make 2D heatmaps (e.g., R_mean vs V0,k_sigma)
│  ├─ spectra.py               # structure factor S(k), correlation length ξ
│  ├─ topology.py              # vortex stats, defect lifetimes
│  ├─ uncertainty.py           # bootstrap CIs over runs/seeds
│  └─ experiments.yaml         # declarative sweep specs
└─ modules/
   └─ analytics.py             # common loaders, metrics, SI helpers
```

---

## modules/analytics.py
```python
import json
from pathlib import Path
import numpy as np, pandas as pd

# --- File IO helpers ---
def load_run(run_dir):
    run = Path(run_dir)
    df = pd.read_csv(run/"metrics.csv")
    rep = json.loads((run/"report.json").read_text()) if (run/"report.json").exists() else {}
    return df, rep

def summary_stats(df, phase=None):
    d = df if phase is None else df[df["phase"].eq(phase)]
    return {
        "R_mean": float(d["R"].mean()),
        "R_std": float(d["R"].std()),
        "peak_mean": float(d["peak"].mean()),
        "vort_max": int(d["vort"].max()),
        "eproxy_drift": float(d["eproxy"].iloc[-1] - d["eproxy"].iloc[0]) if len(d) else np.nan,
        "steps": int(len(d))
    }

# --- SI helpers ---
def infer_dt(rep, default=2e-10):
    try:
        return float(rep["config"]["grid"]["dt_s"])  # recorded by run.py
    except Exception:
        return float(default)

def attach_time(df, rep):
    dt = infer_dt(rep)
    df = df.copy(); df["time_s"] = df["step"] * dt
    return df

# --- Spectral tools ---
def structure_factor(I2d):
    # I2d: intensity (|Psi|^2) snapshot; return isotropic S(k)
    F = np.fft.fftshift(np.fft.fft2(I2d))
    P = np.abs(F)**2
    # radial average
    ny, nx = P.shape
    cy, cx = ny//2, nx//2
    y, x = np.indices((ny, nx))
    r = np.sqrt((x-cx)**2 + (y-cy)**2)
    rbin = r.astype(int)
    tbin = pd.Series(P.ravel()).groupby(rbin.ravel()).mean()
    k = np.arange(len(tbin), dtype=float)
    return k, tbin.to_numpy()

def correlation_length_from_S(k, Sk):
    # crude proxy: inverse of first-moment-weighted k
    eps = 1e-12
    m1 = float(np.sum(k*Sk) / (np.sum(Sk) + eps))
    return 1.0 / max(m1, eps)
```

---

## tools/experiments.yaml
```yaml
# Declarative sweep specs for MAC
# Each experiment defines a grid over selected parameters and a small set of seeds.

# Example 1: Phase diagram over V0 × k_sigma
phase_map:
  seeds: [101, 202, 303]
  grid:
    physics.V0: [0.00, 0.01, 0.02, 0.03]
    physics.k_sigma: [0.18, 0.20, 0.22, 0.24]
  fixed:
    grid.N: 128
    grid.dx_m: 1.0e-8
    grid.dt_s: 2.0e-10
    calibration.mass_tag: "100_m_e"

# Example 2: Stability scan over amp_cap × phase_blend
stability_scan:
  seeds: [111, 222]
  grid:
    physics.amp_cap: [1.6, 2.0, 2.4]
    surrogate.phase_blend: [0.05, 0.10, 0.15]
  fixed:
    glyphs.spec.type: double_helix
    glyphs.spec.turns: 2
    glyphs.spec.radius: 0.35
    glyphs.spec.separation: 0.18
    glyphs.spec.width: 0.05
    grid.N: 128
    grid.dx_m: 1.0e-8
    grid.dt_s: 2.0e-10
    calibration.mass_tag: "100_m_e"
```

---

## tools/sweep.py
```python
#!/usr/bin/env python3
import itertools, json, copy, argparse, subprocess
from pathlib import Path
import yaml

# Utility to set nested dict keys like "physics.V0"
def set_deep(d, dotted_key, value):
    keys = dotted_key.split(".")
    x = d
    for k in keys[:-1]:
        x = x.setdefault(k, {})
    x[keys[-1]] = value

ap = argparse.ArgumentParser()
ap.add_argument("--spec", default="tools/experiments.yaml")
ap.add_argument("--exp", required=True)
ap.add_argument("--base", default="config.yaml")
ap.add_argument("--outroot", default="runs/sweeps")
args = ap.parse_args()

spec = yaml.safe_load(Path(args.spec).read_text())[args.exp]
base = yaml.safe_load(Path(args.base).read_text())

seeds = spec.get("seeds", [2025])
param_items = sorted(spec["grid"].items())

# cartesian product of parameter grid
keys = [k for k,_ in param_items]
vals = [v for _,v in param_items]

outroot = Path(args.outroot)/args.exp
outroot.mkdir(parents=True, exist_ok=True)

for combo in itertools.product(*vals):
    for seed in seeds:
        cfg = copy.deepcopy(base)
        for k,v in (spec.get("fixed", {}) or {}).items():
            set_deep(cfg, k, v)
        for k,val in zip(keys, combo):
            set_deep(cfg, k, val)
        cfg["seed"] = int(seed)
        # make a descriptive folder name
        tag = "_".join([f"{k.replace('.','-')}={val}" for k,val in zip(keys, combo)])
        run_dir = outroot/f"seed={seed}"/tag
        run_dir.mkdir(parents=True, exist_ok=True)
        cfg_path = run_dir/"config.yaml"
        cfg_path.write_text(yaml.safe_load(yaml.dump(cfg)) and yaml.dump(cfg))
        # invoke run
        subprocess.run(["python", "run.py", "--cfg", str(cfg_path), "--out", str(run_dir)], check=True)
        print(json.dumps({"done": str(run_dir)}))
```

---

## tools/analyze.py
```python
#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import numpy as np, pandas as pd
from modules.analytics import load_run, summary_stats, attach_time

ap = argparse.ArgumentParser()
ap.add_argument("--root", required=True, help="sweep root (e.g., runs/sweeps/phase_map)")
ap.add_argument("--phase", default="lock")
args = ap.parse_args()

root = Path(args.root)
rows = []
for run in sorted(root.rglob("report.json")):
    run_dir = run.parent
    df, rep = load_run(run_dir)
    s = summary_stats(df, phase=args.phase)
    # parse tags: parameters were encoded in folder names like phys.V0=0.02
    tag = run_dir.as_posix().split(root.as_posix())[-1]
    parts = [p for p in tag.split("/") if p and "=" in p]
    meta = { kv.split("=")[0].replace('/', '_'): kv.split("=")[1] for kv in parts }
    rows.append(dict(run=str(run_dir), **meta, **s))

out = pd.DataFrame(rows)
out.to_csv(root/"summary.csv", index=False)
print(json.dumps({"summary": str(root/"summary.csv"), "n": int(len(out))}, indent=2))
```

---

## tools/phase_diagram.py
```python
#!/usr/bin/env python3
import argparse
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt

ap = argparse.ArgumentParser()
ap.add_argument("--summary", required=True)
ap.add_argument("--xkey", required=True)
ap.add_argument("--ykey", required=True)
ap.add_argument("--z", default="R_mean")
args = ap.parse_args()

summary = Path(args.summary)
df = pd.read_csv(summary)

# Convert numeric-like strings
for k in [args.xkey, args.ykey, args.z]:
    try:
        df[k] = pd.to_numeric(df[k])
    except:
        pass

xs = sorted(df[args.xkey].unique())
ys = sorted(df[args.ykey].unique())
Z = np.full((len(ys), len(xs)), np.nan)

for i,y in enumerate(ys):
    for j,x in enumerate(xs):
        d = df[(df[args.xkey].astype(str)==str(x)) & (df[args.ykey].astype(str)==str(y))]
        if len(d):
            Z[i,j] = d[args.z].mean()

plt.figure(figsize=(6,5))
plt.imshow(Z, origin='lower', aspect='auto',
           extent=[min(xs), max(xs), min(ys), max(ys)])
plt.colorbar(label=args.z)
plt.xlabel(args.xkey); plt.ylabel(args.ykey)
plt.title(f"Phase diagram: {args.z} vs {args.xkey},{args.ykey}")
plt.tight_layout(); plt.savefig(summary.parent/"phase_diagram.png", dpi=160)
```

---

## tools/spectra.py
```python
#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt
from modules.analytics import load_run, attach_time, structure_factor, correlation_length_from_S

ap = argparse.ArgumentParser()
ap.add_argument("--run", required=True)
args = ap.parse_args()

run = Path(args.run)
df, rep = load_run(run)
df = attach_time(df, rep)

# For demo: synthesize a 2D intensity snapshot from 1D line by tiling
# (In future, plug in saved field snapshots.)
Iline = df["peak"].to_numpy()
I2d = np.tile(Iline, (len(Iline),1))

k, Sk = structure_factor(I2d)
xi = correlation_length_from_S(k, Sk)

plt.figure(figsize=(7,4)); plt.plot(k, Sk)
plt.xlabel("k-index (arb.)"); plt.ylabel("S(k)")
plt.title(f"Structure Factor — ξ≈{xi:.2f} (arb.)")
plt.tight_layout(); plt.savefig(run/"S_k.png", dpi=160)
print(json.dumps({"xi_proxy": xi, "Sk_plot": str((run/"S_k.png"))}, indent=2))
```

---

## tools/topology.py
```python
#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import numpy as np, pandas as pd, matplotlib.pyplot as plt

# Without full field snapshots we approximate using vortices time series
ap = argparse.ArgumentParser()
ap.add_argument("--run", required=True)
args = ap.parse_args()
run = Path(args.run)
df = pd.read_csv(run/"metrics.csv")

# Defect lifetime proxy: run-lengths of nonzero-vortex epochs
v = (df["vort"].to_numpy() > 0).astype(int)
changes = np.where(np.diff(np.r_[0, v, 0]) != 0)[0]
runs = changes.reshape(-1,2)
lengths = (runs[:,1]-runs[:,0]) if len(runs) else np.array([0])

plt.figure(figsize=(7,4));
plt.hist(lengths, bins=min(20, max(5, int(len(lengths)/2))))
plt.xlabel("epoch length (steps)"); plt.ylabel("count")
plt.title("Vortex epoch length distribution (proxy)")
plt.tight_layout(); plt.savefig(run/"vortex_epochs.png", dpi=160)
print(json.dumps({"epochs": lengths.tolist(), "hist": str(run/"vortex_epochs.png")}, indent=2))
```

---

## tools/uncertainty.py
```python
#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import numpy as np, pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("--summary", required=True)
ap.add_argument("--z", default="R_mean")
ap.add_argument("--alpha", type=float, default=0.10)
args = ap.parse_args()

summary = Path(args.summary)
df = pd.read_csv(summary)

# group by parameter tags (all columns except run and stats)
param_cols = [c for c in df.columns if c not in {"run","R_mean","R_std","peak_mean","vort_max","eproxy_drift","steps"}]

rows = []
for _, g in df.groupby(param_cols):
    z = g[args.z].to_numpy()
    if len(z)==0: continue
    m = float(np.mean(z)); s = float(np.std(z, ddof=1))
    # normal approximation CI
    from math import sqrt
    n = len(z)
    zcrit = 1.64485 if args.alpha==0.10 else 1.28155 if args.alpha==0.20 else 1.95996
    half = zcrit * s / max(sqrt(n),1)
    rows.append({**{k:g.iloc[0][k] for k in param_cols}, f"{args.z}_mean": m, f"{args.z}_CI": half, "n": n})

out = pd.DataFrame(rows)
out.to_csv(summary.parent/"uncertainty.csv", index=False)
print(json.dumps({"uncertainty": str(summary.parent/"uncertainty.csv")}, indent=2))
```

---

## Example workflows

### A) Phase diagram (R_mean over V0 × k_sigma)
```bash
python tools/sweep.py --exp phase_map --spec tools/experiments.yaml --base config.yaml --outroot runs/sweeps
python tools/analyze.py --root runs/sweeps/phase_map --phase lock
python tools/phase_diagram.py --summary runs/sweeps/phase_map/summary.csv --xkey physics.V0 --ykey physics.k_sigma --z R_mean
python tools/uncertainty.py --summary runs/sweeps/phase_map/summary.csv --z R_mean --alpha 0.10
```

### B) Stability scan (amp_cap × phase_blend)
```bash
python tools/sweep.py --exp stability_scan --spec tools/experiments.yaml --base config.yaml --outroot runs/sweeps
python tools/analyze.py --root runs/sweeps/stability_scan --phase lock
python tools/phase_diagram.py --summary runs/sweeps/stability_scan/summary.csv --xkey physics.amp_cap --ykey surrogate.phase_blend --z R_mean
```

### C) Spectral & topology diagnostics for a single run
```bash
python tools/spectra.py  --run runs/double_helix_adaptive
python tools/topology.py --run runs/double_helix_adaptive
```

---

## Notes
- MAC uses **deterministic seeds** but lets you provide multiple seeds per point to estimate **uncertainty**.
- All outputs are **CSV + PNG**, living alongside each run; summaries collect them into a single table.
- Spectral and topology tools are written to work **even without full field snapshots**; when we add snapshots, they’ll automatically use the richer data.
- Everything respects the same physical scaling and stability guards as the main lab.

