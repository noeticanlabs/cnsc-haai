# Glyph Quantum Hybrid Module — with PhaseDrive Backend
# ------------------------------------------------------
# Unified hybrid RFE engine that connects classical and quantum computing layers.
#
# PhaseDrive is the high‑speed classical spectral propagator that mirrors the quantum backend.
# It computes wave evolution (e^{-i α k²}) with classical precision and synchronizes
# coherence across tiles. Use PhaseDrive for maximum speed and stability when quantum
# hardware isn’t needed.
#
# Tagline: "PhaseDrive — classical speed, quantum precision."
# ------------------------------------------------------

# =========================
# glyph_quantum/__init__.py
# =========================

__all__ = [
    "QuantumBackend", "PhaseDrive", "QiskitBackend",
    "encode_amp_phase", "decode_amp_phase",
    "HybridRFE",
]

# =========================
# glyph_quantum/qbackend.py
# =========================

from __future__ import annotations
import numpy as np
from typing import Optional, Tuple

class QuantumBackend:
    name: str = "abstract"
    def __init__(self, n_qubits: int, shots: int = 0):
        self.n_qubits = n_qubits
        self.shots = shots
    def apply_linear_propagator(self, tile_complex: np.ndarray, alpha: float) -> np.ndarray:
        raise NotImplementedError

class PhaseDrive(QuantumBackend):
    """Classical backend that mirrors quantum spectral propagation.
    Computes phase evolution directly using FFT mathematics.
    """
    name = "phasedrive"
    def apply_linear_propagator(self, tile_complex: np.ndarray, alpha: float) -> np.ndarray:
        n = tile_complex.shape[0]
        k = np.fft.fftfreq(n)
        k2 = (k**2)
        phase = np.exp(-1j * alpha * k2)
        return tile_complex * phase

class QiskitBackend(QuantumBackend):
    name = "qiskit"
    def __init__(self, n_qubits: int, shots: int = 0, backend_name: Optional[str] = None):
        super().__init__(n_qubits, shots)
        try:
            from qiskit import QuantumCircuit
            from qiskit_aer import Aer
            self.QuantumCircuit = QuantumCircuit
            self.Aer = Aer
        except Exception as e:
            raise RuntimeError("Qiskit not available; pip install qiskit qiskit-aer") from e
        self.backend = self.Aer.get_backend('aer_simulator') if backend_name is None else self.Aer.get_backend(backend_name)

    def _encode_state(self, vec: np.ndarray):
        from qiskit import QuantumCircuit
        n = vec.size
        if n & (n-1) != 0:
            raise ValueError("Tile length must be power of two for direct load")
        qc = QuantumCircuit(int(np.log2(n)))
        norm = np.linalg.norm(vec)
        state = vec / (norm + 1e-18)
        qc.initialize(state.astype(np.complex128), list(range(qc.num_qubits)))
        return qc, norm

    def _apply_phase_k2(self, qc, alpha: float):
        from qiskit.circuit.library import Diagonal
        n = 2 ** qc.num_qubits
        kk = np.fft.fftfreq(n)
        phases = np.exp(-1j * alpha * (kk**2))
        diag = Diagonal(phases)
        qc.append(diag, qc.qubits)
        return qc

    def apply_linear_propagator(self, tile_complex: np.ndarray, alpha: float) -> np.ndarray:
        from qiskit import transpile
        qc, norm = self._encode_state(tile_complex)
        qc = self._apply_phase_k2(qc, alpha)
        qc.save_statevector()
        tqc = transpile(qc, self.backend)
        result = self.backend.run(tqc, shots=self.shots or None).result()
        state = np.array(result.get_statevector(tqc), dtype=np.complex128)
        return state * norm

# ===========================
# glyph_quantum/hybrid_rfe.py
# ===========================

from __future__ import annotations
import numpy as np
from typing import Optional
from .qbackend import QuantumBackend, PhaseDrive, QiskitBackend

class HybridRFE:
    def __init__(self, nx:int, ny:int, dx:float, dy:float, dt:float,
                 *, hbarc=1.0, mc=1.0, g=0.0, V0=0.0, theta0=0.0,
                 Gamma=0.0, q=0.0, backend: Optional[QuantumBackend]=None,
                 tile_n:int=32):
        self.nx, self.ny, self.dx, self.dy, self.dt = nx, ny, dx, dy, dt
        self.hbarc, self.mc = hbarc, mc
        self.g, self.V0, self.theta0 = g, V0, theta0
        self.Gamma, self.q = Gamma, q
        self.tile_n = tile_n
        self.backend = backend or PhaseDrive(int(np.log2(tile_n)))
        if tile_n & (tile_n-1) != 0:
            raise ValueError("tile_n must be a power of two for backend")
        ky = 2*np.pi*np.fft.fftfreq(ny, d=dy)
        self.Ky2 = ky**2

    def _kinetic_tile_x(self, Psi: np.ndarray, alpha: float) -> np.ndarray:
        out = np.empty_like(Psi)
        for j in range(self.ny):
            row = Psi[:,j]
            for s in range(0, self.nx, self.tile_n):
                tile = row[s:s+self.tile_n]
                if tile.shape[0] < self.tile_n:
                    pad = self.tile_n - tile.shape[0]
                    tilep = np.pad(tile, (0,pad))
                else:
                    tilep = tile
                tk = np.fft.fft(tilep)
                tk2 = self.backend.apply_linear_propagator(tk, alpha)
                tx = np.fft.ifft(tk2)[:tile.shape[0]]
                out[s:s+tile.shape[0], j] = tx
        return out

    def _kinetic_y_classical(self, Psi: np.ndarray, alpha: float) -> np.ndarray:
        Psi_k = np.fft.fft(Psi, axis=1)
        phase = np.exp(-1j * alpha * self.Ky2)
        Psi_k = Psi_k * phase[np.newaxis, :]
        return np.fft.ifft(Psi_k, axis=1)

    def _nonlinear_step(self, Psi: np.ndarray) -> np.ndarray:
        eps = 1e-15
        mod2 = np.abs(Psi)**2
        theta = np.angle(Psi)
        term_g = self.g * mod2
        term_lock = (self.V0*0.5) * np.sin(theta - self.theta0) / (np.sqrt(mod2)+eps)
        phase = -(term_g + term_lock) * (self.dt / self.hbarc)
        Psi = Psi * np.exp(1j*phase) * np.exp(-self.Gamma*self.dt)
        return Psi

    def step(self, Psi: np.ndarray) -> np.ndarray:
        alpha = (self.hbarc * self.dt)/(2*self.mc)
        Psi = self._kinetic_tile_x(Psi, alpha/2)
        Psi = self._kinetic_y_classical(Psi, alpha/2)
        Psi = self._nonlinear_step(Psi)
        Psi = self._kinetic_tile_x(Psi, alpha/2)
        Psi = self._kinetic_y_classical(Psi, alpha/2)
        return Psi
