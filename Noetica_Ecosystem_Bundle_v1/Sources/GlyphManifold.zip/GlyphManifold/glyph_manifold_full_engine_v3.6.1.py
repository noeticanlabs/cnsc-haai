
# glyph_manifold_full_engine.py — Complete System v3.6.1

import numpy as np
import matplotlib.pyplot as plt
from scipy.constants import hbar, k, e
from pathlib import Path
import json
import os
from datetime import datetime
from sympy import isprime

# -------------------------
# Constants + Fusion Anchors
# -------------------------
CODATA = {
    'hbar': hbar,
    'k_B': k,
    'eV': e,
    'MeV': 1e6 * e
}

LCF_TARGETS_MEV = {
    'DD_n': 2.45,
    'DT_n': 14.1,
    '3HeD_p': 15.0
}

# -------------------------
# Load Reference Fields
# -------------------------
def load_cern_fields(path="./cern_data/npz"):
    fields = []
    for file in Path(path).rglob("*.npz"):
        data = np.load(file)
        if "rho" in data:
            fields.append(data["rho"].squeeze())
    return np.array(fields)

# -------------------------
# Load Simulation Field
# -------------------------
def load_sim_field(path="sim_output_theta.npz"):
    if not os.path.exists(path):
        raise FileNotFoundError(f"Missing simulation output: {path}")
    data = np.load(path)
    return data["theta"].squeeze()

# -------------------------
# Spectral Power Function
# -------------------------
def compute_power_spectrum(field):
    F = np.fft.fftshift(np.fft.fft2(field))
    P = np.abs(F) ** 2
    return P / np.max(P)

# -------------------------
# CODES v31 Temporal Prime Gate
# -------------------------
def is_legal_timestamp():
    ts_index = int(datetime.utcnow().timestamp()) % 100000
    return isprime(ts_index)

# -------------------------
# Rhythm Gate + Replace Mode
# -------------------------
def coherence_rhythm_gate(sim_field, cern_fields, coherence_tol=0.15, min_harmonic_overlap=0.65):
    sim_spec = compute_power_spectrum(sim_field)
    cern_spec = np.mean([compute_power_spectrum(f) for f in cern_fields], axis=0)

    l2_error = np.linalg.norm(sim_spec - cern_spec)
    harmonic_overlap = np.sum(np.minimum(sim_spec, cern_spec)) / np.sum(cern_spec)
    timestamp_ok = is_legal_timestamp()

    legality = "PASS" if timestamp_ok else "BLOCKED"
    decision = "REPLACE" if (l2_error > coherence_tol or harmonic_overlap < min_harmonic_overlap or not timestamp_ok) else "PASS"

    print(f"[✓] Rhythm Gate: L2 Error = {l2_error:.4f}, Harmonic Overlap = {harmonic_overlap:.2%}, τ_k legality = {legality} → {decision}")

    return {
        "error": l2_error,
        "overlap": harmonic_overlap,
        "decision": decision,
        "timestamp_ok": timestamp_ok,
        "sim_spectrum": sim_spec,
        "cern_spectrum": cern_spec
    }

# -------------------------
# Plotting
# -------------------------
def plot_spectrum_comparison(sim, ref, out="spectrum_comparison.png"):
    fig, axs = plt.subplots(1, 2, figsize=(10, 4))
    axs[0].imshow(sim, cmap="inferno")
    axs[0].set_title("Simulated Spectrum")
    axs[1].imshow(ref, cmap="viridis")
    axs[1].set_title("CERN Reference Spectrum")
    for ax in axs:
        ax.axis('off')
    plt.tight_layout()
    plt.savefig(out)
    plt.close()

# -------------------------
# Fusion Reference Printer
# -------------------------
def print_fusion_targets():
    print("\n[LCF Fusion Reference Anchors — MeV → J]")
    for k, mev in LCF_TARGETS_MEV.items():
        print(f"  {k}: {mev:.2f} MeV = {mev * CODATA['MeV']:.2e} J")

# -------------------------
# Telemetry Writer
# -------------------------
def write_metrics_json(result, out="calibration_metrics.json"):
    with open(out, "w") as f:
        json.dump({
            "l2_error": result['error'],
            "harmonic_overlap": result['overlap'],
            "tau_k_legality": result['timestamp_ok'],
            "decision": result['decision']
        }, f, indent=2)

# -------------------------
# Main Routine
# -------------------------
def main():
    print("[🌐] Glyph Manifold Engine: Spectral Calibration v3.6.1\n")

    try:
        cern_fields = load_cern_fields()
        sim_field = load_sim_field()
    except Exception as e:
        print("[ERROR]", str(e))
        return

    result = coherence_rhythm_gate(sim_field, cern_fields)
    plot_spectrum_comparison(result['sim_spectrum'], result['cern_spectrum'])
    write_metrics_json(result)
    print_fusion_targets()

    print("\n[✓] Complete: Results saved → spectrum_comparison.png + calibration_metrics.json")

if __name__ == '__main__':
    main()
