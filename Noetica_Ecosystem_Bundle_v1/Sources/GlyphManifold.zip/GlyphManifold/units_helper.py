# units_helper.py — minimal helpers for unit conversions and naturalization.
# Usage:
#   from units_helper import mev_to_j, j_to_mev, fm_to_m, m_to_fm, natural_energy_length
#   E_J = mev_to_j(5.0)   # 5 MeV -> Joules
#   L_fm = m_to_fm(1e-9)  # 1 nm -> fm
#
ELEM_CHARGE = 1.602176634e-19  # J / eV (exact)
MEV_TO_J = 1e6 * ELEM_CHARGE
J_TO_MeV = 1.0 / MEV_TO_J
HBAR = 1.054571817e-34  # J s
C = 299792458.0         # m/s
HBAR_C_MeVfm = HBAR * C * J_TO_MeV * 1e15

def mev_to_j(x):
    return float(x) * MEV_TO_J

def j_to_mev(x):
    return float(x) * J_TO_MeV

def fm_to_m(x):
    return float(x) * 1e-15

def m_to_fm(x):
    return float(x) * 1e15

def natural_energy_length(E_MeV):
    """Return the Compton-like length scale (in fm) for energy E (MeV): L ~ ħc / E."""
    if E_MeV <= 0: 
        return float('nan')
    return HBAR_C_MeVfm / float(E_MeV)
