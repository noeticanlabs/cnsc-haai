
# PhaseDrive v3.7-MHD — Glyph Manifold Engine with Magnetic Field Coupling
# Author: Study Mentor ✏️📚
# Description: Coherence phase field solver with MHD magnetic coupling via B·∇θ term

import numpy as np
import json
import os
from numpy.fft import fft2, ifft2, fftfreq

# --- Configuration ---
class Config:
    H, W = 256, 256
    dx = 0.01
    dt = 0.0025
    beta = 0.9
    gamma = 0.03
    V0 = 1.0
    theta0 = 0.0
    alpha = 0.02
    kappa = 0.01
    lam = 0.05
    mu = 0.01
    nu = 0.05  # Magnetic coupling term
    use_strang_split = True
    log_path = "logs/telemetry_mhd.jsonl"

# --- Kernel Cache ---
def compute_fft_kernels(H, W, dx):
    kx = fftfreq(W, dx) * 2 * np.pi
    ky = fftfreq(H, dx) * 2 * np.pi
    KX, KY = np.meshgrid(kx, ky)
    k2 = KX**2 + KY**2
    return k2, KX, KY

# --- RFE Components with B Coupling ---
def compute_rhs(theta, theta_dot, rho, T, Bx, By, cfg):
    grad_y, grad_x = np.gradient(theta)
    laplacian_theta = np.gradient(grad_x)[0] + np.gradient(grad_y)[1]

    BdotGrad = Bx * grad_x + By * grad_y  # B · ∇θ

    div_rho_grad = np.gradient(rho * grad_x)[0] + np.gradient(rho * grad_y)[1]
    lap_T = np.gradient(np.gradient(T)[0])[0] + np.gradient(np.gradient(T)[1])[1]

    rhs = (cfg.beta * laplacian_theta
           - cfg.gamma * theta_dot
           + cfg.V0 * np.sin(theta - cfg.theta0)
           + cfg.alpha * div_rho_grad
           + cfg.kappa * lap_T
           + cfg.lam * (grad_x**2 + grad_y**2)
           - cfg.mu * theta**4
           + cfg.nu * BdotGrad)

    return cfg.dt * rhs

# --- Phase Step ---
def phase_step(theta, theta_dot, rho, T, Bx, By, k2, cfg):
    if cfg.use_strang_split:
        theta_dot += 0.5 * compute_rhs(theta, theta_dot, rho, T, Bx, By, cfg)

    # Spectral (FFT) update
    theta_k = fft2(theta)
    theta_dot_k = fft2(theta_dot)
    theta_dot_k_new = theta_dot_k / (1 + cfg.gamma * cfg.dt * k2)
    theta_dot = np.real(ifft2(theta_dot_k_new))

    theta += cfg.dt * theta_dot

    if cfg.use_strang_split:
        theta_dot += 0.5 * compute_rhs(theta, theta_dot, rho, T, Bx, By, cfg)

    return theta, theta_dot

# --- Logging ---
def log_metrics(step, theta, theta_dot, cfg):
    grad = np.gradient(theta)
    max_grad = np.max(np.sqrt(grad[0]**2 + grad[1]**2))
    energy = 0.5 * np.mean(theta_dot**2 + grad[0]**2 + grad[1]**2) + cfg.V0 * np.mean(1 - np.cos(theta))
    drift = np.abs(np.sum(theta)) / (cfg.H * cfg.W)
    norm_dev = np.abs(1 - np.mean(np.cos(theta)**2 + np.sin(theta)**2))
    metrics = {
        "step": step,
        "E_c": float(energy),
        "drift": float(drift),
        "max_grad": float(max_grad),
        "phase_norm_dev": float(norm_dev),
        "K": 64,
        "dt": cfg.dt,
        "beta": cfg.beta,
        "gamma": cfg.gamma,
        "nu": cfg.nu,
        "mode": "mhd"
    }
    os.makedirs(os.path.dirname(cfg.log_path), exist_ok=True)
    with open(cfg.log_path, 'a') as f:
        f.write(json.dumps(metrics) + "\n")

# --- Main Simulation ---
def run_simulation(steps=200):
    cfg = Config()
    theta = np.random.uniform(-0.1, 0.1, (cfg.H, cfg.W))
    theta_dot = np.zeros_like(theta)
    rho = np.ones_like(theta)
    T = np.ones_like(theta) * 0.5

    # Magnetic field (static for now)
    Bx = np.ones_like(theta) * 0.2
    By = np.zeros_like(theta)

    k2, _, _ = compute_fft_kernels(cfg.H, cfg.W, cfg.dx)

    for step in range(steps):
        theta, theta_dot = phase_step(theta, theta_dot, rho, T, Bx, By, k2, cfg)
        log_metrics(step, theta, theta_dot, cfg)

    # Save final theta for spectral analysis
    np.savez("sim_output_theta_mhd.npz", theta=theta)

if __name__ == '__main__':
    run_simulation()
    print("✅ PhaseDrive v3.7-MHD Simulation Complete. Output: sim_output_theta_mhd.npz")
