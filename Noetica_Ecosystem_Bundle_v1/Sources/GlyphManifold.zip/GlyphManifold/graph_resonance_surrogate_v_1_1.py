"""
Glyph Manifold → Graph-Resonance Surrogate (v1.1)

Purpose
=======
Train a graph-based message-passing surrogate to predict next-step fields
(φ, θ) of your Glyph Manifold from real simulation exports. Drop-in
replacement for the synthetic demo; this consumes your arrays and builds a
lattice graph (or accepts a custom graph) to learn coherence dynamics.

How to use
==========
1) Export arrays from your simulator for a single time step (t → t+1):
   Required (shape [H, W] or [N] for irregular):
     - phi_t.npy            # φ at t
     - theta_t.npy          # θ at t (radians, any wrap)
     - q_t.npy              # source/sink ⊕/⊖ at t
     - phi_t1.npy           # φ at t+1
     - theta_t1.npy         # θ at t+1 (radians)
   Optional (if available):
     - entropy_S_t.npy, curvature_kappa_t.npy, energy_t.npy

2) Set DATA_PATH and GRID_SHAPE below.
3) Run: train → eval → visualize. Swap the synthetic loader for your files.
4) Extend: plug a custom edge_index for irregular meshes/graphs.

Notes
=====
• Phase is encoded as (cosθ, sinθ) internally for stability.
• Periodic boundaries assumed by default for lattice neighbors.
• For irregular graphs, provide edge_index and set GRID_SHAPE=None.
• Physics-inspired losses include conservation proxy and circular phase loss.

Coherence-Protocol Hygiene
==========================
- Units normalized: φ∈[0,1]; θ on S¹; optional features z-score.
- Verification ledger printed after training (conservation drift, error).
"""

from __future__ import annotations
import os, math, json
from dataclasses import dataclass
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import matplotlib.pyplot as plt

# --------------------------- Config ---------------------------
@dataclass
class Config:
    data_path: str = "/mnt/data"          # change to your export folder
    grid_shape: tuple[int,int] | None = (64, 64)  # (H, W) or None if irregular
    use_optional_feats: bool = True
    k_neighbors: int = 4                   # 4 or 8 (only for lattice)
    epochs: int = 120
    lr: float = 3e-3
    weight_decay: float = 1e-4
    batch_size: int = 4                    # for multi-sample datasets
    hidden: int = 128
    layers: int = 3
    seed: int = 42

CFG = Config()

# --------------------------- Utilities ---------------------------

def set_seed(s=42):
    import random
    random.seed(s); np.random.seed(s); torch.manual_seed(s)

set_seed(CFG.seed)

def wrap_angle(a):
    """Wrap radians to (-pi, pi]."""
    return ((a + np.pi) % (2*np.pi)) - np.pi

# --------------------------- Data Loading ---------------------------

def load_field(name: str):
    path = os.path.join(CFG.data_path, name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"Missing file: {path}")
    arr = np.load(path)
    return arr

class GlyphDataset(torch.utils.data.Dataset):
    """Single-step pairs (t → t+1) with node features and targets.
    Supports: lattice (auto-neighbors) or irregular (edge_index.npy present).
    """
    def __init__(self):
        # Required
        phi_t   = load_field("phi_t.npy")
        theta_t = load_field("theta_t.npy")
        q_t     = load_field("q_t.npy")
        phi_t1  = load_field("phi_t1.npy")
        theta_t1= load_field("theta_t1.npy")

        # Optional
        S_t = None; kappa_t = None; energy_t = None
        if CFG.use_optional_feats:
            for nm in ["entropy_S_t.npy", "curvature_kappa_t.npy", "energy_t.npy"]:
                p = os.path.join(CFG.data_path, nm)
                if os.path.exists(p):
                    if nm.startswith("entropy"): S_t = np.load(p)
                    elif nm.startswith("curvature"): kappa_t = np.load(p)
                    elif nm.startswith("energy"): energy_t = np.load(p)

        # Shape handling
        if CFG.grid_shape is not None:
            H, W = CFG.grid_shape
            # reshape if needed
            for a, nm in [(phi_t,"phi_t"),(theta_t,"theta_t"),(q_t,"q_t"),
                          (phi_t1,"phi_t1"),(theta_t1,"theta_t1")]:
                if a.shape != (H, W):
                    a = a.reshape(H, W)
                locals()[nm] = a
        else:
            # irregular: arrays must be 1D of same length N
            for a, nm in [(phi_t,"phi_t"),(theta_t,"theta_t"),(q_t,"q_t"),
                          (phi_t1,"phi_t1"),(theta_t1,"theta_t1")]:
                if a.ndim != 1: a = a.reshape(-1)
                locals()[nm] = a

        # Encode features
        theta_cos = np.cos(theta_t); theta_sin = np.sin(theta_t)
        feats = [phi_t, theta_cos, theta_sin, q_t]
        if S_t is not None: feats.append(S_t)
        if kappa_t is not None: feats.append(kappa_t)
        if energy_t is not None: feats.append(energy_t)
        X = np.stack(feats, axis=-1).astype(np.float32)

        # Targets
        th1 = wrap_angle(theta_t1)
        Y = np.stack([phi_t1, np.cos(th1), np.sin(th1)], axis=-1).astype(np.float32)

        self.X = X.reshape(-1, X.shape[-1])  # (N, d)
        self.Y = Y.reshape(-1, 3)            # (N, 3)

        # Build neighbors
        self.edge_index = self._build_edges()

    def _build_edges(self):
        if CFG.grid_shape is None:
            # try to load custom edges
            einf = os.path.join(CFG.data_path, "edge_index.npy")
            if not os.path.exists(einf):
                raise FileNotFoundError("Irregular mode requires edge_index.npy of shape (2, E)")
            ei = np.load(einf)
            assert ei.shape[0] == 2, "edge_index should be (2, E)"
            return torch.tensor(ei, dtype=torch.long)
        else:
            H, W = CFG.grid_shape
            def idx(y, x): return y*W + x
            edges = []
            ks = 4 if CFG.k_neighbors == 4 else 8
            for y in range(H):
                for x in range(W):
                    i = idx(y,x)
                    nbs = [((y-1)%H, x), ((y+1)%H, x), (y,(x-1)%W), (y,(x+1)%W)]
                    if ks==8:
                        nbs += [((y-1)%H,(x-1)%W),((y-1)%H,(x+1)%W),((y+1)%H,(x-1)%W),((y+1)%H,(x+1)%W)]
                    for ny, nx in nbs:
                        j = idx(ny,nx)
                        edges.append((i,j))
            ei = np.array(edges, dtype=np.int64).T  # (2, E)
            return torch.tensor(ei, dtype=torch.long)

    def __len__(self):
        return 1  # single snapshot pair; extend to sequences as needed

    def __getitem__(self, idx):
        return {
            "x": torch.tensor(self.X),
            "y": torch.tensor(self.Y),
            "edge_index": self.edge_index,
        }

# --------------------------- Model ---------------------------
class ResonantMPNN(nn.Module):
    """Lightweight message-passing net with neighbor aggregation (no PyG dependency)."""
    def __init__(self, in_dim: int, hidden: int, out_dim: int, layers: int = 3):
        super().__init__()
        self.layers = layers
        self.lin_in = nn.Linear(in_dim, hidden)
        self.lin_mp = nn.ModuleList([nn.Linear(hidden*2, hidden) for _ in range(layers)])
        self.norms = nn.ModuleList([nn.LayerNorm(hidden) for _ in range(layers)])
        self.act = nn.SiLU()
        self.head = nn.Linear(hidden, out_dim)

    def aggregate(self, h, edge_index, N):
        # mean aggregation over incoming neighbors
        src, dst = edge_index  # (E,), (E,)
        m = torch.zeros_like(h)
        m.index_add_(0, dst, h[src])
        deg = torch.zeros(N, device=h.device).index_add_(0, dst, torch.ones_like(dst, dtype=torch.float, device=h.device))
        deg = torch.clamp(deg, min=1.0).unsqueeze(-1)
        return m / deg

    def forward(self, x, edge_index):
        N = x.size(0)
        h = self.act(self.lin_in(x))
        for l in range(self.layers):
            h_nb = self.aggregate(h, edge_index, N)
            h_cat = torch.cat([h, h_nb], dim=-1)
            h_new = self.act(self.lin_mp[l](h_cat))
            h = self.norms[l](h + h_new)
        out = self.head(h)
        phi_pred = torch.sigmoid(out[:, :1])         # [0,1]
        cs = F.normalize(out[:, 1:3], p=2, dim=-1)   # (cos, sin)
        return torch.cat([phi_pred, cs], dim=-1)

# --------------------------- Losses & Metrics ---------------------------

def circular_loss(pred_cs, true_cs):
    return (1 - (pred_cs * true_cs).sum(dim=-1)).mean()

def conservation_proxy(phi_pred, q):
    # global conservation drift proxy: sum φ vs sources/sinks (heuristic)
    total = phi_pred.sum()
    src = torch.clamp(q, min=0).sum()
    sink= torch.clamp(-q, min=0).sum()
    return (total - (src - sink)).abs() / (phi_pred.numel() + 1e-8)

# --------------------------- Train / Eval ---------------------------

def train_once():
    ds = GlyphDataset()
    x = ds[0]["x"]; y = ds[0]["y"]; edge_index = ds[0]["edge_index"]

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    x = x.to(device); y = y.to(device); edge_index = edge_index.to(device)

    model = ResonantMPNN(in_dim=x.shape[1], hidden=CFG.hidden, out_dim=3, layers=CFG.layers).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=CFG.lr, weight_decay=CFG.weight_decay)

    # q index assumed as 3 if using only [φ, cosθ, sinθ, q]; adjust if optional feats used
    IDX_Q = 3

    hist = []
    for ep in range(CFG.epochs):
        model.train()
        pred = model(x, edge_index)
        l_phi = F.mse_loss(pred[:, :1], y[:, :1])
        l_th  = circular_loss(pred[:, 1:3], y[:, 1:3])
        q = x[:, IDX_Q:IDX_Q+1] if x.shape[1] > IDX_Q else torch.zeros_like(pred[:, :1])
        l_cons = conservation_proxy(pred[:, :1], q)
        loss = l_phi + l_th + 0.05 * l_cons
        opt.zero_grad(); loss.backward(); opt.step()

        if (ep+1) % 10 == 0:
            hist.append({"epoch": ep+1, "total": float(loss.item()), "L_phi": float(l_phi.item()), "L_theta": float(l_th.item()), "L_cons": float(l_cons.item())})

    print("Epoch | Total | L_phi | L_theta | L_cons")
    for r in hist[-10:]:
        print(f"{r['epoch']:5d} | {r['total']:.5f} | {r['L_phi']:.5f} | {r['L_theta']:.5f} | {r['L_cons']:.5f}")

    # Visualization (φ true vs pred) if lattice
    if CFG.grid_shape is not None:
        H, W = CFG.grid_shape
        with torch.no_grad():
            pred = model(x, edge_index).cpu().numpy()
        phi_true = y[:, 0].detach().cpu().numpy().reshape(H, W)
        phi_pred = pred[:, 0].reshape(H, W)
        fig, axes = plt.subplots(1, 2, figsize=(8, 4))
        im0 = axes[0].imshow(phi_true); axes[0].set_title('φ (true)'); axes[0].axis('off')
        im1 = axes[1].imshow(phi_pred); axes[1].set_title('φ (pred)'); axes[1].axis('off')
        plt.tight_layout(); plt.show()

    # Verification ledger
    with torch.no_grad():
        pred = model(x, edge_index)
        l_phi = F.mse_loss(pred[:, :1], y[:, :1]).item()
        l_th  = circular_loss(pred[:, 1:3], y[:, 1:3]).item()
        q = x[:, IDX_Q:IDX_Q+1] if x.shape[1] > IDX_Q else torch.zeros_like(pred[:, :1])
        l_cons = conservation_proxy(pred[:, :1], q).item()
        ledger = {
            "dimensional_consistency": True,
            "phase_encoded_on_S1": True,
            "losses": {"L_phi": l_phi, "L_theta": l_th, "L_cons": l_cons},
        }
        print("\nVerification Ledger:\n" + json.dumps(ledger, indent=2))

if __name__ == "__main__":
    train_once()

# ─────────────────────────────────────────────────────────────
# Hybrid Integration Module — Residual, Coupler, Boundary, Closure (v1.2)
# ─────────────────────────────────────────────────────────────

"""
This module inserts the learned graph operator into the RIGHT slot of the
Glyph Manifold evolution loop, with invariant projection and a gated mixer.
Placements:
  P1: Residual (analytic step → learned correction)
  P2: Nonlocal Coupler (replace analytic coupler with learned message passing)
  P3: Boundary Controller (learned BC mapping only)
  P4: SGS Closure (sub-grid stress/flux on coarse grids)
Switch via CFG.placement.
"""

from enum import Enum

class Placement(str, Enum):
    Residual = "P1"
    Coupler  = "P2"
    Boundary = "P3"
    Closure  = "P4"

# Extend existing CFG with placement + safety knobs
CFG.placement = getattr(CFG, 'placement', Placement.Residual)
CFG.max_correction_scale = getattr(CFG, 'max_correction_scale', 0.25)  # clip on φ
CFG.enable_gating = getattr(CFG, 'enable_gating', True)
CFG.fail_closed = getattr(CFG, 'fail_closed', True)  # revert to analytic on invariant breach

# --- Invariant Projector & Safety Gate ---

def project_invariants(delta: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
    """Project learned ΔX into invariant-respecting subspace.
    - φ correction zero-mean (global conservation proxy)
    - (cosθ, sinθ) re-normalized to S¹
    """
    dphi = delta[:, :1]
    dphi = dphi - dphi.mean()  # zero-sum
    # clamp correction to avoid runaway
    dphi = torch.clamp(dphi, -CFG.max_correction_scale, CFG.max_correction_scale)
    dcs  = F.normalize(delta[:, 1:3], p=2, dim=-1)
    return torch.cat([dphi, dcs], dim=-1)

@torch.no_grad()
def drift_score(delta: torch.Tensor, x: torch.Tensor) -> torch.Tensor:
    """Compute a scalar drift score for gating. Lower is safer."""
    # Use φ correction magnitude + phase misalignment proxy
    dphi_mag = delta[:, :1].abs().mean()
    dth_mag  = (1 - (delta[:, 1:3] * delta[:, 1:3]).sum(dim=-1).sqrt()).mean()
    return dphi_mag + 0.2 * dth_mag

@torch.no_grad()
def gate_weight(score: torch.Tensor) -> torch.Tensor:
    # sigmoid gate; higher score → lower λ
    return torch.sigmoid(3.0 - 10.0 * score)

# --- Pluggable Coupler (for P2/P4) ---
class GraphCoupler(nn.Module):
    """Wraps ResonantMPNN to output either ΔX (Residual) or flux/coupler terms."""
    def __init__(self, in_dim: int, hidden: int, layers: int = 3, mode: str = 'delta'):
        super().__init__()
        self.mode = mode  # 'delta' or 'flux'
        self.net = ResonantMPNN(in_dim=in_dim, hidden=hidden, out_dim=3, layers=layers)
        # If flux mode, last layer can be interpreted as coupler fields

    def forward(self, x, edge_index):
        out = self.net(x, edge_index)
        return out

# Instantiate coupler once
_coupler = None

def get_coupler(in_dim: int, hidden: int, layers: int):
    global _coupler
    if _coupler is None:
        _coupler = GraphCoupler(in_dim=in_dim, hidden=hidden, layers=layers)
    return _coupler

# --- Hybrid Steps ---

@torch.no_grad()
def step_residual(X_t: torch.Tensor, edge_index: torch.Tensor, step_analytic_fn) -> torch.Tensor:
    """P1: Analytic step then learned residual correction with gating and projection."""
    X_star = step_analytic_fn(X_t)
    coupler = get_coupler(in_dim=X_t.shape[1], hidden=CFG.hidden, layers=CFG.layers)
    delta = coupler(X_t, edge_index)                   # predict ΔX
    delta = project_invariants(delta, X_t)
    lam = torch.tensor(1.0, device=X_t.device)
    if CFG.enable_gating:
        score = drift_score(delta, X_t)
        lam = gate_weight(score)
    X_next = X_star + lam * delta
    return X_next

@torch.no_grad()
def step_coupler(X_t: torch.Tensor, edge_index: torch.Tensor, local_core_fn) -> torch.Tensor:
    """P2: Keep local PDE core; replace/augment coupler with learned message passing."""
    coupler = get_coupler(in_dim=X_t.shape[1], hidden=CFG.hidden, layers=CFG.layers)
    C = coupler(X_t, edge_index)  # interpret as nonlocal influence on (φ, θ)
    X_dot_local = local_core_fn(X_t)
    X_next = X_t + (X_dot_local + C)  # dt normalized to 1 in this abstraction
    X_next = project_invariants(X_next - X_t, X_t) + X_t
    return X_next

@torch.no_grad()
def step_boundary(X_t: torch.Tensor, edge_index: torch.Tensor, apply_bc_fn, boundary_mask: torch.Tensor) -> torch.Tensor:
    """P3: Learned boundary controller; interior uses analytic step elsewhere."""
    coupler = get_coupler(in_dim=X_t.shape[1], hidden=CFG.hidden, layers=CFG.layers)
    bc_delta = coupler(X_t, edge_index)
    bc_delta = project_invariants(bc_delta, X_t)
    X_bc = X_t.clone()
    X_bc[boundary_mask] = apply_bc_fn(X_t[boundary_mask], bc_delta[boundary_mask])
    return X_bc

@torch.no_grad()
def step_closure(X_t: torch.Tensor, edge_index: torch.Tensor, resolved_flux_fn) -> torch.Tensor:
    """P4: Learned sub-grid closure added to resolved flux divergence."""
    coupler = get_coupler(in_dim=X_t.shape[1], hidden=CFG.hidden, layers=CFG.layers)
    SGS = coupler(X_t, edge_index)  # interpret as closure term
    X_next = resolved_flux_fn(X_t, SGS)
    X_next = project_invariants(X_next - X_t, X_t) + X_t
    return X_next

# --- Orchestrator ---
@torch.no_grad()
def step_hybrid(X_t: torch.Tensor, edge_index: torch.Tensor, fns: dict) -> torch.Tensor:
    """Dispatch to the chosen placement; fns provides required callables:
       fns = { 'step_analytic': ..., 'local_core': ..., 'apply_bc': ..., 'resolved_flux': ... }
    """
    try:
        if CFG.placement == Placement.Residual:
            return step_residual(X_t, edge_index, fns['step_analytic'])
        elif CFG.placement == Placement.Coupler:
            return step_coupler(X_t, edge_index, fns['local_core'])
        elif CFG.placement == Placement.Boundary:
            return step_boundary(X_t, edge_index, fns['apply_bc'], fns['boundary_mask'])
        elif CFG.placement == Placement.Closure:
            return step_closure(X_t, edge_index, fns['resolved_flux'])
        else:
            return fns['step_analytic'](X_t)
    except Exception as e:
        if CFG.fail_closed:
            # Fail-closed: fall back to analytic evolution
            return fns['step_analytic'](X_t)
        raise e

# --- Verification Ledger Hook ---

def topology_winding(theta_cos_sin: torch.Tensor, H: int, W: int) -> float:
    """Simple winding estimator on a lattice (diagnostic)."""
    cs = theta_cos_sin.view(H, W, 2).cpu().numpy()
    # Placeholder lightweight proxy; replace with robust contour integral if needed
    # Here we return average curl of angle field as a crude indicator
    th = np.arctan2(cs[...,1], cs[...,0])
    gy, gx = np.gradient(th)
    return float(np.mean(gx - gy))

@torch.no_grad()
def log_ledger(X_prev: torch.Tensor, X_next: torch.Tensor, q_idx: int = 3, grid_shape=None) -> dict:
    phi_prev = X_prev[:, 0]; phi_next = X_next[:, 0]
    q = X_prev[:, q_idx] if q_idx < X_prev.shape[1] else torch.zeros_like(phi_prev)
    mass_drift = (phi_next.sum() - phi_prev.sum() - q.sum()).abs() / (phi_prev.sum() + 1e-8)
    entry = {
        'mass_drift': float(mass_drift.item()),
    }
    if grid_shape is not None:
        H, W = grid_shape
        entry['topology_proxy'] = topology_winding(X_next[:, 1:3], H, W)
    return entry

# --- Example wiring (pseudo) ---
"""
X_t: (N, D) with channels [φ, cosθ, sinθ, q, ...]
edge_index: (2, E)
User must provide:
  def step_analytic(X): ...           # existing PDE integrator, one step
  def local_core(X): ...              # local part of RHS without coupler
  def apply_bc(X_bnd, delta_bnd): ... # boundary update
  def resolved_flux(X, SGS): ...      # coarse flux integrator + closure
Then in loop:
  X_next = step_hybrid(X_t, edge_index, {
      'step_analytic': step_analytic,
      'local_core': local_core,
      'apply_bc': apply_bc,
      'resolved_flux': resolved_flux,
      'boundary_mask': boundary_mask_tensor,
  })
  ledger = log_ledger(X_t, X_next, q_idx=3, grid_shape=CFG.grid_shape)
"""


# -----------------------------
# Surrogate CoherentModule + Orchestrator Demo
# -----------------------------

class _TinySurrogate(nn.Module):
    """Lightweight surrogate (ResonantMPNN-style) used inside the module.
    Predicts Δ[φ, θ] encoded as [Δφ, cosθ, sinθ] and supports MC-dropout.
    """
    def __init__(self, in_dim=4, hidden=128, layers=3, p_drop=0.2):
        super().__init__()
        self.p_drop = p_drop
        self.lin_in = nn.Linear(in_dim, hidden)
        self.layers = nn.ModuleList([nn.Linear(hidden*2, hidden) for _ in range(layers)])
        self.norms = nn.ModuleList([nn.LayerNorm(hidden) for _ in range(layers)])
        self.act = nn.SiLU()
        self.head = nn.Linear(hidden, 3)
        self.drop = nn.Dropout(p_drop)

    def _aggregate(self, h, A):
        # mean over neighbors using adjacency A (dense for simplicity)
        deg = A.sum(-1, keepdim=True).clamp(min=1.0)
        return A @ h / deg

    def forward(self, x, A, mc=False):
        h = self.act(self.lin_in(x))
        for l, lin in enumerate(self.layers):
            h_nb = self._aggregate(h, A)
            h_cat = torch.cat([h, h_nb], dim=-1)
            h_new = self.act(lin(h_cat))
            h = self.norms[l](h + (self.drop(h_new) if mc else h_new))
        out = self.head(h)
        dphi = torch.tanh(out[:, :1]) * 0.25  # bounded correction
        cs = F.normalize(out[:, 1:3], p=2, dim=-1)
        return torch.cat([dphi, cs], dim=-1)

class GlyphSurrogateModule(CoherentModule):
    name = "glyph_surrogate"
    def __init__(self, in_dim=4, hidden=128, layers=3, p_drop=0.2):
        self.net = _TinySurrogate(in_dim, hidden, layers, p_drop)
        self._schema_in = {"graph":"GraphStruct","phi":"tensor","theta":"tensor","q":"tensor","mc":"int"}
        self._schema_out = {"dphi":"tensor","dtheta_cs":"tensor","uncertainty":"float"}
        self._phase = PhaseState(version="1.0.0", schema_hash=stable_hash([self._schema_in,self._schema_out]), invariants={"proj":"mass+S1"})

    def phase(self): return self._phase
    def input_schema(self): return self._schema_in
    def output_schema(self): return self._schema_out

    def call(self, payload, *, intent=None):
        G: GraphStruct = payload["graph"]
        phi = payload["phi"]; theta = payload["theta"]; q = payload["q"]
        x = torch.stack([phi, torch.cos(theta), torch.sin(theta), q], dim=-1)
        mc = int(payload.get("mc", 5))
        # MC-dropout samples for epistemic variance
        preds = []
        for _ in range(max(1, mc)):
            preds.append(self.net(x, G.adj, mc=True))
        P = torch.stack(preds, dim=0)  # (M, N, 3)
        mean = P.mean(0)
        var = P.var(0).mean().item()
        dphi = mean[:, :1]
        dtheta_cs = mean[:, 1:3]
        # invariant projection
        dphi = dphi - dphi.mean(dim=0, keepdim=True)
        dtheta_cs = F.normalize(dtheta_cs, p=2, dim=-1)
        return {"dphi": dphi, "dtheta_cs": dtheta_cs, "uncertainty": float(var)}

# Integrate surrogate into GlyphManifoldModule via gated mixing
class GlyphManifoldModule(nn.Module, CoherentModule):
    name = "glyph_manifold"
    def __init__(self, in_dim=2, hidden_dim=32, n_relations=3, dt=0.1, use_surrogate=True):
        nn.Module.__init__(self)
        self.pde_core = GlyphPDECore(dt=dt)
        self.surrogate = GlyphRGATSurrogate(in_dim, hidden_dim, n_relations)
        self.use_surrogate = use_surrogate
        self.dt = dt
        # CoherentModule bits
        self._schema_in = {"graph":"GraphStruct","phi":"tensor","theta":"tensor","q":"tensor","lam":"float","surrogate_out":"dict?"}
        self._schema_out = {"phi_next":"tensor","theta_next":"tensor","lambda":"float"}
        self._phase = PhaseState(version="1.1.0", schema_hash=stable_hash([self._schema_in,self._schema_out]), invariants={"mass_conserve":True,"phase_norm":True})

    def phase(self): return self._phase
    def input_schema(self): return self._schema_in
    def output_schema(self): return self._schema_out

    def project_invariants(self, dphi, dtheta):
        dphi = dphi - dphi.mean(dim=0, keepdim=True)
        dtheta = torch.atan2(torch.sin(dtheta), torch.cos(dtheta))
        return dphi, dtheta

    def call(self, payload, *, intent=None):
        G = payload["graph"]; phi = payload["phi"]; theta = payload["theta"]; q = payload["q"]
        lam = float(payload.get("lam", 0.2))
        phi_star, theta_star = self.pde_core(G, phi, theta, q)

        if self.use_surrogate and payload.get("surrogate_out") is not None:
            so = payload["surrogate_out"]
            # convert cos/sin back to delta-theta via small-angle approx
            dphi = so["dphi"]
            cs = so["dtheta_cs"]
            dtheta = torch.atan2(cs[:,1], cs[:,0])
            # gate from uncertainty & drift
            drift = (phi_star.sum() - phi.sum()).abs().item()
            unc = float(so.get("uncertainty", 0.0))
            lam_eff = 1.0 / (1.0 + 5.0*unc + 2.0*drift)
            lam_use = lam * lam_eff
            dphi, dtheta = self.project_invariants(dphi, dtheta)
            phi_next = phi_star + lam_use * dphi
            theta_next = theta_star + lam_use * dtheta
            out_lambda = float(lam_use)
        else:
            # fallback: internal RGAT correction (no external surrogate provided)
            x = torch.stack([phi, theta], dim=-1)
            dX = self.surrogate(G, x)
            dphi, dtheta = dX[...,0], dX[...,1]
            dphi, dtheta = self.project_invariants(dphi, dtheta)
            phi_next = phi_star + lam * dphi
            theta_next = theta_star + lam * dtheta
            out_lambda = float(lam)

        return {"phi_next": phi_next, "theta_next": theta_next, "lambda": out_lambda}

# -----------------------------
# Orchestrator demo hook — run baseline and hybrid step
# -----------------------------
if __name__ == "__main__":
    # Baseline run
    base = PhaseDriveBaseline()
    rep = base.call({"seed": 0})
    print("Baseline report:", rep["report"])  # paths saved under /mnt/data/baseline_rfe_p0

    # Small synthetic graph + fields to exercise surrogate-gated mixing
    N = 64
    A = torch.ones(N, N) - torch.eye(N)
    G = GraphStruct(adj=A, rel_adj=[A, A, A])
    phi = torch.rand(N)
    theta = torch.rand(N)*2*math.pi - math.pi
    q = torch.zeros(N)

    # External surrogate
    surr = GlyphSurrogateModule()
    so = surr.call({"graph": G, "phi": phi, "theta": theta, "q": q, "mc": 5})

    # Hybrid step via GlyphManifoldModule as CoherentModule
    gm = GlyphManifoldModule(use_surrogate=True)
    out = gm.call({"graph": G, "phi": phi, "theta": theta, "q": q, "lam": 0.2, "surrogate_out": so})
    print({"lambda_used": out["lambda"], "phi_mean": float(out["phi_next"].mean().item())})
