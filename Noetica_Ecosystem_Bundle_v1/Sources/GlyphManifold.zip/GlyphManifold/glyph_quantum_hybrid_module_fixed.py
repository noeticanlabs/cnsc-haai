from __future__ import annotations

import numpy as np
from typing import Optional

# =========================
# Glyph Quantum Hybrid Module — with PhaseDrive Backend
# Unified hybrid RFE engine that connects classical and quantum computing layers.
#
# PhaseDrive is the high‑speed classical spectral propagator that mirrors the quantum backend.
# It computes wave evolution (e^{-i α k²}) with classical precision and synchronizes
# coherence across tiles. Use PhaseDrive for maximum speed and stability when quantum
# hardware isn’t needed.
# =========================


class QuantumBackend:
    """Abstract quantum backend interface for linear spectral propagation.
    The contract: apply e^{-i α k^2} in the spectral domain to a *1D tile* (complex vector).
    """
    name: str = "abstract"

    def __init__(self, *args, **kwargs) -> None:
        pass

    def apply_linear_propagator(self, tile_complex: np.ndarray, alpha: float) -> np.ndarray:
        """Apply e^{-i α k^2} to the spectral representation of a 1D tile.
        Implementations may approximate/encode this transformation.
        """
        raise NotImplementedError


class PhaseDrive(QuantumBackend):
    """Classical backend that mirrors quantum spectral propagation.
    Computes phase evolution directly using FFT mathematics.
    """
    name = "phasedrive"

    def apply_linear_propagator(self, tile_complex: np.ndarray, alpha: float) -> np.ndarray:
        # tile_complex is expected in Fourier space along x with unit-length frequency grid
        n = tile_complex.shape[0]
        k = np.fft.fftfreq(n)  # normalized frequencies: 0, 1/n, ..., (n/2-1)/n, -n/2/n, ...
        k2 = k**2
        phase = np.exp(-1j * alpha * k2)
        return tile_complex * phase


class QiskitBackend(QuantumBackend):
    """Placeholder/stub for a Qiskit-based backend.
    Left lightweight to avoid external dependency; demonstrates the interface.
    """
    name = "qiskit"

    def __init__(self, n_qubits: int, shots: int = 0, backend_name: Optional[str] = None):
        self.n_qubits = n_qubits
        self.shots = shots
        self.backend_name = backend_name

    # Example helpers to show potential encoding path
    def _encode_state(self, tile_complex: np.ndarray) -> np.ndarray:
        # Normalize and return as-is in this stub
        norm = np.linalg.norm(tile_complex)
        return tile_complex / (norm + 1e-12)

    def _apply_phase_k2(self, tile_encoded: np.ndarray, alpha: float) -> np.ndarray:
        # Mirror classical behavior for this stub
        n = tile_encoded.shape[0]
        k = np.fft.fftfreq(n)
        k2 = k**2
        return tile_encoded * np.exp(-1j * alpha * k2)

    def apply_linear_propagator(self, tile_complex: np.ndarray, alpha: float) -> np.ndarray:
        encoded = self._encode_state(tile_complex)
        evolved = self._apply_phase_k2(encoded, alpha)
        # In a real backend, decoding would map back from measurement or statevector
        return evolved


class HybridRFE:
    """Hybrid split-step (Strang) solver for a 2D cubic-NLS / GPE-like PDE.

    Model (dimensionless form):
        i ħ ∂t Ψ = - (ħ^2 / 2m) (∂xx + ∂yy) Ψ + g |Ψ|^2 Ψ + V_lock(θ) Ψ - i Γ Ψ

    Here we implement:
      - Linear (kinetic) step via spectral propagators along x and y.
      - Nonlinear local step with cubic term and a simple phase-lock potential term.
      - Strang splitting: half linear (x + y), full nonlinear, half linear (x + y).

    Parameters
    ----------
    shape : tuple[int, int]
        Grid shape (ny, nx).
    dt : float
        Time step.
    hbarc : float
        Effective ħ (can be 1 in normalized units).
    mc : float
        Effective mass (can be 1 in normalized units).
    g : float
        Cubic nonlinearity coefficient.
    V0 : float
        Locking potential amplitude.
    theta0 : float
        Reference phase for locking.
    Gamma : float
        Linear loss rate.
    backend_x : QuantumBackend
        Backend for spectral propagation along x on 1D tiles (rows).
    """

    def __init__(
        self,
        shape: tuple[int, int],
        dt: float = 1e-2,
        hbarc: float = 1.0,
        mc: float = 1.0,
        g: float = 1.0,
        V0: float = 0.0,
        theta0: float = 0.0,
        Gamma: float = 0.0,
        backend_x: Optional[QuantumBackend] = None,
    ) -> None:
        self.ny, self.nx = shape
        self.dt = float(dt)
        self.hbarc = float(hbarc)
        self.mc = float(mc)
        self.g = float(g)
        self.V0 = float(V0)
        self.theta0 = float(theta0)
        self.Gamma = float(Gamma)
        self.backend_x = backend_x if backend_x is not None else PhaseDrive()

        # Precompute y-direction spectral factors for efficiency
        self._ky = np.fft.fftfreq(self.ny)
        self._ky2 = self._ky**2

    # ----- linear steps -----
    def _kinetic_tile_x(self, Psi: np.ndarray, alpha: float) -> np.ndarray:
        """Apply exp(-i alpha ∂xx) via spectral phase along x, row by row using backend_x.
        alpha should be ħ dt / (2m).
        """
        out = np.empty_like(Psi, dtype=np.complex128)
        # FFT along x, apply backend phase, IFFT back.
        for j in range(self.ny):
            row = Psi[j, :]
            row_hat = np.fft.fft(row)
            row_hat = self.backend_x.apply_linear_propagator(row_hat, alpha)
            out[j, :] = np.fft.ifft(row_hat)
        return out

    def _kinetic_y_classical(self, Psi: np.ndarray, alpha: float) -> np.ndarray:
        """Apply exp(-i alpha ∂yy) via classical spectral phase along y."""
        Psi_hat = np.fft.fft(Psi, axis=0)      # FFT along y
        phase = np.exp(-1j * alpha * self._ky2)[:, None]
        Psi_hat *= phase
        return np.fft.ifft(Psi_hat, axis=0)

    # ----- nonlinear step -----
    def _nonlinear_step(self, Psi: np.ndarray) -> np.ndarray:
        """Local nonlinear update:
            Ψ -> Ψ * exp(-i dt / ħ * (g |Ψ|^2 + V_lock(θ))) * exp(-Γ dt)
        where V_lock(θ) ≈ (V0/2) sin(θ - θ0) / (|Ψ| + eps) couples phase to a reference.
        """
        eps = 1e-12
        mod2 = np.abs(Psi)**2
        theta = np.angle(Psi)
        term_g = self.g * mod2
        term_lock = (self.V0 * 0.5) * np.sin(theta - self.theta0) / (np.sqrt(mod2) + eps)
        phase = -(term_g + term_lock) * (self.dt / self.hbarc)
        return Psi * np.exp(1j * phase) * np.exp(-self.Gamma * self.dt)

    # ----- full step (Strang) -----
    def step(self, Psi: np.ndarray) -> np.ndarray:
        alpha = (self.hbarc * self.dt) / (2.0 * self.mc)
        Psi = self._kinetic_tile_x(Psi, alpha / 2.0)
        Psi = self._kinetic_y_classical(Psi, alpha / 2.0)
        Psi = self._nonlinear_step(Psi)
        Psi = self._kinetic_tile_x(Psi, alpha / 2.0)
        Psi = self._kinetic_y_classical(Psi, alpha / 2.0)
        return Psi
