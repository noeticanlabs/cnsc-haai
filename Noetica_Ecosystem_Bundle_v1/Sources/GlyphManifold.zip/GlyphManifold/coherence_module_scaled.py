# coherence_module_scaled.py — Reconstructed from LoC v6.0C
import numpy as np

class CoherenceModule:
    def __init__(self, shape=(128, 128)):
        self.shape = shape
        self.fields = {
            "C": np.zeros(shape)  # Coherence field
        }

    def step(self, theta, dtheta_dt, gamma=0.05, dt=0.001):
        grad_theta_x = np.roll(theta, -1, axis=1) - theta
        grad_theta_y = np.roll(theta, -1, axis=0) - theta
        grad_squared = grad_theta_x**2 + grad_theta_y**2

        S_phi = grad_squared                     # Constructive interference (source)
        D_gamma = gamma * (dtheta_dt**2)         # Dissipation (loss)

        dC_dt = S_phi - D_gamma
        self.fields["C"] += dt * dC_dt
        return self.fields["C"]
