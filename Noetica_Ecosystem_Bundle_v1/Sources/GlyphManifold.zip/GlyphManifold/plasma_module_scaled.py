# plasma_module_scaled.py with coherence feedback
import numpy as np

class PhysicsModule:
    def __init__(self, cfg):
        self.cfg = cfg
        self.qe = 1.602e-19
        self.D = 1e-2
        self.gamma_C = 1e-3  # coherence boost to drive
        self.dx = 0.01
        self.dt = min(cfg.dt, (self.dx**2) / (4 * self.D))
        self.fields = self.initialize()

    def initialize(self):
        print("[PlasmaModule (Scaled+Feedback)] Initializing: Charged blob + coherence-driven gain")
        field = np.zeros((128, 128))
        field[64, 64] = 1e16
        return field

    def laplacian(self, field):
        return (
            -4 * field +
            np.roll(field, 1, axis=0) +
            np.roll(field, -1, axis=0) +
            np.roll(field, 1, axis=1) +
            np.roll(field, -1, axis=1)
        ) / self.dx**2

    def step(self, fields, control_signal, coherence=None):
        theta = control_signal.get("theta", 0.0)
        laplace = self.laplacian(self.fields)

        nonlinear_drive = self.qe * np.tanh(self.fields / 1e17 + np.sin(theta))

        if coherence is not None:
            nonlinear_drive += self.gamma_C * coherence

        self.fields += self.dt * (self.D * laplace + nonlinear_drive)
        return self.fields
