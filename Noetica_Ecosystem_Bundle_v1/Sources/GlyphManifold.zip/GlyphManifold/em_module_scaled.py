# em_module_scaled.py with coherence feedback
import numpy as np

class PhysicsModule:
    def __init__(self, cfg):
        self.cfg = cfg
        self.epsilon_0 = 8.854e-12
        self.mu_0 = 4 * np.pi * 1e-7
        self.c = 1 / np.sqrt(self.epsilon_0 * self.mu_0)
        self.beta_C = 0.01  # feedback coupling
        self.dx = 0.01
        self.dt = min(cfg.dt, self.dx / (2 * self.c))
        self.fields = self.initialize()
        self.prev_fields = self.fields.copy()

    def initialize(self):
        print("[EMModule (Scaled+Feedback)] Initializing: Ez pulse + coherence-modulated drive")
        field = np.zeros((128, 128))
        field[64, 64] = 1.0
        return field

    def laplacian(self, field):
        return (
            -4 * field +
            np.roll(field, 1, axis=0) +
            np.roll(field, -1, axis=0) +
            np.roll(field, 1, axis=1) +
            np.roll(field, -1, axis=1)
        ) / self.dx**2

    def step(self, fields, control_signal, coherence=None):
        theta = control_signal.get("theta", 0.0)
        C_factor = 1 + self.beta_C * coherence if coherence is not None else 1

        laplace = self.laplacian(self.fields)
        new_field = (
            2 * self.fields - self.prev_fields +
            (self.dt**2) * (self.c**2 * laplace + np.sin(theta) * C_factor)
        )
        self.prev_fields = self.fields
        self.fields = new_field
        return self.fields
