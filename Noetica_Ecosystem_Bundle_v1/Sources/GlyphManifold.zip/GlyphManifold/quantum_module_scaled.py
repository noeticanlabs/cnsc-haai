# quantum_module_scaled.py with double-slit setup and coherence feedback
import numpy as np

class PhysicsModule:
    def __init__(self, cfg):
        self.cfg = cfg
        self.hbar = 1.055e-34
        self.m = 9.11e-31
        self.dx = 1e-9
        self.lambda_C = 1e-3
        self.dt = min(cfg.dt, (self.m * self.dx**2) / self.hbar)
        self.i = complex(0, 1)

        # Slit parameters
        self.barrier = np.ones((128, 128))
        slit_width = 4
        slit_gap = 12
        center = 64
        barrier_x = 48

        # Create slit mask: high potential (barrier), low at slits
        self.barrier[barrier_x, :] = 1000  # barrier height
        self.barrier[barrier_x,
            center - slit_gap//2 - slit_width : center - slit_gap//2 + slit_width
        ] = 0  # top slit
        self.barrier[barrier_x,
            center + slit_gap//2 - slit_width : center + slit_gap//2 + slit_width
        ] = 0  # bottom slit

        self.fields = self.initialize()

    def initialize(self):
        print("[QuantumModule (Double-Slit+Feedback)] Initializing: Wavepacket + slit barrier")
        x = np.linspace(-1, 1, 128) * self.dx * 64
        y = np.linspace(-1, 1, 128) * self.dx * 64
        X, Y = np.meshgrid(x, y)
        k0 = 5e9
        psi = np.exp(-((X + 30e-9)**2 + (Y)**2) / (2 * (5e-9)**2)) * np.exp(self.i * k0 * X)
        psi /= np.linalg.norm(psi)
        return psi

    def laplacian(self, field):
        return (
            -4 * field +
            np.roll(field, 1, axis=0) +
            np.roll(field, -1, axis=0) +
            np.roll(field, 1, axis=1) +
            np.roll(field, -1, axis=1)
        ) / self.dx**2

    def step(self, fields, control_signal, coherence=None):
        theta = control_signal.get("theta", 0.0)
        laplace = self.laplacian(self.fields)
        potential = self.barrier

        C_term = self.lambda_C * coherence * self.fields if coherence is not None else 0.0
        V_term = potential * self.fields

        self.fields += self.i * self.dt * (-self.hbar / (2 * self.m)) * laplace                        - self.i * self.dt * V_term + self.i * np.sin(theta) + C_term

        norm = np.linalg.norm(self.fields)
        if norm > 0:
            self.fields /= norm
        return self.fields
