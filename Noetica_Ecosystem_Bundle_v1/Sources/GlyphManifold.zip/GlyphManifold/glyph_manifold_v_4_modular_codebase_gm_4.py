# =============================================
# Glyph Manifold v4 — Modular Codebase (gm4)
# A clean, testable, and safe-by-default implementation
# =============================================
#
# Layout (single-file monorepo view; split into files in your project):
#   gm4/__init__.py
#   gm4/version.py
#   gm4/cfg.py
#   gm4/numerics.py
#   gm4/telemetry.py
#   gm4/checks.py
#   gm4/safety/governor.py
#   gm4/modules/fluid.py
#   gm4/modules/plasma.py
#   gm4/modules/thermo.py
#   gm4/modules/acoustic.py
#   gm4/modules/em.py
#   gm4/modules/quantum.py
#   gm4/engine.py
#   gm4/runner.py
#   examples/run_basic.py
#
# Copy each section into the corresponding file path.
# =============================================

# ------------------------------
# FILE: gm4/__init__.py
# ------------------------------
"""Glyph Manifold v4 (gm4): modular multiphysics sandbox.

This package provides a safe, testable framework for coupled phase-field
simulations with optional fluid, plasma, thermo, EM, acoustic, and quantum
noise modules. A stability governor and telemetry hooks are included.
"""
from .version import __version__

__all__ = ["__version__"]


# ------------------------------
# FILE: gm4/version.py
# ------------------------------
__version__ = "4.0.0"


# ------------------------------
# FILE: gm4/cfg.py
# ------------------------------
from dataclasses import dataclass

@dataclass
class CFG:
    # Global numeric settings
    dt: float = 1e-3
    dx: float = 1.0
    dy: float = 1.0
    steps: int = 200
    seed: int = 42

    # Phase-field parameters
    beta: float = 0.2          # gradient limiter weight
    kappa_opt: float = 1e-2    # Laplacian (diffusion-like) weight
    mu: float = 0.01           # phase potential depth

    # Wave / acoustic
    c: float = 1.0             # wave speed

    # Quantum noise
    q_noise_std: float = 1e-2

    # EM optics proxy
    alpha_opt: float = 1e-3

    # Safety thresholds
    max_grad2: float = 100.0
    min_coherence: float = 0.02

    # Telemetry
    log_every: int = 10
    out_dir: str = "outputs"

    # Unit system (informational)
    units: str = "dimensionless"


# ------------------------------
# FILE: gm4/numerics.py
# ------------------------------
import numpy as np

Array = np.ndarray

def wrap_angle(a: Array) -> Array:
    return (a + np.pi) % (2*np.pi) - np.pi

def grad_center(f: Array, dx: float, dy: float):
    dfx = (np.roll(f, -1, 0) - np.roll(f, 1, 0)) / (2*dx)
    dfy = (np.roll(f, -1, 1) - np.roll(f, 1, 1)) / (2*dy)
    return dfx, dfy

def laplacian(f: Array, dx: float, dy: float) -> Array:
    return ((np.roll(f, -1, 0) - 2*f + np.roll(f, 1, 0)) / dx**2 +
            (np.roll(f, -1, 1) - 2*f + np.roll(f, 1, 1)) / dy**2)

def poisson_periodic(rhs: Array, dx: float, dy: float) -> Array:
    # Solve ∇²ψ = rhs with periodic BC via FFT
    nx, ny = rhs.shape
    kx = 2*np.pi*np.fft.fftfreq(nx, d=dx)
    ky = 2*np.pi*np.fft.fftfreq(ny, d=dy)
    KX, KY = np.meshgrid(kx, ky, indexing='ij')
    K2 = KX**2 + KY**2
    rhs_hat = np.fft.fft2(rhs)
    psi_hat = np.zeros_like(rhs_hat, dtype=complex)
    mask = K2 != 0
    psi_hat[mask] = -rhs_hat[mask] / K2[mask]
    psi = np.fft.ifft2(psi_hat)
    return psi.real


def rk2_heun(theta: Array, rhs_fn, dt: float):
    # Heun's method for θ̇ = f(θ)
    k1 = rhs_fn(theta)
    k2 = rhs_fn(theta + dt*k1)
    return theta + 0.5*dt*(k1 + k2)


# ------------------------------
# FILE: gm4/telemetry.py
# ------------------------------
import os
import csv
import numpy as np
from .numerics import wrap_angle

class Telemetry:
    def __init__(self, out_dir: str):
        self.out_dir = out_dir
        os.makedirs(out_dir, exist_ok=True)
        self.csv_path = os.path.join(out_dir, "metrics.csv")
        with open(self.csv_path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["step", "coherence_r", "max_grad2"])  # extend as needed

    @staticmethod
    def coherence(theta: np.ndarray) -> float:
        U = np.exp(1j*theta)
        return float(np.abs(np.mean(U)))

    @staticmethod
    def max_grad2(theta: np.ndarray, dx: float, dy: float) -> float:
        from .numerics import grad_center
        dtx, dty = grad_center(theta, dx, dy)
        return float(np.max(dtx*dtx + dty*dty))

    def log(self, step: int, theta: np.ndarray, dx: float, dy: float):
        r = self.coherence(theta)
        gmax = self.max_grad2(theta, dx, dy)
        with open(self.csv_path, "a", newline="") as f:
            w = csv.writer(f)
            w.writerow([step, r, gmax])


# ------------------------------
# FILE: gm4/checks.py
# ------------------------------
import numpy as np
from .telemetry import Telemetry

class CoherenceChecks:
    def __init__(self, min_coherence: float, max_grad2: float):
        self.min_coherence = min_coherence
        self.max_grad2 = max_grad2

    def evaluate(self, theta: np.ndarray, dx: float, dy: float):
        r = Telemetry.coherence(theta)
        gmax = Telemetry.max_grad2(theta, dx, dy)
        status = {
            "ok": (r >= self.min_coherence) and (gmax <= self.max_grad2),
            "r": r,
            "gradmax": gmax,
            "violations": {
                "low_coherence": r < self.min_coherence,
                "grad_spike": gmax > self.max_grad2,
            }
        }
        return status


# ------------------------------
# FILE: gm4/safety/governor.py
# ------------------------------
import numpy as np
from dataclasses import dataclass

@dataclass
class Guardrails:
    max_grad2: float
    min_coherence: float
    max_gain: float = 1.0

class Governor:
    """Stability governor that clamps source terms and gains based on metrics."""
    def __init__(self, guards: Guardrails):
        self.g = guards

    def clamp_gain(self, gain: float, r: float, gradmax: float) -> float:
        # Reduce gain if coherence drops or gradients spike
        scale = 1.0
        if r < self.g.min_coherence:
            scale *= max(0.2, r / max(self.g.min_coherence, 1e-9))
        if gradmax > self.g.max_grad2:
            scale *= max(0.2, self.g.max_grad2 / (gradmax + 1e-9))
        return float(min(gain * scale, self.g.max_gain))


# ------------------------------
# FILE: gm4/modules/fluid.py
# ------------------------------
import numpy as np
from ..numerics import grad_center

def pressure_field(rho: np.ndarray, T: np.ndarray) -> np.ndarray:
    return rho * T

def momentum_source_from_pressure(theta: np.ndarray, rho: np.ndarray, T: np.ndarray, dx: float, dy: float) -> np.ndarray:
    P = pressure_field(rho, T)
    dPx, dPy = grad_center(P, dx, dy)
    return -0.5*(dPx + dPy)


# ------------------------------
# FILE: gm4/modules/plasma.py
# ------------------------------
import numpy as np
from scipy.constants import mu_0
from ..numerics import grad_center

def plasma_beta(P: np.ndarray, Bx: np.ndarray, By: np.ndarray, Bz: np.ndarray | None = None) -> np.ndarray:
    B2 = Bx*Bx + By*By + (0.0 if Bz is None else Bz*Bz)
    return P / (B2/(2.0*mu_0) + 1e-16)

def em_tension_proxy(Bx: np.ndarray, By: np.ndarray, alpha_opt: float, dx: float, dy: float) -> np.ndarray:
    Bmag = np.sqrt(Bx*Bx + By*By) + 1e-12
    dBx, dBy = grad_center(Bmag, dx, dy)
    return -alpha_opt * (dBx + dBy)


# ------------------------------
# FILE: gm4/modules/thermo.py
# ------------------------------
import numpy as np
from ..numerics import laplacian

def temperature_from_energy(energy: np.ndarray, rho: np.ndarray) -> np.ndarray:
    return energy / (rho + 1e-12)

def thermal_diffusion(T: np.ndarray, kappa_T: float, dx: float, dy: float) -> np.ndarray:
    return kappa_T * laplacian(T, dx, dy)


# ------------------------------
# FILE: gm4/modules/acoustic.py
# ------------------------------
import numpy as np
from ..numerics import laplacian

def acoustic_wave_term(theta: np.ndarray, c: float, dx: float, dy: float) -> np.ndarray:
    return (c**2) * laplacian(theta, dx, dy)


# ------------------------------
# FILE: gm4/modules/em.py
# ------------------------------
import numpy as np

# Placeholder for future EM layer (Maxwell coupling)
# Here, we provide stubs consistent with the interface.

def poynting_divergence_stub(theta: np.ndarray) -> np.ndarray:
    return np.zeros_like(theta)


# ------------------------------
# FILE: gm4/modules/quantum.py
# ------------------------------
import numpy as np

def quantum_noise(shape: tuple[int, int], std: float) -> np.ndarray:
    return np.random.normal(scale=std, size=shape)


# ------------------------------
# FILE: gm4/engine.py
# ------------------------------
import numpy as np
from .numerics import grad_center, laplacian, wrap_angle
from .modules.acoustic import acoustic_wave_term
from .modules.fluid import momentum_source_from_pressure
from .modules.plasma import em_tension_proxy
from .modules.quantum import quantum_noise

class Engine:
    """Compute RHS for the phase field and provide a stepper with safety hooks."""
    def __init__(self, cfg, governor=None):
        self.cfg = cfg
        self.gov = governor

    def rhs(self, theta: np.ndarray, rho: np.ndarray, T: np.ndarray, Bx: np.ndarray, By: np.ndarray) -> np.ndarray:
        dx, dy = self.cfg.dx, self.cfg.dy
        # Geometry terms
        dtx, dty = grad_center(theta, dx, dy)
        grad2 = dtx*dtx + dty*dty
        lap = laplacian(theta, dx, dy)
        rhs_geom = -self.cfg.beta * (grad2/(1.0 + grad2)) + self.cfg.kappa_opt * lap - self.cfg.mu*np.sin(2.0*theta)
        # Acoustic
        rhs_ac = acoustic_wave_term(theta, self.cfg.c, dx, dy)
        # Fluid pressure coupling (proxy to phase forcing)
        rhs_fluid = momentum_source_from_pressure(theta, rho, T, dx, dy)
        # EM curvature/tension proxy
        rhs_em = em_tension_proxy(Bx, By, self.cfg.alpha_opt, dx, dy)
        # Quantum noise
        rhs_q = quantum_noise(theta.shape, self.cfg.q_noise_std)
        # Combine
        rhs = rhs_geom + rhs_ac + rhs_fluid + rhs_em + rhs_q
        return rhs

    def step(self, theta: np.ndarray, rho: np.ndarray, T: np.ndarray, Bx: np.ndarray, By: np.ndarray):
        dt = self.cfg.dt
        dx, dy = self.cfg.dx, self.cfg.dy
        # Build a closure for RK2
        def f(th):
            return self.rhs(th, rho, T, Bx, By)
        # Heun's method
        k1 = f(theta)
        k2 = f(theta + dt*k1)
        theta_new = theta + 0.5*dt*(k1 + k2)
        theta_new = wrap_angle(theta_new)
        return theta_new


# ------------------------------
# FILE: gm4/runner.py
# ------------------------------
import os
import numpy as np
from .cfg import CFG
from .engine import Engine
from .telemetry import Telemetry
from .checks import CoherenceChecks
from .safety.governor import Governor, Guardrails

class Runner:
    def __init__(self, cfg: CFG, shape=(128,128)):
        self.cfg = cfg
        self.shape = shape
        np.random.seed(cfg.seed)
        # Fields
        self.theta = np.random.uniform(-np.pi, np.pi, size=shape)
        self.rho = np.ones(shape) * 1.0   # dimensionless density
        self.T = np.ones(shape) * 0.1     # dimensionless temperature
        self.Bx = np.ones(shape) * 0.1
        self.By = np.ones(shape) * 0.1
        # Safety & telemetry
        self.tel = Telemetry(cfg.out_dir)
        self.checks = CoherenceChecks(cfg.min_coherence, cfg.max_grad2)
        guards = Guardrails(max_grad2=cfg.max_grad2, min_coherence=cfg.min_coherence, max_gain=1.0)
        self.gov = Governor(guards)
        self.engine = Engine(cfg, governor=self.gov)

    def run(self):
        os.makedirs(self.cfg.out_dir, exist_ok=True)
        for step in range(self.cfg.steps):
            # Compute next θ
            theta_next = self.engine.step(self.theta, self.rho, self.T, self.Bx, self.By)
            # Safety check
            status = self.checks.evaluate(theta_next, self.cfg.dx, self.cfg.dy)
            # If unstable, damp by clamping noise/couplings via governor (simple demo: linear blend)
            if not status["ok"]:
                r = status["r"]; g = status["gradmax"]
                # Blend toward previous stable state
                blend = self.gov.clamp_gain(1.0, r, g)
                theta_next = (1.0 - (1.0 - blend))*theta_next + (1.0 - blend)*self.theta
            # Commit
            self.theta = theta_next
            # Log
            if step % self.cfg.log_every == 0:
                self.tel.log(step, self.theta, self.cfg.dx, self.cfg.dy)
        # Save final state
        np.savez(os.path.join(self.cfg.out_dir, "final_state.npz"), theta=self.theta)
        return self.theta


# ------------------------------
# FILE: examples/run_basic.py
# ------------------------------
from gm4.cfg import CFG
from gm4.runner import Runner

if __name__ == "__main__":
    cfg = CFG(
        dt=5e-3,
        dx=1.0,
        dy=1.0,
        steps=400,
        seed=123,
        beta=0.2,
        kappa_opt=8e-3,
        mu=0.02,
        c=0.8,
        q_noise_std=5e-3,
        alpha_opt=5e-4,
        max_grad2=80.0,
        min_coherence=0.015,
        log_every=20,
        out_dir="outputs_basic",
        units="dimensionless"
    )
    sim = Runner(cfg, shape=(128,128))
    sim.run()
    print("[gm4] Done. Metrics in outputs_basic/metrics.csv; field in outputs_basic/final_state.npz")


# ------------------------------
# FILE: gm4/modules/recursion.py
# ------------------------------
import numpy as np
from ..numerics import laplacian

class Recursion:
    """Optional self-reflection term: ∂tθ += λ_r ∇²C, where C = |⟨e^{iθ}⟩|^2 at scale σ.
    Safe by default (λ_r=0). Includes internal gain clamp to stay below λ_r*.
    """
    def __init__(self, lambda_r: float = 0.0, sigma: float = 3.0, max_lambda_r: float = 0.5):
        self.lambda_r = float(lambda_r)
        self.sigma = float(sigma)
        self.max_lambda_r = float(max_lambda_r)

    def _gaussian_fft(self, nx, ny, sigma):
        x = np.arange(-nx//2, nx//2)
        y = np.arange(-ny//2, ny//2)
        X, Y = np.meshgrid(x, y, indexing='ij')
        G = np.exp(-(X**2 + Y**2)/(2.0*sigma**2)); G /= G.sum()
        return np.fft.fft2(np.fft.ifftshift(G))

    def coherence_map(self, theta: np.ndarray) -> np.ndarray:
        U = np.exp(1j*theta)
        nx, ny = theta.shape
        Gk = self._gaussian_fft(nx, ny, self.sigma)
        Us = np.fft.ifft2(np.fft.fft2(U) * Gk)
        C = np.abs(Us)**2
        return C.real

    def rhs_term(self, theta: np.ndarray, dx: float, dy: float, safe_gain: float) -> np.ndarray:
        lam = min(self.lambda_r, self.max_lambda_r) * safe_gain
        if lam <= 0.0:
            return np.zeros_like(theta)
        C = self.coherence_map(theta)
        return lam * laplacian(C, dx, dy)


# ------------------------------
# FILE: gm4/mpc.py
# ------------------------------
import numpy as np
from .numerics import wrap_angle

class MPCPreview:
    """Tiny model-predictive preview: roll N mini-steps with a provided f(θ) and dt/N.
    Reject update if preview metrics cross guard thresholds.
    """
    def __init__(self, steps_ahead:int=3):
        self.steps_ahead = int(steps_ahead)

    def preview(self, theta, f, dt, checker, dx, dy):
        th = theta.copy()
        mini_dt = dt / self.steps_ahead
        for _ in range(self.steps_ahead):
            k1 = f(th)
            k2 = f(th + mini_dt*k1)
            th = wrap_angle(th + 0.5*mini_dt*(k1 + k2))
            status = checker.evaluate(th, dx, dy)
            if not status["ok"]:
                return False, status
        return True, checker.evaluate(th, dx, dy)


# ------------------------------
# FILE: gm4/numerics.py (ADD FFT Laplacian option)
# ------------------------------
# Append to bottom of file

def laplacian_fft(f: np.ndarray, dx: float, dy: float) -> np.ndarray:
    nx, ny = f.shape
    kx = 2*np.pi*np.fft.fftfreq(nx, d=dx)
    ky = 2*np.pi*np.fft.fftfreq(ny, d=dy)
    KX, KY = np.meshgrid(kx, ky, indexing='ij')
    K2 = KX**2 + KY**2
    F = np.fft.fft2(f)
    out_hat = -K2 * F
    out = np.fft.ifft2(out_hat)
    return out.real


# ------------------------------
# FILE: gm4/engine.py (wire recursion + selectable Laplacian)
# ------------------------------
# Insert after imports
from .modules.recursion import Recursion
from .mpc import MPCPreview
from .telemetry import Telemetry

# Modify Engine to accept options
class Engine:
    def __init__(self, cfg, governor=None, recursion: Recursion|None=None, use_fft_laplace: bool=False, mpc_preview: MPCPreview|None=None, checks=None):
        self.cfg = cfg
        self.gov = governor
        self.rec = recursion
        self.use_fft = use_fft_laplace
        self.mpc = mpc_preview
        self.checks = checks

    def _lap(self, f, dx, dy):
        from .numerics import laplacian, laplacian_fft
        return laplacian_fft(f, dx, dy) if self.use_fft else laplacian(f, dx, dy)

    def rhs(self, theta: np.ndarray, rho: np.ndarray, T: np.ndarray, Bx: np.ndarray, By: np.ndarray) -> np.ndarray:
        dx, dy = self.cfg.dx, self.cfg.dy
        from .numerics import grad_center
        dtx, dty = grad_center(theta, dx, dy)
        grad2 = dtx*dtx + dty*dty
        lap = self._lap(theta, dx, dy)
        rhs_geom = -self.cfg.beta * (grad2/(1.0 + grad2)) + self.cfg.kappa_opt * lap - self.cfg.mu*np.sin(2.0*theta)
        from .modules.acoustic import acoustic_wave_term
        rhs_ac = acoustic_wave_term(theta, self.cfg.c, dx, dy)
        from .modules.fluid import momentum_source_from_pressure
        rhs_fluid = momentum_source_from_pressure(theta, rho, T, dx, dy)
        from .modules.plasma import em_tension_proxy
        rhs_em = em_tension_proxy(Bx, By, self.cfg.alpha_opt, dx, dy)
        from .modules.quantum import quantum_noise
        rhs_q = quantum_noise(theta.shape, self.cfg.q_noise_std)
        rhs = rhs_geom + rhs_ac + rhs_fluid + rhs_em + rhs_q
        # Optional recursion term with safe gain based on telemetry
        if self.rec is not None:
            r = Telemetry.coherence(theta)
            g = Telemetry.max_grad2(theta, dx, dy)
            safe = self.gov.clamp_gain(1.0, r, g) if self.gov else 1.0
            rhs += self.rec.rhs_term(theta, dx, dy, safe)
        return rhs

    def step(self, theta: np.ndarray, rho: np.ndarray, T: np.ndarray, Bx: np.ndarray, By: np.ndarray):
        dt = self.cfg.dt
        def f(th): return self.rhs(th, rho, T, Bx, By)
        # MPC preview if enabled
        if self.mpc and self.checks:
            ok, _ = self.mpc.preview(theta, f, dt, self.checks, self.cfg.dx, self.cfg.dy)
            if not ok:
                # halve dt for this step as a safe fallback
                dt *= 0.5
        # Heun
        k1 = f(theta)
        k2 = f(theta + dt*k1)
        from .numerics import wrap_angle
        theta_new = wrap_angle(theta + 0.5*dt*(k1 + k2))
        return theta_new


# ------------------------------
# FILE: gm4/runner.py (enable options + config hash)
# ------------------------------
# Replace Runner.__init__ body to add recursion + mpc + fft switch
import hashlib, json

class Runner:
    def __init__(self, cfg: CFG, shape=(128,128), enable_recursion=False, lambda_r=0.0, use_fft=False, mpc_steps=0):
        self.cfg = cfg
        self.shape = shape
        np.random.seed(cfg.seed)
        self.theta = np.random.uniform(-np.pi, np.pi, size=shape)
        self.rho = np.ones(shape) * 1.0
        self.T   = np.ones(shape) * 0.1
        self.Bx  = np.ones(shape) * 0.1
        self.By  = np.ones(shape) * 0.1
        self.tel = Telemetry(cfg.out_dir)
        self.checks = CoherenceChecks(cfg.min_coherence, cfg.max_grad2)
        guards = Guardrails(max_grad2=cfg.max_grad2, min_coherence=cfg.min_coherence, max_gain=1.0)
        self.gov = Governor(guards)
        rec = None
        if enable_recursion:
            from .modules.recursion import Recursion
            rec = Recursion(lambda_r=lambda_r, sigma=3.0, max_lambda_r=0.5)
        mpc = None
        if mpc_steps and mpc_steps > 0:
            from .mpc import MPCPreview
            mpc = MPCPreview(steps_ahead=mpc_steps)
        self.engine = Engine(cfg, governor=self.gov, recursion=rec, use_fft_laplace=use_fft, mpc_preview=mpc, checks=self.checks)
        # Save a config hash for provenance
        chash = hashlib.sha256(json.dumps(cfg.__dict__, sort_keys=True).encode()).hexdigest()[:12]
        with open(os.path.join(cfg.out_dir, "config.json"), "w") as f:
            json.dump({"cfg": cfg.__dict__, "config_hash": chash, "shape": shape, "options": {"recursion": enable_recursion, "lambda_r": lambda_r, "use_fft": use_fft, "mpc_steps": mpc_steps}}, f, indent=2)

# ensure run() unchanged except it uses self.engine as before

# ------------------------------
# FILE: examples/run_recursion.py
# ------------------------------
from gm4.cfg import CFG
from gm4.runner import Runner

if __name__ == "__main__":
    cfg = CFG(out_dir="outputs_recursion", steps=500, dt=4e-3, kappa_opt=1e-2, q_noise_std=4e-3)
    sim = Runner(cfg, shape=(128,128), enable_recursion=True, lambda_r=0.35, use_fft=True, mpc_steps=3)
    sim.run()
    print("[gm4] Recursion demo complete. See outputs_recursion/")

# ------------------------------
# FILE: tests/test_sanity.py
# ------------------------------
import numpy as np
from gm4.cfg import CFG
from gm4.runner import Runner

def test_runs_and_logs(tmp_path):
    cfg = CFG(out_dir=str(tmp_path/"out"), steps=20, dt=1e-2)
    sim = Runner(cfg, shape=(64,64))
    th = sim.run()
    assert th.shape == (64,64)
    # CSV created
    import os
    assert os.path.exists(tmp_path/"out"/"metrics.csv")

