# acoustic_module_scaled.py with coherence feedback
import numpy as np

class PhysicsModule:
    def __init__(self, cfg):
        self.cfg = cfg
        self.rho = 1.21
        self.c_sound = 343.0
        self.eta_C = 1e-2  # coherence-amplified driving term
        self.dx = 0.01
        self.dt = min(cfg.dt, self.dx / (2 * self.c_sound))
        self.fields = self.initialize()
        self.prev_fields = self.fields.copy()

    def initialize(self):
        print("[AcousticModule (Scaled+Feedback)] Initializing: Pressure + coherence-amplified wavefront")
        field = np.zeros((128, 128))
        field[64, 64] = 100.0
        return field

    def laplacian(self, field):
        return (
            -4 * field +
            np.roll(field, 1, axis=0) +
            np.roll(field, -1, axis=0) +
            np.roll(field, 1, axis=1) +
            np.roll(field, -1, axis=1)
        ) / self.dx**2

    def step(self, fields, control_signal, coherence=None):
        theta = control_signal.get("theta", 0.0)
        laplace = self.laplacian(self.fields)

        source_term = 10 * np.sin(theta)
        if coherence is not None:
            source_term += self.eta_C * coherence

        new_field = (
            2 * self.fields - self.prev_fields +
            self.dt**2 * (self.c_sound**2 * laplace + source_term)
        )

        self.prev_fields = self.fields
        self.fields = new_field
        return self.fields
