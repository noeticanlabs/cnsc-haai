# fluid_module_scaled.py with coherence feedback
import numpy as np

class PhysicsModule:
    def __init__(self, cfg):
        self.cfg = cfg
        self.nu = 1e-3  # viscosity (m²/s)
        self.beta_C = 0.01  # feedback strength
        self.dx = 0.01
        self.dt = min(cfg.dt, (self.dx**2) / (4 * self.nu))
        self.u = np.zeros((128, 128))
        self.v = np.zeros((128, 128))
        self.initialize()

    def initialize(self):
        print("[FluidModule (Scaled+Feedback)] Initializing: Central vortex + coherence boost")
        cx, cy = 64, 64
        for x in range(128):
            for y in range(128):
                dx = x - cx
                dy = y - cy
                r2 = dx**2 + dy**2
                if r2 < 100:
                    mag = 1 / np.sqrt(r2 + 1e-5)
                    self.u[x, y] = -dy * mag
                    self.v[x, y] = dx * mag

    def laplacian(self, field):
        return (
            -4 * field +
            np.roll(field, 1, axis=0) +
            np.roll(field, -1, axis=0) +
            np.roll(field, 1, axis=1) +
            np.roll(field, -1, axis=1)
        ) / self.dx**2

    def step(self, fields, control_signal, coherence=None):
        theta = control_signal.get("theta", 0.0)
        C_boost = self.beta_C * coherence if coherence is not None else 0.0

        self.u += self.dt * (self.nu * self.laplacian(self.u) + 0.01 * np.sin(theta) + C_boost)
        self.v += self.dt * (self.nu * self.laplacian(self.v) + 0.01 * np.cos(theta) + C_boost)

        return np.sqrt(self.u**2 + self.v**2)
