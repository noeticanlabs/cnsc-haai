
from __future__ import annotations
# HybridRFE Adapter v2 — plugs real solver into the Canvas runner
import math, time, numpy as np, importlib, sys
from typing import Dict, Any
sys.path.append("/mnt/data")
ccf = importlib.import_module("coherence_contract_framework_v_1")

# Try to import the user's module (assumes earlier best-practice patches applied)
try:
    gqm = importlib.import_module("glyph_quantum_hybrid_module")
except Exception as e:
    # Fallback: try patched in-memory load like earlier sessions (optional)
    raise RuntimeError("Could not import glyph_quantum_hybrid_module; apply the best-practice patch first.") from e

def _gaussian_state(nx:int, ny:int):
    x = np.linspace(-2.0, 2.0, nx)
    y = np.linspace(-2.0, 2.0, ny)
    X, Y = np.meshgrid(x, y, indexing="ij")
    Psi = np.exp(-(X**2 + Y**2)/(2*0.5**2)) * np.exp(1j*2.0*X)
    Psi = Psi / (np.linalg.norm(Psi) + 1e-18)
    return Psi.astype(np.complex128)

class HybridRFEAdapter(ccf.CoherentModule):
    name = "hybrid_rfe"

    def __init__(self, steps:int=64):
        self.steps = steps
        self._schema_in  = {"nx":"int","ny":"int","dt":"float","backend":"str","tile_n":"int","g":"float","Gamma":"float","T_flow":"float","q":"float"}
        self._schema_out = {"Psi":"list","CI":"float","drift":"float","runtime_ms":"float"}
        self._phase = ccf.PhaseState(version="2.1", schema_hash=ccf.stable_hash([self._schema_in, self._schema_out]), invariants={"stability":"|drift|<1e-4"})
        self._lat = ccf.SMA(20); self._err=0; self._cache_hit=ccf.SMA(20)

    def phase(self): return self._phase
    def input_schema(self): return self._schema_in
    def output_schema(self): return self._schema_out
    def metrics(self):
        return ccf.CoherenceMetrics(phase_curvature=0.03, energy=self._lat.mean(), latency_ms=self._lat.mean(), error_rate=self._err, cache_hit=self._cache_hit.mean())

    def _make_backend(self, backend_spec: str, tile_n: int):
        # Prefer make_backend if present
        if hasattr(gqm, "make_backend"):
            return gqm.make_backend(backend_spec, tile_n)
        # Fallback: only support phasedrive directly
        if str(backend_spec).lower() in ("phasedrive","phase","pd", "none", ""):
            return gqm.PhaseDrive(int(np.log2(tile_n)))
        raise ValueError("Backend %r not supported without make_backend()" % backend_spec)

    def call(self, payload: Dict[str, Any], *, intent: str | None = None) -> Dict[str, Any]:
        t0 = time.perf_counter()
        nx = int(payload.get("nx",64)); ny = int(payload.get("ny",64))
        dt = float(payload.get("dt",0.04)); tile_n = int(payload.get("tile_n",32))
        backend_spec = str(payload.get("backend","phasedrive"))
        g = float(payload.get("g",0.0)); Gamma = float(payload.get("Gamma",0.0))
        T_flow = float(payload.get("T_flow",0.0)); q = float(payload.get("q",0.0))

        # Map TE/committor hints into gentle parameter nudges (bounded)
        g_eff = g + 0.2*min(1.0, max(0.0, T_flow))
        Gamma_eff = max(0.0, Gamma + 0.1*(1.0 - q))

        backend = self._make_backend(backend_spec, tile_n)
        model = gqm.HybridRFE(nx, ny, 1.0, 1.0, dt, g=g_eff, Gamma=Gamma_eff, backend=backend, tile_n=tile_n)

        Psi0 = _gaussian_state(nx, ny)
        norm0 = float(np.linalg.norm(Psi0))
        Psi = Psi0.copy()
        for _ in range(self.steps):
            Psi = model.step(Psi)
        normT = float(np.linalg.norm(Psi))
        drift = (normT - norm0) / (norm0 + 1e-18)

        dt_ms = (time.perf_counter() - t0)*1000.0
        self._lat.add(dt_ms)

        # slice a small patch to keep payload light
        sl = Psi[:min(4,nx), :min(4,ny)]
        # crude CI proxy: normalized inverse gradient energy
        gy, gx = np.gradient(np.abs(Psi))
        ci = float(1.0 / (1.0 + 0.1*(np.mean(gx**2) + np.mean(gy**2))))

        return {"Psi": [[float(np.real(z)), float(np.imag(z))] for z in sl.reshape(-1)],
                "CI": ci, "drift": float(drift), "runtime_ms": float(dt_ms)}
