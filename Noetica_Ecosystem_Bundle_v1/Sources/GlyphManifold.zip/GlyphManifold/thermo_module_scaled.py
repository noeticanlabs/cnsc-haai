# Fully patched thermo_module_scaled.py with functional heat diffusion
import numpy as np

class PhysicsModule:
    def __init__(self, cfg):
        self.cfg = cfg
        self.kappa_2 = 1e-4  # will be overwritten by driver
        self.dx = 0.01
        self.dt = cfg.dt

    def initialize(self):
        print("[ThermoModule (Fixed)] Initializing: 100 K hot spot at center")
        field = np.zeros((128, 128))
        field[64, 64] = 100.0
        return field

    def laplacian(self, field):
        return (
            -4 * field +
            np.roll(field, 1, axis=0) +
            np.roll(field, -1, axis=0) +
            np.roll(field, 1, axis=1) +
            np.roll(field, -1, axis=1)
        ) / self.dx**2

    def step(self, fields, control_signal, coherence=None):
        laplace = self.laplacian(fields)
        return fields + self.dt * (self.kappa_2 * laplace)
