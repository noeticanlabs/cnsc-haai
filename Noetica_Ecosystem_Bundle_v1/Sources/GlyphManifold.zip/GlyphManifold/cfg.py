# cfg.py — Configuration for Law of Coherence + RFE Simulator

CONFIG = {
    # --- Physical Constants ---
    "c": 1.0,                   # wave speed (normalized units)
    "V0": 1.0,                  # strength of phase-locking potential
    "theta0": 0.0,              # equilibrium phase
    "gamma": 0.05,              # damping coefficient
    "D": 0.01,                  # diffusion coefficient

    # --- Simulation Parameters ---
    "Lx": 10.0,                 # spatial domain size (x)
    "Nx": 256,                  # spatial resolution
    "T": 20.0,                  # total simulation time
    "dt": 0.01,                 # time step size

    # --- Source Term ---
    "source_type": "pulse",     # options: 'none', 'pulse', 'sin', 'random'
    "pulse_position": 5.0,
    "pulse_amplitude": 1.0,
    "pulse_width": 0.2,

    # --- Boundary Conditions ---
    "boundary": "periodic",     # options: 'dirichlet', 'neumann', 'periodic'

    # --- Output Options ---
    "save_interval": 100,       # how often to save frames
    "plot_live": True,          # show live plots during simulation
    "output_dir": "./output",   # where to save results

    # --- LoC Parameters ---
    "track_coherence": True,
    "delta_top_injection": True, # topological injection allowed?
    "coherence_metric": "gradient_sq",  # options: 'gradient_sq', 'flux_dot'

    # --- Numerical Stability ---
    "safety_factor": 0.8         # CFL safety factor for stability
}


# Derived Parameters (computed on load)
def compute_derived(cfg):
    cfg["dx"] = cfg["Lx"] / cfg["Nx"]
    cfg["Nt"] = int(cfg["T"] / cfg["dt"])
    cfg["x"] = [i * cfg["dx"] for i in range(cfg["Nx"])]
    return cfg

CONFIG = compute_derived(CONFIG)
