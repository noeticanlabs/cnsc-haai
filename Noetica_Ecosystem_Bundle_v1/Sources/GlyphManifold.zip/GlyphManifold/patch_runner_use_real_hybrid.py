
# Create an updated runner that uses the HybridRFEAdapter instead of the stub
import json, yaml
from pathlib import Path
from typing import Dict, Any
import importlib, sys
sys.path.append("/mnt/data")
from coherence_contract_framework_v_1 import CoherenceModule if False else None  # placeholder
from hybrid_rfe_adapter_v2 import HybridRFEAdapter

def patch_runner_use_real_hybrid(in_path="/mnt/data/glyph_manifold_runner_v2_1.py", out_path="/mnt/data/glyph_manifold_runner_v2_1_real.py"):
    # Read the original runner and replace the stub builder for 'hybrid_rfe'
    text = Path(in_path).read_text()
    # naive but effective replacement: swap class name in build_modules dict
    text = text.replace('    "hybrid_rfe": HybridRFEStub(),', '    "hybrid_rfe": HybridRFEAdapter(),')
    Path(out_path).write_text(text)
    return out_path

if __name__ == "__main__":
    p = patch_runner_use_real_hybrid()
    print("Patched runner saved to:", p)
