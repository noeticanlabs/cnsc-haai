# Chemistry Micro‑Database (Expanded, ~5–10% of list)

Curated subset inspired by **kjappelbaum/awesome‑chemistry‑datasets** — focused on datasets that plug neatly into **CoherenceLab + MAC** for physics‑guided simulations and benchmarking. Each entry has a one‑liner on how to use it in parameter sweeps, validation, or surrogate training.

---

## Text & Knowledge Bases
- **BC5CDR** — Chemical–Disease relation corpus. *Use*: Mine chemical entity co‑mentions to seed reaction channels or hazard tags in experiment YAML.
- **Europe PMC** — Full‑text literature. *Use*: Build keyword priors (e.g., solvent names, electrolyte salts) for MAC sweep recipes.
- **PubChem** — Compounds + bioassays. *Use*: Pull distributions over properties (logP, TPSA) to parameterize diffusivity/partitioning in sandbox.

## Molecular Structure & Properties
- **QM9** — ~134k small organics with DFT properties. *Use*: Train/validate surrogate mappings from structure → polarizability or hardness (affects field coupling).
- **MoleculeNet: ESOL** — Solubility data. *Use*: Map solubility to effective reaction partitioning; compare diffusion‑limited vs reaction‑limited regimes.
- **MoleculeNet: FreeSolv** — Hydration free energies. *Use*: Benchmark solvent effects; calibrate field‑assisted reaction gains vs ΔG_hyd.
- **MoleculeNet: Lipophilicity** — Octanol/water partition. *Use*: Parameterize multi‑phase diffusion with MAC (membrane‑like barriers).
- **ChEMBL** — Bioactivity (targets/ligands). *Use*: Sample association/dissociation rates for toy kinetics with field modulation.
- **ZINC22** — Commercial compound library. *Use*: Generate molecular panels for property distributions (size, charge).

## Reactions
- **USPTO (Lowe/MIT)** — Extracted reactions from patents. *Use*: Empirical priors on yields/conditions; drive reaction‑rate distributions in A+B⇌C tests.
- **Open Reaction Database (ORD)** — Structured, schema‑driven reaction records. *Use*: Directly ingest to parameterize k_f/k_r vs solvent/base/temp.

## Spectroscopy
- **NMRShiftDB** — Open NMR shifts. *Use*: Validate field‑induced shielding trends (qualitative) or teach surrogates a structure→response map.
- **MassBank** — Open mass spectra. *Use*: Sanity‑check fragmentation‑like signals from pulse experiments (qualitative comparison).

## Biochemical Binding
- **BindingDB** — Binding affinities and kinetics. *Use*: Set distributions for k_on/k_off in manifold‑guided association kinetics.
- **PDBbind** — Protein–ligand complexes with binding data. *Use*: If licensing works for you, similar to BindingDB for structure‑aware priors.

## Materials & Crystallography
- **Crystallography Open Database (COD)** — Crystal structures. *Use*: Compare simulated structure factors S(k) to real lattice data.
- **Materials Project** — DFT materials properties. *Use*: Validate elastic/spectral trends from field‑deformed lattices (toy comparisons).
- **OQMD / NOMAD** — Large materials repositories. *Use*: Mine diffusion/formation energies to inform activation barriers.

## Thermochemistry & Kinetics
- **MNSol** — Solvation thermochemistry. *Use*: Cross‑check solvent trends in reaction–diffusion sweeps.
- **NIST Chemical Kinetics** — Gas‑phase kinetics. *Use*: Pull Arrhenius parameters to shape temperature dependence (if permitted by terms).

---

### Integration notes
- **Licensing varies**: confirm terms per dataset before redistribution. Many are open (COD, MassBank, NMRShiftDB, ORD), others require caution (ChEMBL/PDBbind).
- **How to MAC**: represent each dataset as a YAML block giving local paths and field mappings; then sweep over data‑derived parameters (e.g., k_f, ΔG, D).

