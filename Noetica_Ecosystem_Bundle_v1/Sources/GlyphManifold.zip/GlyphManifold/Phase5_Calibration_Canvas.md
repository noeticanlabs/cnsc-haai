# Phase‑5 Calibration Canvas — Law of Coherence ⇄ Nuclear Data (UCLP‑2.1)

**Date:** auto-generated

This canvas binds empirical nuclear constants to the **Law of Coherence (LoC)** parameters and the **Glyph Manifold** PDE for experiment‑grade calibration under **UCLP‑2.1**.

---

## 1) Datasets
- NIST atomic & nuclear subset (enhanced): `nist_atomic_nuclear_constants_subset_enhanced.*`
- Nuclide map canvas: `nuclide_data_canvas.*`
- Harmonized table saved as: `phase5_calibration_table.csv`

Key fields used:
- `Z` (proton number), `A` (mass number), `symbol`, `nuclide`
- `Q_meV` (decay Q value, MeV) → **V₀** (LoC potential scale)
- `half_life_s` (seconds) → **Γ** (LoC damping via λ = ln2 / t₁/₂)
- `xi_curvature_proxy` → **ξ** (LoC curvature coupling; placeholder unless provided)

---

## 2) Parameter Mapping (LoC ⇄ Data)

Let the LoC field equation be (schematic form):

[ Box θ + Γ·θ̇ + ξ R θ = −V₀ sin(θ − θ₀) ]

Empirical bindings:
- Potential scale:  V₀ ← Q_MeV  (keep in MeV for analysis; convert for SI as needed).
- Damping:          Γ  ← λ = ln 2 / t_{1/2}  (s⁻¹).
- Curvature couple: ξ  ← xi_curvature_proxy  (NaN unless supplied; can be set from separation energies or shell indices).

Non‑dimensionalization (simulation):
- Choose energy scale: E₀ = median(Q_MeV).
- Choose time scale:   T₀ = 1 / median(λ).
- Use: Ṽ₀ = V₀/E₀, Γ̃ = Γ·T₀, t̃ = t/T₀.

---

## 3) Calibration Procedure (Glyph Manifold)

1. Select a nuclide set 𝒩 with valid Q and t₁/₂.
2. Map parameters per nuclide: V₀, Γ, ξ.
3. Run PDE with these parameters as (a) initial conditions or (b) parameter sweeps.
4. Extract decay curve C(t) from the manifold (coherence or amplitude).
5. Fit exponential (with adaptive changepoint) to obtain λ̂.
6. Compare λ̂ vs. empirical λ → compute ρ, RMSE.
7. Log to UCLP via `/mnt/data/uclp_feedback.py` (semanticAlignment from ρ, numericStability from RMSE).

---

## 4) UCLP‑2.1 Telemetry Binding

- semanticAlignment = mean Pearson ρ across chosen nuclides
- numericStability = 1/(1 + RMSE/median(RMSE))
- phaseMismatch = |Q_net| (from vortex tracker when applicable)
- entropy_rate = relative gap in early/late decay constants from changepoint fit

---

## 5) Actionable Artifacts

- Calibration table: `/mnt/data/phase5_calibration_table.csv`
- Next: feed a selected row set into the PDE runner and write `validation_phase3_summary.csv` for the logger.

---

## 6) Notes & Extensions
- If separation energies or shell indices are available, set `xi_curvature_proxy` accordingly.
- Consider hierarchical modeling: group nuclides by shell closures to test structural coherence effects.
- Add GCC circular coordinates as an orthogonal topological feature to predict anomalous decay behaviors.

---

## 7) Units & Conversions (Dual-Normalized)

**Computation:** natural units (ħ = c = 1, MeV-based)

**Logging/Calibration:** SI units (J, m, s) with the following bridges:

- ħc = 197.326980338 MeV·fm
- 1 eV = 1.602176634000e-19 J, 1 MeV = 1.602176634000e-13 J
- 1 fm = 1.0e-15 m
- Planck scales: l_P = 1.616e-35 m, t_P = 5.391e-44 s, E_P ≈ 1.221e+22 MeV

**Usage in PDE:**
- Internal solver uses dimensionless fields with V₀ (MeV), Γ (s⁻¹) mapped to internal scales via chosen E₀ and T₀.
- Logger records both natural-unit values and SI-converted values for reproducibility.

Artifacts:
- codata_reference_block.json
- codata_reference_block.csv
