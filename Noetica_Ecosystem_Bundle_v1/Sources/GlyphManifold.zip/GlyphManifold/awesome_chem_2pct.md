# Mini Chemistry Datasets DB (~2% sample)

Curated micro‑subset from **kjappelbaum/awesome‑chemistry‑datasets** for quick experiments and benchmarking with CoherenceLab + MAC.

## Text datasets
| Name | Link | Why it’s useful |
|---|---|---|
| BC5CDR | https://paperswithcode.com/dataset/bc5cdr | Chemical–disease NER corpus; good for testing text‑mining and linking chemicals to effects. |
| Europe PMC | https://europepmc.org | Bulk full‑text for mining chemical mentions and properties; pairs well with keyword‑guided scrapes to seed reaction terms. |

## Structures
| Name | Link | Why it’s useful |
|---|---|---|
| Crystallography Open Database (COD) | https://www.crystallography.net | Source of crystal structures; can validate lattice‑scale patterns and compare simulated structure factors. |
| ZINC22 | https://cartblanche22.docking.org | Commercially available compounds for VS; great for generating ligand panels to parameterize reaction channels. |

## Structure–property benchmarks
| Name | Link | Why it’s useful |
|---|---|---|
| FreeSolv | http://www.free-solvation-database.org/ | Hydration free energies (exp & calc); benchmark solvent effects in reaction–diffusion scenarios. |
| BindingDB | https://www.bindingdb.org | Massive binding/affinity records; can set distributions for association/dissociation rates in surrogate kinetics. |

---

### Notes
- Licensing varies by source; check each dataset’s terms before redistribution.
- For MAC integration: represent each dataset as a YAML block that points to local CSV/SD files and lists key fields (e.g., `kf`, `kr`, `ΔG_hyd`, `Ki`).
