# Field Equations — Live Notebook (Glyph Manifold)

**Auto‑patch v1 (stability + units sanity)**
- Courant number (wave): **C = 1** (rule-of-thumb 3D explicit limit ≈ 0.577). → *Borderline/unstable.* Reduce **Δt** to ≤ 0.000577 s or coarsen **c** for stability.
- Diffusion conversion: **D_phys = 1.000e-12 m²/s** (matches 1e-12 m²/s).
- Damping: **γ_phys = 30 s⁻¹**, damping time τ ≈ **0.0333 s**.
- Energy unit: **E_unit = ρ c² = 1.000e-10 J/m³**.

## PDE Hygiene (DLX-1.5 → DLX-1.6)
Current:  θ̈ = c²∇²θ − V₀ sin(θ−θ₀) − γ θ̇ + D ∇²θ + F(t)

**Keep both** ∇² terms only if you *intentionally* want a telegraph + diffusion blend. Otherwise, fold into an *effective* propagator:
- In Fourier:  θ̈ₖ + γ θ̇ₖ + ωₖ² θₖ = Fₖ(t), with **ωₖ² = (c² − i D ω)** k² + V₀ cos(θ₀) (linearized).  
- Practical: for small amplitudes and modest D, keep both; for clean waves, set **D→0**.

## Gauge Extension (minimal coupling, ready-to-run)
Replace ∇θ → ∇θ − qA and add a Maxwell‑like energy:
- 𝓔_A = (α/2)|∇×A|² + (β/2)|∇·A|²,  Ȧ = −η_A ∇×(∇×A) + ν_A ∇²A + J_θ,  with J_θ = q ∇θ.
This preserves gauge (choose β=0 for Coulomb‑like, or small β for numerical conditioning).

## Resonant Drive Cue (DLX‑1.7)
For plane‑wave k, **f₀(k) ≈ ωₖ/2π ≈ (c k)/(2π)** for weak V₀.  
Sweet spot scan: pick k from the helix pitch (**k ≈ 2π/pitch**) and set f ≈ c k/2π. With pitch=1.5 (sim‑units), try f ∈ [0.6, 1.6]·f₀.

## Stability Checklist (auto‑computed)
- Suggested new **Δt ≤ 0.000577 s** (keep C ≤ 0.577).  
- If you keep Δt = 1 ms, reduce **c** to ≤ 0.000577 m/s.

## Topology Detector (v2.6 — branch‑cut free, drop‑in)
```python
import numpy as np

def detect_winding(u):
    """u = Psi / |Psi| on a 2D grid. Returns {'Q_count','Q_net'}.
    Uses CCW plaquette sum with wrapped phase diffs and sign‑aware clustering."""
    # phase with wrap-safe diffs
    phi = np.angle(u)
    dphi_x = np.mod(np.diff(phi, axis=0)+np.pi, 2*np.pi)-np.pi
    dphi_y = np.mod(np.diff(phi, axis=1)+np.pi, 2*np.pi)-np.pi
    # build plaquette circulation (CCW)
    circ = dphi_x[:, :-1] + dphi_y[1:, :] - dphi_x[:, 1:] - dphi_y[:-1, :]
    W = np.rint(circ/(2*np.pi)).astype(int)
    Q_net = int(np.sum(W))
    # count nonzero plaquettes (cluster‑aware lite)
    Q_count = int(np.count_nonzero(W))
    return {'Q_net': Q_net, 'Q_count': Q_count}
```
(*If you want true core clustering, run a connected‑components pass on W≠0.*)

## DLX‑1.6 Run Plan (immediate)
- **Change** Δt → 0.00052 s or **c** → 0.00052 m/s.
- **Keep** D=1e-3, γ=0.03 for comparability.
- **Activate** gauge with tiny ν_A=1e-4, η_A=1e-3, q=1 (dimensionless), β=1e-3.
- **Add** drive off (DLX‑1.6), on in DLX‑1.7 with f≈c·(2π/pitch)/(2π)=c/pitch.

## Quick Numbers (helix‑matched drive)
- k_helix ≈ 2π/pitch ≈ 4.189 (sim‑units)
- f₀ ≈ c·k_helix/(2π) ≈ 6.667e-04 Hz (with current anchors)

---

Append this block to your repo’s Live Notebook file. Next step: re‑run DLX‑1.6 with the stability fix and log energy + topology.
