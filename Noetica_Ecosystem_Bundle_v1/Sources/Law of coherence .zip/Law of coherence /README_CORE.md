# Core Tuning Kit

Defaults target r*: 1.00e-06 m. Adjust via scripts.

## θ-model
Config: /mnt/data/configs/theta2d_core.yaml
```
python /mnt/data/scripts/make_core_params.py theta --r_star 1.00e-06 --dx 1.0e-06 --out /mnt/data/configs/theta2d_core.yaml
python /mnt/data/scripts/analyze_core_hit.py --theta /mnt/data/configs/theta2d_core.yaml
```

## GPE
Config: /mnt/data/configs/gpe2d_core.yaml
```
python /mnt/data/scripts/make_core_params.py gpe --solve g  --r_star 1.00e-06 --n0 1e20 --out /mnt/data/configs/gpe2d_core.yaml
python /mnt/data/scripts/analyze_core_hit.py --gpe /mnt/data/configs/gpe2d_core.yaml
```
Or solve n0 instead of g:
```
python /mnt/data/scripts/make_core_params.py gpe --solve n0 --r_star 1.00e-06 --g 1e-45 --out /mnt/data/configs/gpe2d_core.yaml
```
