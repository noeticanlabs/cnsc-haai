## Canonical Definitions: Coherence, Curvature, and Strain (RFT–Law of Coherence Framework)

### 1. Coherence (\(\mathcal{C}\))
**Physical meaning:** Degree of local phase alignment or mutual order within a field.

**Operational definition:**  
Given a scalar phase field \(\theta(x,y)\), define
\[
\mathcal{C} = \Big| \langle e^{i(\theta(x,y) - \langle \theta \rangle)} \rangle_\Omega \Big|,
\]
where \(\langle \cdot \rangle_\Omega\) denotes the spatial average over the domain.

**Range:** \(0 \le \mathcal{C} \le 1\)
- \(\mathcal{C} = 1\): perfectly ordered (all phases aligned).  
- \(\mathcal{C} = 0\): fully incoherent (random phases).

**Measurement:** Directly computed from field snapshots or via complex order parameters used in XY/Kuramoto-type systems.

---

### 2. Curvature (\(\kappa\))
**Physical meaning:** Local geometric bending of constant-phase contours; quantifies spatial stress or geometric strain of the field.

**Operational definition:**  
For a smooth \(\theta(x,y)\),
\[
\kappa(x,y) = \nabla \!\cdot\! \left( \frac{\nabla\theta}{|\nabla\theta|} \right), \quad |\nabla\theta|>0.
\]

**Units:** Inverse length.

**Interpretation:**  
- High \(|\kappa|\): sharp bends or defects (vortex cores, domain walls).  
- \(\kappa = 0\): locally flat phase, minimal geometric strain.

**Measurement:** Finite-difference or spectral derivatives of \(\theta\). Physically corresponds to curvature of phase fronts or iso-energy contours.

---

### 3. Strain (\(\sigma\))
**Physical meaning:** Stored elastic or phase-gradient energy density; the energetic cost of deviating from perfect coherence.

**Operational definition (scalar proxy):**
\[
\sigma(x,y) = \tfrac{1}{2}\,|\nabla\theta|^2.
\]

**Integrated strain (total tension):**
\[
E_\sigma = \int_\Omega \sigma(x,y)\,d^2x.
\]

**Units:** Energy per unit area (if \(\theta\) is dimensionless).

**Interpretation:**  
- High strain regions mark competing phase domains or shear in the coherent field.  
- Equilibrium corresponds to minimized \(E_\sigma\) under topological constraints.

---

### 4. Relationship among Quantities

| Quantity | Governs | Measured by | Physical Interpretation |
|-----------|----------|--------------|--------------------------|
| **Coherence (\(\mathcal{C}\))** | Order | Mean phase alignment | Degree of global organization |
| **Curvature (\(\kappa\))** | Geometry | Phase-front bending | Spatial configuration of order |
| **Strain (\(\sigma\))** | Energy | Gradient magnitude | Local energetic cost of order |

These quantities interact as follows:
\[
\frac{d\mathcal{C}}{dt} \;\propto\; -\frac{dE_\sigma}{dt},
\]
meaning coherence tends to increase as strain energy is released or redistributed, approaching a dynamic equilibrium where curvature and order balance.

---

### 5. Measurement Pipeline (for simulations)
1. Generate \(\theta(x,y)\) from simulation or glyphic field.  
2. Compute \(\nabla\theta\), \(|\nabla\theta|\), and \(\kappa(x,y)\).  
3. Calculate \(\mathcal{C}\), \(E_\sigma\), and correlate time-derivatives.  
4. Track \(\mathcal{C}(t)\) vs. \(E_\sigma(t)\) to verify \(d\mathcal{C}/dt \propto -dE_\sigma/dt\).  
5. Compare across parameter sweeps to confirm universality of coherence–strain balance.

---

**Summary Statement:**  
Coherence, curvature, and strain form an interdependent triad describing how a field organizes itself. Coherence measures *order*, curvature measures *geometry*, and strain measures *energy*. The Law of Coherence proposes that systems evolve to balance these three, minimizing tension while maintaining structured order.



---

### 6. Dimensional Analysis & φ‑Scaling Consistency

**Conventions.** Let length dimension be [L]. Take the phase θ to be dimensionless (radians). Introduce an optional stiffness constant K so that energy has physical units.

**Units.**

| Quantity | Symbol | Physical dimension |
|---|---|---|
| Phase | θ | 1 (dimensionless) |
| Gradient | ∇θ | [L]⁻¹ |
| Curvature | κ = ∇·(∇θ/|∇θ|) | [L]⁻¹ |
| Strain density | σ = ½|∇θ|² | [L]⁻² |
| Stiffness (optional) | K in 𝓔 = ½K|∇θ|² + V | energy |
| Energy density | 𝓔 | energy·[L]⁻² |
| Total strain energy | E_σ = ∫σ d²x | 1 (or energy if multiplied by K) |
| Coherence | 𝒞 | 1 (dimensionless) |

**Two scaling modes.** Distinguish active field zoom vs passive unit dilation:

1) **Active zoom (higher spatial frequency):** θ_Φ(x) = θ(Φx) on a fixed domain.
- ∇θ_Φ(x) = Φ(∇θ)(Φx) ⇒ |∇θ_Φ|² ∝ Φ².
- σ_Φ(x) = ½|∇θ_Φ|² ∝ Φ².
- E_σ[θ_Φ] = ∫_Ω σ_Φ d²x ∝ Φ² (domain fixed).
- κ_Φ(x) = Φ κ(Φx) (divergence adds another Φ).
- 𝒞: invariant to global phase; may change empirically if texture statistics change.

2) **Passive dilation (change of units):** x′ = Φx, fields expressed over the stretched domain Ω′.
- Derivatives scale as ∂_x = Φ ∂_{x′} ⇒ |∇θ|² → |∇′θ|²/Φ².
- Area element d²x → d²x′/Φ².
- Therefore E_σ = ∫ ½|∇θ|² d²x is invariant under uniform dilation (pure unit change).
- Curvature scales as κ → κ′/Φ (inverse length).

**φ‑scaling tests.** If an observable Q has length dimension [L]^d, then under passive dilation by Φ: Q → Φ^d Q. Choosing Φ = φ (golden ratio), predicted scaling is Q ∝ φ^d.
- Example: a constructed quantity with d = −4 should scale as φ⁻⁴ (matching your earlier numerical ratio).
- Sanity checks: κ has d = −1; σ has d = −2; E_σ has d = 0 (dimensionless, or energy if multiplied by K).

**Normalization choices.**
- Dimensionless convention: set K = 1, energies reported in natural units.
- Physical convention: keep K with energy units (e.g., J). Then 𝓔 = ½K|∇θ|² + V(θ), E_σ = ½K ∫ |∇θ|² d²x.

**Consistency checklist.**
- Report whether a scaling is active or passive; they predict opposite tendencies for σ and E_σ.
- When claiming φ‑scaling, state the exponent d you are testing and show log Q vs log Φ slope.
- For curvature, verify units by grid refinement: κ should scale linearly with inverse grid spacing for self‑similar resamples.


---

### 7. Extended Energy Definition (RFT Formulation)

To separate local strain from total energy and avoid redundancy with coherence metrics, the RFT energy density is defined in gauged form.

**Local strain diagnostic:**
- Ungauged (toy model):  
  σ = ½|∇θ|²
- Full RFT (gauged):  
  σ = ½κ₁|Dθ|², Dθ = ∇θ − A

**Total energy density:**

𝓔 = ½κ₁|Dθ|² + ½κ₂|F|² + V(θ), F = ∇×A

where:
- κ₁ is the coupling for the covariant strain term,
- κ₂ is the coupling for the curvature or field-strength term,
- V(θ) is a potential energy term (e.g., cosine or harmonic potential),
- F = ∇×A represents field curvature or vorticity.

If an additional axion-like term αθFṽF exists, it remains topological and does not modify 𝓔 directly.

This formulation ensures that energy is not a trivial function of strain alone. σ remains a local diagnostic of phase gradient intensity, while 𝓔 measures the total field energy including curvature and potential effects. This distinction removes tautological correlations between energy and coherence when testing the Law of Coherence.
