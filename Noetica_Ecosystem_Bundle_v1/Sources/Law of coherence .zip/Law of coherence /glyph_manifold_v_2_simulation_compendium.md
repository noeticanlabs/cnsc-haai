# Glyph Manifold v2 — Simulation Compendium

**Purpose:** One-stop suite of simulation scenarios spanning RFT coherence, glyph manifold dynamics, portals, and glyph-logic. Designed to plug into `glyph_manifold_sim.ipynb`.

**Core Metrics (CCS):** coherence \(\mathcal{C}\), strain \(\mathcal{S}=\|\nabla s\|^2+\|\nabla\theta\|^2\), curvature energy \(\|\Omega\|^2\); plus Allan deviation (\(\Phi_a\)), recovery time \(R_t\), semantic fidelity \(\sigma_{sem}\), portal fidelity \(F_{portal}\).

**Global Defaults:** `k=64`, weights `(α,β,χ,λ,μ)=(1,0.5,0.1,0.2,0.7)`, gains `(γθ,γs)=(0.2,0.1)`, portal floor `c*=0.8`, spectral prior temp `τ=0.2`.

---

## 0) Shared Scaffolding

### 0.1 State containers (pseudo‑API)

```python
class Manifold:  # mesh + metric
    V: np.ndarray  # (n, d)
    E: np.ndarray  # (m, 2)
    W: np.ndarray  # edge weights

class Field:
    data: np.ndarray  # (n,) for theta (float), (n,k) for s

class GlyphField:
    M: Manifold
    theta: Field  # radians
    s: Field      # latent k
    schema: dict

# metrics
@dataclass
class Metrics:
    C: float
    S: float
    Om2: float
    Allan: float | None = None
    R_recov: float | None = None
    sigma_sem: float | None = None
    F_portal: float | None = None
```

### 0.2 Logging & evaluation hooks

```python
class Logger:
    def __init__(self):
        self.rows = []
    def log(self, t, **kv):
        self.rows.append({"t": t, **kv})
    def dataframe(self):
        import pandas as pd
        return pd.DataFrame(self.rows)
```

### 0.3 Utility kernels

- **Synchronizer (Kuramoto geodesic):** \(\theta_i \leftarrow \mathrm{Arg}\sum_{j\in N(i)} e^{i\theta_j}\).
- **Transport:** covariant advection of `s` along \(u=\nabla^\#\theta\).
- **Energy:** \(\mathcal{E}=\alpha\|\nabla\theta\|^2+\beta\|\nabla s\|^2+\chi\langle s,\Omega s\rangle+\lambda V_{shape}-\mu\mathcal{C}\).

> Implementation note: use semi‑implicit for stiff terms (β,χ), explicit for transport/noise.

---

## 1) Canonical Base Scenarios

### C1 — Two‑Cavity Shortcut (Phase Locking)

**Goal:** Coherence plateau under coupling sweep.

**Setup:** Two Kuramoto cavities with N oscillators each; coupling `K` swept log‑space.

**Inputs:** `N, K_grid, ω spread σ_ω, steps, dt`.

**Outputs:** `C(K), Δphase(K), Allan(K)`.

**Procedure:**

1. Initialize θ¹, θ² with random phases; native ω drawn from `N(ω0, σ_ω)`.
2. Evolve for warm‑up, then measure steady‑state.
3. Fit plateau region; detect “mini‑shortcut” threshold.

**Notebook cell (template):**

```python
for K in K_grid:
    θ = init_two_cavities(N, σ_ω)
    log = run_kuramoto(θ, K, steps, dt)
    C, dphi, allan = summarize_phase(log)
    logger.log(K=K, C=C, dphi=dphi, Allan=allan)
```

---

### C2 — Squeezed‑in / Noise‑out

**Goal:** Reduced phase‑noise PSD vs baseline.

**Inputs:** `squeeze_db, band, steps, dt`.

**Outputs:** `PSD_base, PSD_sqz, ΔPSD, C(t)`.

**Procedure:**

1. Run baseline; compute PSD(θ).
2. Inject band‑limited squeezed noise; rerun.
3. Compare PSD curves and coherence time.

---

### C3 — φ‑ratio Modulation

**Goal:** Test r∈{3/2,4/3, φ} for stability bands.

**Inputs:** `ratios=[1.5, 1.618034, 1.6667], temp τ`.

**Outputs:** `Allan(r), band_smoothness(r)`.

**Procedure:** modulate θ → θ + A sin(2π r t); compute Allan deviation.

---

## 2) Glyph Manifold Dynamics

### G1 — Coherence‑Preserving Deformation (P1)

**Goal:** Keep C drop <5% under shear+bend.

**Inputs:** `mesh, k=64, shear γ, bend κ, steps`.

**Outputs:** `C(t), S(t), ||Ω||²(t)`.

**Procedure:**

1. Init glyph from v1 template.
2. Apply parametric deformation fields.
3. Track CCS metrics; assert max drop.

---

### G2 — Portal Jump Continuity (P2)

**Goal:** Maintain seam coherence and semantic transfer.

**Inputs:** `M1, M2, seam Φ, generator (Δb,Δφ,Δρ), c*`.

**Outputs:** `F_portal, C_seam_pre/post, σ_sem`.

**Procedure:**

1. Stitch meshes along Φ.
2. Initialize (θ,s) on M2 via operator L.
3. Seam‑relax: minimize `L_glue + λ(1-C)` in k‑ring.

---

### G3 — Rational Riff Stability (P3)

**Goal:** Compare curvature oscillations under riffs.

**Inputs:** `ratio r, temp τ, duration`.

**Outputs:** `PSD_r, S(t), Ω_norm`.

**Procedure:** apply `riff(G, r)` and log CCS.

---

### G4 — Portal Cascade Stress Test

**Goal:** Coherence half‑life across N portals.

**Inputs:** `N, alternating curvature, generator set`.

**Outputs:** `C_after_n, half_life N_1/2`.

**Procedure:** chain portals; fit exponential decay in C.

---

## 3) Biophysical EM Analogues

### B1 — Harmonic Lattice Resonance

**Goal:** Coherence vs boundary curvature in oscillator grid.

**Inputs:** `grid size, boundary κ(t)`.

**Outputs:** `C(t), resonance map`.

---

### B2 — Coherence Collapse & Recovery

**Goal:** Recovery dynamics after noise bursts.

**Inputs:** `burst rate, amplitude, γθ, γs`.

**Outputs:** `R_t, hysteresis area`.

---

### B3 — Curvature–Charge Correlation

**Goal:** Test κ ↔ energy density correlation.

**Inputs:** `field config, metric g`.

**Outputs:** `corr(κ, ρ_energy)`.

---

## 4) Topology & Weave

### T1 — Handle Addition / Removal

**Goal:** Topological resilience index.

**Inputs:** `handle radius, seam width, relax iters`.

**Outputs:** `resilience = C_post × σ_sem`.

---

### T2 — Multi‑Manifold Weave

**Goal:** Standing interference harmonics.

**Inputs:** `flows u1,u2, phase orientation`.

**Outputs:** spectral peaks, braid invariants.

---

## 5) Integration (RFT–Glyph Fusion)

### I1 — Coherence–Energy Map

**Goal:** Visualize energy landscape as function of C.

**Outputs:** heatmaps over manifold; C vs E curve.

---

### I2 — Glyph Traveler with Comms

**Goal:** Traveler carrying internal glyph state across portals.

**Inputs:** `trajectory, portal schedule, comm bandwidth`.

**Outputs:** CCS along path, packet loss across portals.

---

### I3 — Glyph‑Logic Algebra Validation

**Goal:** Check (bind∘weave) ≃ (weave∘bind) (homotopy ε<1e‑3).

**Procedure:** Monte‑Carlo over noise seeds; compare canonical forms.

---

## 6) Result Tables (schemas)

**Per‑run schema:**

```
seed | scenario | params(JSON) | C_end | S_end | Om2_end | Allan | R_recov | sigma_sem | F_portal | notes
```

**Per‑timestep schema:**

```
t | C | S | Om2 | metric_1 | metric_2 | ...
```

---

## 7) Plots & Dashboards

- C(t), S(t), ||Ω||²(t) per scenario; dual‑axis C vs E.
- PSD overlays for C2/C3/G3.
- Portal seam heatmaps for G2/T1.
- Half‑life plot for G4.

---

## 8) Repro Harness

```python
from itertools import product
SEEDS = [1,2,3,4,5]
SCENARIOS = [C1, C2, C3, G1, G2, G3, G4, B1, B2, B3, T1, T2, I1, I2, I3]

for seed in SEEDS:
    for S in SCENARIOS:
        params = default_params(S)
        res = run(S, seed=seed, **params)
        save_results(S, seed, res)
```

---

## 9) Acceptance Criteria

- C1 plateau and detectable threshold.
- C2 PSD drop ≥ 3 dB in target band.
- G1 coherence drop ≤ 5% under specified deformation.
- G2 `F_portal ≥ c*` and `σ_sem ≥ 0.9` after relax.
- G4 fitted half‑life exists (R² ≥ 0.95).
- I3 homotopy tolerance met across ≥95% seeds.

---

## 10) Next Deltas

- Wire API stubs into `glyph_manifold_sim.ipynb`.
- Add result writer (`.parquet`) and run registry.
- Add small synthetic datasets for reconstruction losses.

> Mantra for runs: *Measure the music, then move the stage.*

