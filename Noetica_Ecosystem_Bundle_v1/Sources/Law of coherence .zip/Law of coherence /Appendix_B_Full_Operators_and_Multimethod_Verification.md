# Appendix B — Full Operator Equations & Multimethod Verification (Dense)

## B.1 Variational (Lagrangian) Derivation
Let \(\theta: \Omega\times\mathbb R\to\mathbb R\) and \(A: \Omega\times\mathbb R\to\mathbb R^d\) with \(d=2\) (extendable). Define
\[
\mathcal L = \tfrac12\,\kappa_1\,|D\theta|^2 + \tfrac12\,\kappa_2\,|F|^2 - V(\theta),\qquad D\theta=\nabla\theta - A,\quad F=\nabla\times A.
\]
Euler–Lagrange equations (temporal gauge sketch; full 1+d form in B.2):
\[
\partial_t(\kappa_1\,\dot\theta) - \nabla\cdot(\kappa_1 D\theta) + V'(\theta)=0,\tag{B.1}
\]
\[
\partial_t\Big(\kappa_2\,\dot A\Big) + \nabla\times(\kappa_2 F) - \kappa_1 D\theta = 0,\tag{B.2}
\]
subject to chosen gauge and boundary conditions (periodic in simulations). When \(\kappa_i\) are constants and \(V''(\theta_0)\) finite, linearization around \((\theta_0,A_0)\) yields well-posed hyperbolic dynamics.

---

## B.2 Canonical (Hamiltonian) Form
Canonical momenta (temporal gauge; \(A_0=0\)):
\[
\pi_\theta = \frac{\partial \mathcal L}{\partial \dot\theta} = \kappa_1\,\dot\theta,\qquad \Pi = \frac{\partial \mathcal L}{\partial \dot A} = \kappa_2\,\dot A.
\]
Hamiltonian density
\[
\mathcal H = \pi_\theta\,\dot\theta + \Pi\!:\!\dot A - \mathcal L = \tfrac12\kappa_1\,\dot\theta^2 + \tfrac12\kappa_2\,|\dot A|^2 + \tfrac12\kappa_1|D\theta|^2 + \tfrac12\kappa_2|F|^2 + V(\theta).
\]
For static analyses used in verification, \(\mathcal H\equiv\mathcal E\).

---

## B.3 Covariant Tensor Form
In 1+2 dimensions with metric \(\eta=\mathrm{diag}(+,-,-)\), write the 1-form \(A_\mu\) and curvature 2-form \(F_{\mu\nu}=\partial_\mu A_\nu-\partial_\nu A_\mu\). Let \(\Theta\) be a scalar field and define a covariant 1-form \(D_\mu\Theta=\partial_\mu\Theta-A_\mu\). The Lagrangian density
\[
\mathcal L = \tfrac12\kappa_1\,D_\mu\Theta\,D^\mu\Theta + \tfrac12\kappa_2\,F_{\mu\nu}F^{\mu\nu} - V(\Theta)
\]
yields E–L equations
\[
\kappa_1\,D_\mu D^\mu \Theta + V'(\Theta)=0,\qquad \kappa_2\,\partial_\mu F^{\mu\nu} - \kappa_1 D^\nu\Theta=0.\tag{B.3}
\]
On curved manifolds replace derivatives by \(\nabla_\mu\) and add metric determinant factors.

---

## B.4 Spectral (Fourier) Representation & Dispersion
For periodic \(\Omega\), with \(k=(k_x,k_y)\) and \(\widehat{\cdot}\) the spatial Fourier transform,
\[
\widehat{D\theta}(k)= i k\,\hat\theta(k) - \hat A(k),\qquad \widehat{F}(k)= i\,(k_x\,\hat A_y - k_y\,\hat A_x).
\]
Linearized around \((\theta_0,A_0)\) with \(V''(\theta_0)=m^2\), plane-wave ansatz \(e^{i(k\cdot x-\omega t)}\) gives an effective dispersion (schematic, gauge-fixed):
\[
\omega^2(k) \approx \kappa_1 k^2 + m^2 + c_F\,\kappa_2 k^4,\tag{B.4}
\]
where \(c_F\) depends on gauge and polarization. This relation is used in Appendix C to compare analytic vs numerical \(\omega(k)\).

---

## B.5 Discrete Operators & Time Integration
**Centered differences (2nd order)** on grid spacing \(\Delta\):
\[
(\partial_x \theta)_{i,j}=\frac{\theta_{i+1,j}-\theta_{i-1,j}}{2\Delta},\quad (\partial_y \theta)_{i,j}=\frac{\theta_{i,j+1}-\theta_{i,j-1}}{2\Delta}.
\]
**Covariant gradient:** \((D\theta)_{i,j}=(\nabla\theta)_{i,j}-A_{i,j}\).  
**Discrete curl (2D):** \(F_{i,j}= (\partial_x A_y-\partial_y A_x)_{i,j}\).

**Symplectic integrator (leapfrog/Verlet):**
1) \(\pi_\theta^{n+1/2}=\pi_\theta^{n-1/2}+\Delta t\,[\nabla\cdot(\kappa_1 D\theta)^n - V'(\theta^n)]\)  
2) \(\Pi^{n+1/2}=\Pi^{n-1/2}+\Delta t\,[ -\nabla\times(\kappa_2 F)^n + \kappa_1 D\theta^n ]\)  
3) \(\theta^{n+1}=\theta^n+\Delta t\,\kappa_1^{-1}\,\pi_\theta^{n+1/2}\)  
4) \(A^{n+1}=A^n+\Delta t\,\kappa_2^{-1}\,\Pi^{n+1/2}\)

Energy error scales as \(\mathcal O(\Delta t^2)\) for smooth data; CFL: \(\Delta t \lesssim c\,\Delta\) with \(c\) from the spectral radius of the discrete operator.

---

## B.6 Finite-Element (Weak) Form
Multiply (B.1) by test \(\eta\) and integrate by parts (periodic BCs drop boundary terms):
\[
\int \kappa_1\,\dot\theta\,\dot\eta + \kappa_1 D\theta\cdot\nabla\eta + V'(\theta)\,\eta\; d^2x = 0.
\]
Similarly, the weak form for \(A\) uses test vector field \(w\) with curl and covariant terms. This provides a FEM route (e.g., FEniCS) to cross‑validate FD/FFT implementations.

---

## B.7 Symbolic & AD Verification
Using symbolic algebra (e.g., SymPy/autograd):
- Construct \(\mathcal L(\theta,\nabla\theta,A,\nabla\times A)\).  
- Verify E–L via \(\partial \mathcal L/\partial \theta - \nabla\cdot(\partial \mathcal L/\partial (\nabla\theta))=0\).  
- Autodiff residual checks: compute \(\mathcal R_\theta=\text{E–L}_\theta\), \(\mathcal R_A=\text{E–L}_A\) over random fields; confirm convergence to machine zero on analytic solutions (e.g., uniform, plane-wave, or lattice cases).

---

## B.8 Alternative Verification Pathways
| Method | What is checked | Acceptance |
|---|---|---|
| Spectral vs FD gradients | \(|\nabla\theta|^2\), \(|F|^2\) | mean rel. diff. < 1e−3 |
| FEM (FEniCS) weak form | Energy & residuals | < 1% energy gap vs FD/FFT |
| PINN/DeepONet residuals | PDE residual fields | L2 residual < 1e−5 on test ICs |
| Symbolic regression (SINDy) | Recover terms in \(\mathcal L\) | Finds \(|D\theta|^2, |F|^2, V(\theta)\) |
| Linear perturbation | Dispersion \(\omega(k)\) | < 0.2% at small k |

---

## B.9 Gauge Choices & Constraints
- **Temporal gauge:** \(A_0=0\) simplifies time stepping; add divergence cleaning for \(\nabla\cdot A\) if needed.
- **Coulomb/Lorenz gauges:** impose \(\nabla\cdot A=0\) or \(\partial_\mu A^\mu=0\) via projection (FFT) or penalty terms.
- **Constraint monitoring:** track \(\nabla\cdot A\) and boundary fluxes; include in Appendix C logs.

---

## B.10 Boundary Conditions & Domains
- **Periodic (torus):** default for spectral accuracy and topological charge conservation.  
- **Dirichlet/Neumann:** for driven/coerced coherence; state explicitly to avoid energy non‑conservation artifacts.

---

## B.11 Implementation Checklists
- Record \((\kappa_1,\kappa_2), V, \Delta, \Delta t,\) gauge, seeds.  
- De‑alias quadratic nonlinearities (2/3 rule).  
- Use wrapped differences for winding; fix branch cuts globally.  
- Validate against manufactured solutions (plane wave, uniform, single vortex) before production runs.

---

**Cross‑references:** Dispersion fits, energy conservation traces, and residual scaling results are summarized in Appendix C and archived with seeds and grid specs for reproducibility.
