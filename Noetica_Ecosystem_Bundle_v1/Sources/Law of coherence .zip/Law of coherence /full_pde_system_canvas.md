
# 🧠 Live Canvas: Full PDE System — Glyph Manifold Framework (2D, Fully Runnable)

---

## 🔷 Step 0: Problem Setup — Coupled PDE System

### Scalar PDE (physical):
\[
\ddot{\theta} = c^2 \nabla^2 \theta - V_0 \sin(\theta - \theta_0) - \gamma \dot{\theta} + D \nabla^2 \theta + F(t)
\]

### Gauge Extension:
\[
\nabla \theta \rightarrow \nabla \theta - q \mathbf{A}
\]
\[
\dot{\mathbf{A}} = -\eta_A \nabla (\nabla \cdot \mathbf{A}) + (\eta_A + \nu_A) \nabla^2 \mathbf{A} + q \nabla \theta
\]

---

## 🔷 Step 1: Non-Dimensionalization

Given scales: \( \Delta x = L_c \), \( \Delta t = L_c / c \)

### Non-dimensional PDE:
\[
\partial_t^2 \theta = (1 + \tilde{D}) \nabla^2 \theta - \tilde{V}_0 \sin(\theta) - \tilde{\gamma} \partial_t \theta + \tilde{F}(t)
\]

With:
- \( \tilde{D} = \frac{D}{c^2} \)
- \( \tilde{\gamma} = \frac{\gamma L}{c} \)
- \( \tilde{V}_0 = \frac{V_0 L^2}{\Theta c^2} \)

---

## 🔷 Step 2: Numerical Scheme (Explicit FD, 2D)

### Update Rule:
\[
\theta^{n+1}_{i,j} = 2\theta^n_{i,j} - \theta^{n-1}_{i,j}
+ \Delta t^2 \left[ (1 + \tilde{D}) \nabla^2 \theta^n_{i,j} - \tilde{V}_0 \sin(\theta^n_{i,j}) - \tilde{\gamma} \frac{\theta^n_{i,j} - \theta^{n-1}_{i,j}}{\Delta t} + \tilde{F}^n_{i,j} \right]
\]

### CFL:
\( \Delta t \leq \Delta x / \sqrt{1 + \tilde{D}} \)

---

## 🔷 Step 3: Analytical Solution (Linearized)

Fourier-space:
\[
\ddot{\hat{\theta}}_k + \tilde{\gamma} \dot{\hat{\theta}}_k + \omega_k^2 \hat{\theta}_k = \hat{F}_k(t), \quad
\omega_k^2 = (1 + \tilde{D})k^2 + \tilde{V}_0
\]

Resonance amplitude:
\[
|\hat{\theta}_k(\Omega)| = \frac{f_0}{\sqrt{(\omega_k^2 - \Omega^2)^2 + \tilde{\gamma}^2 \Omega^2}}
\]

---

## 🔷 Step 4: Dispersion Analysis

Dispersion relation:
\[
\omega(k) = \sqrt{(1 + \tilde{D})k^2 + \tilde{V}_0 - \tilde{\gamma}^2/4} - i \tilde{\gamma}/2
\]

- Group velocity:
\( v_g = \frac{d\omega}{dk} \)
- Linear at large \( k \), saturates at small \( k \)

---

## 🔷 Step 5: Gauge Field Update

Update equation:
\[
\dot{\mathbf{A}} = -\eta_A \nabla(\nabla \cdot \mathbf{A}) + (\eta_A + \nu_A) \nabla^2 \mathbf{A} + q \nabla \theta
\]

Discrete updates:
- Quiver, divergence, and curl operators using central differences
- Euler or RK1 stepping

---

## 🔷 Step 6: Full Simulation Loop (Pseudocode)

```python
for n in range(N_steps):
    A = update_A(A, theta)
    theta_new = update_theta(theta, theta_prev, A)
    apply_BC(theta_new, A)
    theta_prev, theta = theta, theta_new
```

---

## 🔷 Step 7: Energy & Stability

### Total energy:
\[
E = \frac{1}{2} \dot{\theta}^2 + \frac{1}{2} |\nabla \theta - q\mathbf{A}|^2 + V_0(1 - \cos \theta) + \mathcal{E}_A
\]

Check:
- Drift
- Damping loss
- Forcing gain
- Spectral energy

---

## 🔷 Step 8: Extension to Manifolds

- Use **Laplace-Beltrami** for scalar fields
- Use **DEC** or FEM for vector fields
- Apply on triangle mesh, sphere, torus, or arbitrary domains

---

## 🔷 Step 9: Visualization (2D, Fully Runnable)

### Scalar Fields:
```python
plt.imshow(np.mod(theta, 2*np.pi), cmap='twilight_shifted')
```

### Vector Fields:
```python
plt.quiver(X, Y, Ax, Ay)
plt.streamplot(X, Y, Ax, Ay)
```

### Diagnostics:
```python
divA = np.gradient(Ax, dx, axis=1) + np.gradient(Ay, dy, axis=0)
curlA = np.gradient(Ay, dx, axis=1) - np.gradient(Ax, dy, axis=0)
```

### FFT Spectrum:
```python
spectrum = np.abs(np.fft.fftshift(np.fft.fft2(theta)))**2
```

---

## ✅ Fully Ready for Development

This canvas includes:
- Mathematical modeling
- Discretization
- Simulation loop
- Analysis tools
- 2D visualization
- Compatibility with this environment

