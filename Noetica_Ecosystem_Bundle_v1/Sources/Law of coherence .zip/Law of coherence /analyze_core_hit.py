#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, re, math
from pathlib import Path

def parse_val(text, key):
    m = re.search(rf'^\s*{re.escape(key)}\s*:\s*([eE0-9\.\-\+]+)\s*$', text, flags=re.MULTILINE)
    return float(m.group(1)) if m else None

def theta_hit(path):
    t = Path(path).read_text()
    c2 = parse_val(t, 'c2') or 1.0
    V0 = parse_val(t, 'V0') or 1.0
    dx = parse_val(t, 'dx') or 1e-6
    r_star = parse_val(t, 'r_star_m') or 1e-6
    r_pred = math.sqrt(c2/V0)*dx
    return dict(model='theta', r_star=r_star, r_pred=r_pred, error=r_pred-r_star)

def gpe_hit(path):
    t = Path(path).read_text()
    hbar = parse_val(t, 'hbar') or 1.054e-34
    m = parse_val(t, 'm') or 1.44e-25
    g = parse_val(t, 'g') or 1e-45
    n0 = parse_val(t, 'n0') or 1e20
    r_star = parse_val(t, 'r_star_m') or 1e-6
    r_pred = hbar / math.sqrt(2.0*m*g*n0)
    return dict(model='gpe', r_star=r_star, r_pred=r_pred, error=r_pred-r_star)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--theta')
    ap.add_argument('--gpe')
    args = ap.parse_args()
    out = {}
    if args.theta:
        out['theta'] = theta_hit(args.theta)
    if args.gpe:
        out['gpe'] = gpe_hit(args.gpe)
    print(out)

if __name__ == '__main__':
    main()
