#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, re, math
from pathlib import Path

def update_yaml(path, replacements):
    text = Path(path).read_text()
    for key, val in replacements.items():
        pattern = re.compile(rf'(^\s*{re.escape(key)}\s*:\s*).*$' , re.MULTILINE)
        text = pattern.sub(rf'\1{val}', text)
    Path(path).write_text(text)

def solve_theta(r_star, dx, c2):
    return c2 / (r_star/dx)**2

def solve_gpe_for_g(r_star, m, hbar, n0):
    return (hbar/(math.sqrt(2.0)*m*r_star))**2 / n0

def solve_gpe_for_n0(r_star, m, hbar, g):
    return (hbar/(math.sqrt(2.0)*m*r_star))**2 / g

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('model', choices=['theta','gpe'])
    ap.add_argument('--out', required=True)
    ap.add_argument('--r_star', type=float, default=1e-6)
    ap.add_argument('--dx', type=float, default=1e-6)
    ap.add_argument('--c2', type=float, default=1.0)
    ap.add_argument('--solve', choices=['g','n0'], default='g')
    ap.add_argument('--m', type=float, default=1.44e-25)
    ap.add_argument('--hbar', type=float, default=1.054e-34)
    ap.add_argument('--g', type=float, default=1e-45)
    ap.add_argument('--n0', type=float, default=1e20)
    args = ap.parse_args()

    if args.model=='theta':
        V0 = solve_theta(args.r_star, args.dx, args.c2)
        update_yaml(args.out, {'V0': f'{V0:.6g}', 'r_star_m': f'{args.r_star:.6g}', 'dx_m': f'{args.dx:.6g}'})
        print('Solved θ-model V0 =', V0)
    else:
        if args.solve=='g':
            g = solve_gpe_for_g(args.r_star, args.m, args.hbar, args.n0)
            update_yaml(args.out, {'g': f'{g:.6g}', 'n0': f'{args.n0:.6g}', 'r_star_m': f'{args.r_star:.6g}'})
            print('Solved GPE g =', g, 'for n0 =', args.n0)
        else:
            n0 = solve_gpe_for_n0(args.r_star, args.m, args.hbar, args.g)
            update_yaml(args.out, {'n0': f'{n0:.6g}', 'g': f'{args.g:.6g}', 'r_star_m': f'{args.r_star:.6g}'})
            print('Solved GPE n0 =', n0, 'for g =', args.g)

if __name__ == '__main__':
    main()
