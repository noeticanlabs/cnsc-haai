# METHODS — RFT‑Watch v1.1

**Goal.** Infer elapsed time directly from the evolving interference of the RFT order parameter, without using a counter, and detect drift.

## Signal
We simulate a 1D phase field θ(x,t) with gauge A(x,t). The complex order parameter Ψ=e^{iθ} is averaged spatially to form s(t)=⟨Ψ⟩_x ∈ ℂ.

## Fingerprints (QUBS‑style)
We maintain overlapping windows (length T_w, hop H). For each window we compute the rFFT magnitude of s(t), z-score normalize, suppress DC, and pick the top‑m peaks with a minimum bin spacing. A fingerprint is the sorted list of (normalized frequency, normalized amplitude).

## Matching
We build a training dictionary from the first N_train windows, pairing each fingerprint with its center time. For inference, we compute a **frequency‑tolerant distance:** for each peak in the query fingerprint we match the nearest frequency in a candidate fingerprint if it lies within τ_ω; otherwise a mismatch penalty is added. The cost combines normalized frequency and amplitude differences. Confidence is 1/(ε + d_min). If d_min > τ_d, the time is marked **unknown**.

## Metrics
MAE of (t_hat−t_true) over inference windows, coverage (accepted windows), and confidence histograms. For drift detection we compare MAE between baseline and a run with a small dt drift.

## Notes
- Overlapping windows increase coverage and stability versus single‑shot FFT.
- Z‑scoring stabilizes peak selection across parameter regimes.
- Frequency‑tolerant matching prevents false mismatches when peaks shift slightly.
- This design directly mirrors the logic of quantum‑beat “watches” (Rydberg wave‑packet beats), generalized to RFT fields.
