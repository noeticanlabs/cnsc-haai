# Noetica Language Package v1.0

This is a complete package of the Noetica language system including:
- Spoken Proto-Latin Noetica Spec
- Core Vocabulary Lexicon (v2.0)
- Coherence Role Definitions (Δ, Ω, Ψ)
- Phactum Dialects and Execution Modes
- Glyph Mapping + Rₗ Coherence Tables

Use this archive to compile, interpret, or evolve Noetican symbolic expressions in machine or human systems.
