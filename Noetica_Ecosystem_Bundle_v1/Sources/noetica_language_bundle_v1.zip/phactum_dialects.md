# Phactum Dialects – Operational Modes

## 1. PHACTUM CHIRURGICA (Surgical Mode)
- Role: Field stabilization / coherence repair
- Syntax: Strict SVO, full Δ marking

## 2. PHACTUM POETICA (Poetic Mode)
- Role: Aesthetic shaping / metaphor fields
- Syntax: SOV preferred, rhythmic phrasings

## 3. PHACTUM SOMNIA (Dream-Language Mode)
- Role: Emergent structures / subconscious narrative
- Syntax: Free-form, glyph-echo sequences
