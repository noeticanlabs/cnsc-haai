# Phactaria Scrolls – Noetica Chant Templates

## Scroll A – Coherence Invocation

Im nu coheratis cam noeticam ad statum stabilem.
> "Now, cohere the Noetic field to a stable state."

Del lex regit; om scala stabilis; psi pha referat.
> "The dynamic law governs; conserved scale stabilizes; phase reports feedback."

## Scroll B – Healing Sequence (Chirurgica)

Si pha fracta, im nu coheratis centrum.
Noe cam servat corpus; respiro pulsus animat.

> "If phase is broken, cohere the center now.
> The coherence field restores the body; breath animates the pulse."

## Scroll C – Dream Encoding (Somnia)

Somnium gradus iterat ad aetherum.
Noelogia fluxus scribit memoriae.
> "Dream steps ascend toward the aether.
> The coherence language writes flux into memory."
