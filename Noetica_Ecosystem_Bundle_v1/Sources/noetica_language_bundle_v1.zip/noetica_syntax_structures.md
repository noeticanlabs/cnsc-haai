# Syntax Structures in Noetica

## Sentence Templates

1. Declarative: Subject + Tense + Verb + Object
   > Ego nu cohero cam. – I now cohere the field.

2. Command: Imperative + Verb + Object
   > Im coheratis cam noeticam. – Cohere the Noetic field!

3. Conditional: Si + Clause + Main Clause
   > Si pha fracta, non cohero cam. – If phase is broken, I don’t cohere the field.

4. Question: An + Clause
   > An tu cohero pha? – Do you cohere the phase?
