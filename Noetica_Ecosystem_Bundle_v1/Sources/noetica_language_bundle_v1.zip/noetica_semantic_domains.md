# Semantic Domains of Noetica

- **Coherence Field (noe, pha, cam)**: Structural dynamics of resonance
- **Cognition (anima, cognitio, sensus)**: Feedback, processing, selfhood
- **Mechanics (vis, motus, frictio)**: Applied phase energy and force
- **Logic & Math (lex, logia, aequalis)**: Governing symbolic transformations
- **Narrative (narratio, causa, somnium)**: Story as coherence propagation

Each domain maps to glyphs in GM-OS and Δ/Ω/Ψ semantic roles.
