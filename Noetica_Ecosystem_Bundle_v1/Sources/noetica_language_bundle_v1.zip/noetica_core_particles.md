# Noetica Particles and Operators

| Particle | Role | Meaning |
|----------|------|---------|
| nu       | Ψ    | Present time |
| pa       | Ψ    | Past |
| fu       | Ψ    | Future |
| im       | Δ    | Imperative command |
| non      | Ψ    | Logical negation |
| nega     | Ω    | Strong / axiomatic exclusion |
| si       | Ψ    | If (condition) |
| ke       | Ω    | That (complementizer) |
| del      | Δ    | Marks dynamics |
| om       | Ω    | Marks conservation |
| psi      | Ψ    | Marks sensing / feedback |
