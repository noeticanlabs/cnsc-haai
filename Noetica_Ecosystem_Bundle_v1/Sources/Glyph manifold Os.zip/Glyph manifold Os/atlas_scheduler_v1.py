
import time, json
from pathlib import Path
import numpy as np

class Stepper:
    def __init__(self, solver, tag):
        self.solver = solver
        self.tag = tag
        self.R = []
    def step(self):
        R = self.solver.step()
        self.R.append(R)
        return R

class Atlas:
    def __init__(self, steppers, log_path: Path, target_hz=12.0):
        self.steppers = steppers
        self.target_hz = float(target_hz)
        self.log_path = Path(log_path); self.log_path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = open(self.log_path, "a", buffering=1)
        self._start = time.time(); self._ticks = 0

    def _log(self, row: dict):
        self._fh.write(json.dumps(row)+"\n")

    def tick(self):
        Rs = [s.step() for s in self.steppers]
        self._ticks += 1
        now = time.time()
        elapsed = now - self._start
        hz = self._ticks / max(1e-6, elapsed)
        row = {"t": now, "ticks": self._ticks, "elapsed_s": elapsed,
               "hz": hz, "R_mean": float(np.mean(Rs)), "R_std": float(np.std(Rs))}
        self._log(row)
        return row

    def run_seconds(self, seconds: float):
        end = self._start + seconds
        while time.time() < end:
            self.tick()
        self._fh.flush(); self._fh.close()
