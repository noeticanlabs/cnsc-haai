# LoC Theorem A10 — QSL Bound (empirical) — 20251024

**Verdict:** **True** (c_Q=1); **max c_Q\*** ≈ 0.9766500988002502

## Artifacts
- Summary: [GMOS_A10__20251024__A10_QSL_001__summary.json](sandbox:/mnt/data/GMOS_artifacts/GMOS_A10__20251024__A10_QSL_001__summary.json)
- Table: [GMOS_A10__20251024__A10_QSL_001__qsl_bounds.csv](sandbox:/mnt/data/GMOS_artifacts/GMOS_A10__20251024__A10_QSL_001__qsl_bounds.csv)
- Plots: [GMOS_A10__20251024__A10_QSL_001__qsl_6.283_5.027.png](sandbox:/mnt/data/GMOS_artifacts/GMOS_A10__20251024__A10_QSL_001__qsl_6.283_5.027.png), [GMOS_A10__20251024__A10_QSL_001__qsl_6.283_12.566.png](sandbox:/mnt/data/GMOS_artifacts/GMOS_A10__20251024__A10_QSL_001__qsl_6.283_12.566.png), [GMOS_A10__20251024__A10_QSL_001__qsl_18.850_5.027.png](sandbox:/mnt/data/GMOS_artifacts/GMOS_A10__20251024__A10_QSL_001__qsl_18.850_5.027.png), [GMOS_A10__20251024__A10_QSL_001__qsl_18.850_12.566.png](sandbox:/mnt/data/GMOS_artifacts/GMOS_A10__20251024__A10_QSL_001__qsl_18.850_12.566.png)
