# LoC Theorem A9 — Coherence–Fluctuation Link — 20251024

**Verdict:** PASS
**γ\* (Crooks coherence term):** -0.391939
**RMS residuals:** {"diag": 5.649129063713848e-16, "coh_raw": 1.5498353531006945, "coh_corrected": 1.537859272254188}

## Artifacts
- Metrics: [GMOS_THM_A9__20251024__A9_FLUCT_COH__metrics.json](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_A9__20251024__A9_FLUCT_COH__metrics.json)
- Work distributions: [GMOS_THM_A9__20251024__A9_FLUCT_COH__work_distributions.csv](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_A9__20251024__A9_FLUCT_COH__work_distributions.csv)
- Crooks residuals plot: [GMOS_THM_A9__20251024__A9_FLUCT_COH__crooks_residuals.png](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_A9__20251024__A9_FLUCT_COH__crooks_residuals.png)
