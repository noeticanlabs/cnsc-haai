# Glyph Field Atlas — H→Ne batch (with R017) — 2025-10-25

## He — seq=⊕
- Dir: [open](sandbox:artifacts/glyph_runs/He.GlyphPDE.05aee1fe)
- Tail-mean R: **0.426089**, RC=0.0196, 1-χ=0.95
- Δk (first two peaks): **8.885765876316732**; Vortices: net=-6, defects=1906
- Plots: [θ](sandbox:artifacts/glyph_runs/He.GlyphPDE.05aee1fe/theta.png), [a](sandbox:artifacts/glyph_runs/He.GlyphPDE.05aee1fe/a.png), [R(t)](sandbox:artifacts/glyph_runs/He.GlyphPDE.05aee1fe/R_trace.png), [E(k)](sandbox:artifacts/glyph_runs/He.GlyphPDE.05aee1fe/spectrum_theta.png), [vortex map](sandbox:artifacts/glyph_runs/He.GlyphPDE.05aee1fe/vortex_map.png)

## Ne — seq=⊕
- Dir: [open](sandbox:artifacts/glyph_runs/Ne.GlyphPDE.3ae34af1)
- Tail-mean R: **0.417839**, RC=0.0495, 1-χ=0.94
- Δk (first two peaks): **13.328648814475097**; Vortices: net=-3, defects=2027
- Plots: [θ](sandbox:artifacts/glyph_runs/Ne.GlyphPDE.3ae34af1/theta.png), [a](sandbox:artifacts/glyph_runs/Ne.GlyphPDE.3ae34af1/a.png), [R(t)](sandbox:artifacts/glyph_runs/Ne.GlyphPDE.3ae34af1/R_trace.png), [E(k)](sandbox:artifacts/glyph_runs/Ne.GlyphPDE.3ae34af1/spectrum_theta.png), [vortex map](sandbox:artifacts/glyph_runs/Ne.GlyphPDE.3ae34af1/vortex_map.png)

## Li — seq=⊕↻
- Dir: [open](sandbox:artifacts/glyph_runs/Li.GlyphPDE.c538bdc6)
- Tail-mean R: **0.424384**, RC=0.287, 1-χ=0.88
- Δk (first two peaks): **13.328648814475097**; Vortices: net=-2, defects=1864
- Plots: [θ](sandbox:artifacts/glyph_runs/Li.GlyphPDE.c538bdc6/theta.png), [a](sandbox:artifacts/glyph_runs/Li.GlyphPDE.c538bdc6/a.png), [R(t)](sandbox:artifacts/glyph_runs/Li.GlyphPDE.c538bdc6/R_trace.png), [E(k)](sandbox:artifacts/glyph_runs/Li.GlyphPDE.c538bdc6/spectrum_theta.png), [vortex map](sandbox:artifacts/glyph_runs/Li.GlyphPDE.c538bdc6/vortex_map.png)

## Be — seq=⊕↻
- Dir: [open](sandbox:artifacts/glyph_runs/Be.GlyphPDE.e2eb42f9)
- Tail-mean R: **0.426432**, RC=0.35, 1-χ=0.8
- Δk (first two peaks): **17.771531752633464**; Vortices: net=1, defects=1831
- Plots: [θ](sandbox:artifacts/glyph_runs/Be.GlyphPDE.e2eb42f9/theta.png), [a](sandbox:artifacts/glyph_runs/Be.GlyphPDE.e2eb42f9/a.png), [R(t)](sandbox:artifacts/glyph_runs/Be.GlyphPDE.e2eb42f9/R_trace.png), [E(k)](sandbox:artifacts/glyph_runs/Be.GlyphPDE.e2eb42f9/spectrum_theta.png), [vortex map](sandbox:artifacts/glyph_runs/Be.GlyphPDE.e2eb42f9/vortex_map.png)

## B — seq=⊕↻
- Dir: [open](sandbox:artifacts/glyph_runs/B.GlyphPDE.a5b5a8f4)
- Tail-mean R: **0.428886**, RC=0.36, 1-χ=0.75
- Δk (first two peaks): **8.885765876316732**; Vortices: net=3, defects=1903
- Plots: [θ](sandbox:artifacts/glyph_runs/B.GlyphPDE.a5b5a8f4/theta.png), [a](sandbox:artifacts/glyph_runs/B.GlyphPDE.a5b5a8f4/a.png), [R(t)](sandbox:artifacts/glyph_runs/B.GlyphPDE.a5b5a8f4/R_trace.png), [E(k)](sandbox:artifacts/glyph_runs/B.GlyphPDE.a5b5a8f4/spectrum_theta.png), [vortex map](sandbox:artifacts/glyph_runs/B.GlyphPDE.a5b5a8f4/vortex_map.png)

## N — seq=⊕↻
- Dir: [open](sandbox:artifacts/glyph_runs/N.GlyphPDE.19af03ea)
- Tail-mean R: **0.420391**, RC=0.3, 1-χ=0.9
- Δk (first two peaks): **13.328648814475097**; Vortices: net=-2, defects=1824
- Plots: [θ](sandbox:artifacts/glyph_runs/N.GlyphPDE.19af03ea/theta.png), [a](sandbox:artifacts/glyph_runs/N.GlyphPDE.19af03ea/a.png), [R(t)](sandbox:artifacts/glyph_runs/N.GlyphPDE.19af03ea/R_trace.png), [E(k)](sandbox:artifacts/glyph_runs/N.GlyphPDE.19af03ea/spectrum_theta.png), [vortex map](sandbox:artifacts/glyph_runs/N.GlyphPDE.19af03ea/vortex_map.png)

## O — seq=⊕↻
- Dir: [open](sandbox:artifacts/glyph_runs/O.GlyphPDE.f9141f65)
- Tail-mean R: **0.426582**, RC=0.484, 1-χ=0.91
- Δk (first two peaks): **8.885765876316732**; Vortices: net=-6, defects=1866
- Plots: [θ](sandbox:artifacts/glyph_runs/O.GlyphPDE.f9141f65/theta.png), [a](sandbox:artifacts/glyph_runs/O.GlyphPDE.f9141f65/a.png), [R(t)](sandbox:artifacts/glyph_runs/O.GlyphPDE.f9141f65/R_trace.png), [E(k)](sandbox:artifacts/glyph_runs/O.GlyphPDE.f9141f65/spectrum_theta.png), [vortex map](sandbox:artifacts/glyph_runs/O.GlyphPDE.f9141f65/vortex_map.png)

## F — seq=⊕↻
- Dir: [open](sandbox:artifacts/glyph_runs/F.GlyphPDE.12a5cce2)
- Tail-mean R: **0.425272**, RC=0.322, 1-χ=0.93
- Δk (first two peaks): **17.771531752633464**; Vortices: net=3, defects=1823
- Plots: [θ](sandbox:artifacts/glyph_runs/F.GlyphPDE.12a5cce2/theta.png), [a](sandbox:artifacts/glyph_runs/F.GlyphPDE.12a5cce2/a.png), [R(t)](sandbox:artifacts/glyph_runs/F.GlyphPDE.12a5cce2/R_trace.png), [E(k)](sandbox:artifacts/glyph_runs/F.GlyphPDE.12a5cce2/spectrum_theta.png), [vortex map](sandbox:artifacts/glyph_runs/F.GlyphPDE.12a5cce2/vortex_map.png)
