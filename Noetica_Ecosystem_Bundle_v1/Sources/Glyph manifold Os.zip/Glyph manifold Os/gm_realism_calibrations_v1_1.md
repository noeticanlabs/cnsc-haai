# Glyph Manifold OS — Real↔Glyph Calibrations for Realism (v1.1)

This pack unifies **unit conversions, particle parameters, and NPZ bindings** so the manifold runs in physically-calibrated units without fallbacks.

## A) Unit Conversions (authoritative)

**Energy–Frequency–Temperature**
- E[eV] = h·f ⇒ f[Hz] = E[eV] / h ≈ E[eV] × 2.417989e+14 Hz
- E[meV] ↔ f[Hz]: E[meV] = h(meV·s)·f ⇒ h ≈ 4.135668e-12 meV·s
- 1 eV ↔ 241.798924 THz; 1 meV ↔ 241.798924 GHz
- E[eV] = k_B·T ⇒ T[K] = E[eV] / k_B ≈ E[eV] × 11604.518122 K
- **Rule of thumb:** 1 meV ≈ 11.6045 K ≈ 241.799 GHz

**Angular frequency**
- E[meV] = ħ(meV·s)·ω[rad/s], with ħ ≈ 6.582120e-13 meV·s

**Magnetic resonance (Zeeman)**
- Electron: f = (γ/2π)·B ⇒ (γ/2π) ≈ 2.802495e+10 Hz/T
- Proton:   f = (γ/2π)·B ⇒ (γ/2π) ≈ 4.257748e+07 Hz/T

## B) Required NPZ Bindings


- `omega` key (one of): `phase_drive_omega`, `omega`, `omega_rad_per_unit`, `ω`
- Derived keys (must exist): `time_unit_s`, `frequency_hz`, `energy_mev`
- `scaling.json` per run recording provenance and residuals.

**Formulas**  
- `frequency_hz = omega / (2π * TIME_UNIT_S)`  
- `energy_mev = h(meV·s) * frequency_hz`, with h ≈ 4.135668e-12 meV·s  
- `energy_mev = ħ(meV·s) * omega`, with ħ ≈ 6.582120e-13 meV·s

## C) Temperature & Fields


- `E[eV] = k_B T` with k_B ≈ 0.000086173 eV/K ⇒ **1 meV ≈ 11.6045 K**.  
- Magnetic ESR/NMR links: `f = (γ/2π)·B`. Use catalog or species-specific γ.

## D) Particle Catalog (PDG-style subset)

CSV: [particle_catalog.csv](sandbox:/mnt/data/GMOS_artifacts/docs/particle_catalog.csv)

Columns: name, pdg_like_id, mass_eV, charge_e, spin, parity, g_factor, magnetic_moment_muB, lifetime_s, notes

## E) Quantum/Dynamic Parameters Schema

- Schema: [quantum_dynamic_params.schema.json](sandbox:/mnt/data/GMOS_artifacts/docs/quantum_dynamic_params.schema.json)

- Example: [quantum_dynamic_params.example.json](sandbox:/mnt/data/GMOS_artifacts/docs/quantum_dynamic_params.example.json)


Recommended NPZ echo fields (when applicable):
- `temperature_K`, `B_tesla`, `species`, `gamma_over_2pi_hz_per_t`
- `T1_relax_s`, `T2_dephase_s`, `Gamma1_s_inv`, `Gamma_phi_s_inv`
- `J_model`, `J_eta`, `J_omega_c` (bath)
- `detuning_rad_s`, `rabi_rad_s`

## F) Real→Glyph Mapping (Elements)


Per element phase-vector **Φ = (R,C,T,χ)** from NIST-like tables:
- `R = (E_ion^{-1} + EN)/max(...)`, `C = σ/σ_max`, `T = (N_iso/N_iso_max)/A`, `χ = W/W_max`.
PDE coefficients: `D=D0(1−χ)`, `Γ=Γ0(1−C)`, `K=K0(RC)`, `μ=μ0(C−χ)`, `ξ=ξ0 C`, `τ=τ0/(1+C)`, `V0→V0(1+R−χ)`.

## G) Gravity/Phase (BMV-class) — Optional


For two masses m1,m2 at separation d for time t, predicted gravitational phase:
- `φ_G = G m1 m2 t / (ħ d)`.
Record `(m1, m2, d, t, φ_G)` in run metadata when relevant.

## H) CI Gates Tied to Calibrations


- **C11/C13**: `alphaE_p95`, `alphaH1_p95`, `alphaH2_p95` must exist in NPZ when bounds are claimed.
- **E10/C23**: Spectrum plotted in k and Hz; ripple/gap tracked after binding.
- **VII (adaptive)**: Settling and recovery gates are unitless but logged with calibrated time.

---

**Usage:** New runs must include the NPZ bindings and (if quantum) the schema fields. If it’s not in this pack, it’s not considered calibrated.
