
import numpy as np, math

def _wrap_phase(x):
    return (x + np.pi) % (2*np.pi) - np.pi

def _laplacian_periodic(u, dx, dy):
    return ((np.roll(u,1,0)+np.roll(u,-1,0)-2*u)/(dy*dy) +
            (np.roll(u,1,1)+np.roll(u,-1,1)-2*u)/(dx*dx))

def _complex_order(theta):
    z = np.exp(1j*theta)
    zb = z.mean()
    return float(np.abs(zb)), float(np.angle(zb))

class GlyphSolverFull:
    """
    Phase+Envelope PDE (RK2 Heun, periodic BCs)
      thetä = (c^2 + D) ∇²θ − V0 sin(θ − θ0) − gamma θ̇ + K a sin(ψ − θ)
      τ ȧ    = (μ − β a^2) a + xi ∇² a + α R (K/K0) cos(ψ − θ) − δ a
    """
    def __init__(self, Nx=96, Ny=96, dx=1/96, dy=1/96, dt=1e-3, params=None, seed=123, K0=0.5, alpha=0.5, beta=1.0, delta=0.05):
        self.Nx, self.Ny, self.dx, self.dy, self.dt = Nx, Ny, dx, dy, float(dt)
        p = params or {}
        self.c     = float(p.get("c",1.0))
        self.D     = float(p.get("D",0.05))
        self.gamma = float(p.get("gamma",0.10))
        self.V0    = float(p.get("V0",0.5))
        self.K     = float(p.get("K",0.35))
        self.tau   = float(p.get("tau",1.0))
        self.mu    = float(p.get("mu",0.2))
        self.xi    = float(p.get("xi",0.05))
        self.beta  = float(p.get("beta",beta))
        self.delta = float(p.get("delta",delta))
        self.theta0= float(p.get("theta0",0.0))
        self.alpha = float(alpha)
        self.K0    = float(K0)
        rng = np.random.default_rng(seed)
        self.theta = rng.uniform(-np.pi, np.pi, size=(Ny, Nx)).astype(np.float64)
        self.v     = np.zeros_like(self.theta)  # theta_dot
        self.a     = np.clip(0.1 + 0.02*rng.standard_normal((Ny, Nx)), 0.0, 0.2).astype(np.float64)

    def cfl_guard(self):
        c = max(1e-12, self.c); D = max(1e-12, self.D); xi = max(1e-12, self.xi)
        wave_cap = min(self.dx, self.dy) / (math.sqrt(2.0)*c + 1e-12)
        diff_cap_theta = 0.25 * min(self.dx*self.dx, self.dy*self.dy) / (D + 1e-12)
        diff_cap_a     = 0.25 * min(self.dx*self.dx, self.dy*self.dy) / (xi + 1e-12)
        return min(wave_cap, diff_cap_theta, diff_cap_a)

    def _rhs(self, theta, v, a):
        lap_th = _laplacian_periodic(theta, self.dx, self.dy)
        R, psi = _complex_order(theta)
        acc = (self.c*self.c + self.D)*lap_th \
            - self.V0*np.sin(theta - self.theta0) \
            - self.gamma*v \
            + self.K*a*np.sin(psi - theta)
        lap_a = _laplacian_periodic(a, self.dx, self.dy)
        drive = self.alpha * R * (self.K/max(1e-12, self.K0)) * np.cos(psi - theta)
        adot = ((self.mu - self.beta*(a**2))*a) + self.xi*lap_a + drive - self.delta*a
        return acc, adot

    def step(self):
        dt = self.dt
        acc1, adot1 = self._rhs(self.theta, self.v, self.a)
        th1 = _wrap_phase(self.theta + dt*self.v)
        v1  = self.v + dt*acc1
        a1  = np.clip(self.a + (dt/max(1e-9, self.tau))*adot1, 0.0, 10.0)
        acc2, adot2 = self._rhs(th1, v1, a1)
        self.theta = _wrap_phase(self.theta + dt*0.5*(self.v + v1))
        self.v     = self.v + dt*0.5*(acc1 + acc2)
        self.a     = np.clip(self.a + (dt/max(1e-9, self.tau))*0.5*(adot1 + adot2), 0.0, 10.0)
        R = np.abs(np.exp(1j*self.theta).mean())
        return float(R)
