from scipy.interpolate import interp1d

# Bosch–Hale-like synthetic fusion rate for D-T
BH_T = [1e6, 2e6, 3e6, 5e6, 10e6, 15e6]  # K
BH_sv = [1e-26, 3e-25, 1e-23, 5e-22, 1e-20, 5e-19]  # cm^3/s

fusion_interp = interp1d(BH_T, BH_sv, kind='linear', fill_value="extrapolate")

def fusion_energy_output(n1, n2, T):
    T_K = T * 11604  # eV → K
    rate = fusion_interp(T_K)
    energy = n1 * n2 * rate
    return energy