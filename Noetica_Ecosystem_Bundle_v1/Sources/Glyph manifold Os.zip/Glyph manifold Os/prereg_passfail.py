
import json, sys, argparse
def decide(EA, EB):
    strong = (EA is not None and EB is not None and EA <= 0.70 and EB <= 0.70)
    moderate = ((EA is not None and EB is not None) and ((EA <= 0.70 and EB <= 0.80) or (EB <= 0.70 and EA <= 0.80)))
    if strong: return "STRONG PASS"
    if moderate: return "MODERATE PASS"
    if (EA is None) or (EB is None): return "INDETERMINATE"
    if (EA >= 0.90) or (EB >= 0.90): return "FAIL"
    return "NO PASS"
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", type=str, help="Inline JSON string with thresholds", required=False)
    ap.add_argument("--json_file", type=str, help="Path to JSON file", required=False)
    args = ap.parse_args()
    if not args.data and not args.json_file:
        print("Provide --data or --json_file"); sys.exit(2)
    data = json.loads(args.data) if args.data else json.load(open(args.json_file))
    A = data["platforms"]["A"]; B = data["platforms"]["B"]
    EA = (A["Ac_multi"]/A["Ac_single"]) if A.get("Ac_single") and A.get("Ac_multi") else None
    EB = (B["Ac_multi"]/B["Ac_single"]) if B.get("Ac_single") and B.get("Ac_multi") else None
    out = {"E_platform_A":EA,"E_platform_B":EB,"decision":decide(EA,EB),
           "bounds":{"strong":"<=0.70 both","moderate":"(<=0.70 & <=0.80)","fail":">=0.90 any"}}
    print(json.dumps(out, indent=2))
    open("decision.txt","w").write(json.dumps(out, indent=2))
if __name__ == "__main__": main()
