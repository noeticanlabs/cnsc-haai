# LoC Theorem A6 — Recoverability Lower Bound — 20251024

**Verdict:** PASS (a*=5.0, violations=0.0)

## Artifacts
- Metrics: [GMOS_THM_A6__20251024__A6_RECOV_LB__metrics.json](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_A6__20251024__A6_RECOV_LB__metrics.json)
- Pairs CSV: [GMOS_THM_A6__20251024__A6_RECOV_LB__pairs.csv](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_A6__20251024__A6_RECOV_LB__pairs.csv)
- Plot: [GMOS_THM_A6__20251024__A6_RECOV_LB__F_vs_gap.png](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_A6__20251024__A6_RECOV_LB__F_vs_gap.png)
