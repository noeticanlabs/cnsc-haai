# Coherence Shells — Radial Profile — 20251024

**Columns used:** radius=`r`, coherence=`c`
**Samples (N):** 180
**Coherence wall (|dC/dr| max):** r≈0.0707107, C≈0.997655
**Monotonicity score:** 0.475
**Exponential tail length (ξ):** ~ 10.7

## Artifacts
- Cleaned profile: [csv](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_SHELLS__20251024__profile_cleaned.csv)
- Metrics: [json](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_SHELLS__20251024__metrics.json)
- Scaling: [json](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_SHELLS__20251024__scaling.json)
- Plot C vs r: [png](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_SHELLS__20251024__C_vs_r.png)
- Gradient dC/dr: [png](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_SHELLS__20251024__dCdr.png)
- Exponential tail fit: [png](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_SHELLS__20251024__expfit.png)
- Context canvas: [md](sandbox:/mnt/data/canvas_f_coherence_shells.md)
- Operators appendix: [md](sandbox:/mnt/data/Appendix_B_Full_Operators_and_Multimethod_Verification.md)