
"""Glyph library and token mapping (ASCII-safe).
We parse/emit glyphic PDE strings, but internally use ASCII tokens.
"""
# Display glyphs
GLYPH_LAPL = "∆φ"
GLYPH_DAMP = "◯"
GLYPH_INJ  = "⊕"
GLYPH_SPIN = "↻"

# ASCII tokens
LAPL = "LAPL"
DAMP = "DAMP"
INJ  = "INJ"
SPIN = "SPIN"

ASCII_TO_GLYPH = {
    LAPL: GLYPH_LAPL,
    DAMP: GLYPH_DAMP,
    INJ:  GLYPH_INJ,
    SPIN: GLYPH_SPIN,
}

GLYPH_TO_ASCII = {v:k for k,v in ASCII_TO_GLYPH.items()}

def coeffs_to_glyph_line(coeffs):
    """coeffs: dict of ASCII token -> float. Returns a pretty glyph line."""
    parts = []
    for key in (LAPL, DAMP, INJ, SPIN):
        if key in coeffs and abs(coeffs[key]) > 0:
            parts.append(f"{coeffs[key]:+0.3f}·{ASCII_TO_GLYPH[key]}")
    return " ".join(parts) if parts else "0.000·" + GLYPH_LAPL
