
import numpy as np
from numpy.fft import rfftn, irfftn, rfftfreq, fftfreq

def wrap_phase(x):
    return (x + np.pi) % (2*np.pi) - np.pi

def kgrid(Ny,Nx,dx,dy):
    ky = fftfreq(Ny, d=dy)*2*np.pi
    kx = rfftfreq(Nx, d=dx)*2*np.pi
    KY,KX = np.meshgrid(ky,kx,indexing='ij')
    K2 = KX*KX + KY*KY
    return KX, KY, K2

def lap_fft(u, dx, dy):
    Ny,Nx = u.shape
    _,_,K2 = kgrid(Ny,Nx,dx,dy)
    return irfftn(-K2*rfftn(u), s=u.shape)

class GlyphSolver:
    def __init__(self, Nx=96, Ny=96, dx=1/96, dy=1/96, dt=5e-4, mode="imex", params=None, seed=1234):
        self.Nx,self.Ny,self.dx,self.dy,self.dt = Nx,Ny,dx,dy,dt
        self.mode = mode
        self.params = params or {"c":1.0,"D":0.08,"gamma":0.2,"V0":0.6,"K":0.5,"tau":1.0,"mu":0.2,"xi":0.05,"beta":1.0,"delta":0.05,"theta0":0.0}
        rng = np.random.default_rng(seed)
        self.theta = rng.uniform(-np.pi, np.pi, size=(Ny,Nx))
        self.thd = np.zeros_like(self.theta)
        self.a = np.clip(0.1 + 0.02*rng.standard_normal((Ny,Nx)), 0.0, 0.2)

    def source(self):
        return 0.0*self.theta

    def order(self):
        z = np.exp(1j*self.theta); zbar = z.mean()
        return float(np.abs(zbar)), float(np.angle(zbar))

    def _lap(self, u):
        return lap_fft(u, self.dx, self.dy)

    def step(self):
        p=self.params; dt=self.dt
        R,psi = self.order()
        lap_theta = self._lap(self.theta)
        F = (p["c"]**2 + p["D"]) * lap_theta \
            - p["V0"]*np.sin(self.theta - p.get("theta0",0.0)) \
            - p["gamma"]*self.thd \
            + p["K"]*self.a*np.sin(psi - self.theta) \
            + self.source()
        if self.mode == "rk4":
            k1d = F;  k1t = self.thd
            k2d = F;  k2t = self.thd + 0.5*dt*k1d
            k3d = F;  k3t = self.thd + 0.5*dt*k2d
            k4d = F;  k4t = self.thd + dt*k3d
            self.thd  = self.thd  + (dt/6.0)*(k1d + 2*k2d + 2*k3d + k4d)
            self.theta = wrap_phase(self.theta + (dt/6.0)*(k1t + 2*k2t + 2*k3t + k4t))
        else:
            # IMEX: treat diffusion implicitly on thd
            # thd_{n+1} = (thd_n + dt * (F - (c^2+D)lap_theta)) / (1 + dt*(c^2+D)k^2)
            from numpy.fft import rfftn, irfftn
            c2D = (p["c"]**2 + p["D"])
            F_no_diff = F - c2D*lap_theta
            Thd = rfftn(self.thd); Fnd = rfftn(F_no_diff)
            # build K2
            from numpy.fft import rfftfreq, fftfreq
            ky = fftfreq(self.Ny, d=self.dy)*2*np.pi
            kx = rfftfreq(self.Nx, d=self.dx)*2*np.pi
            KY,KX = np.meshgrid(ky,kx,indexing='ij'); K2 = KX*KX + KY*KY
            denom = (1.0 + dt*c2D*K2)
            self.thd  = irfftn((Thd + dt*Fnd)/denom, s=self.theta.shape)
            self.theta = wrap_phase(self.theta + dt*self.thd)
        # envelope
        R,psi = self.order()
        lap_a = self._lap(self.a)
        drive = 0.5 * R * (p["K"]/max(1e-12, 0.5)) * np.cos(psi - self.theta)
        adot = ((p["mu"] - p["beta"]*(self.a**2)) * self.a) + p["xi"]*lap_a + drive - p["delta"]*self.a
        self.a = np.clip(self.a + (dt/max(1e-6, p["tau"])) * adot, 0.0, 10.0)
        return R

    def cfl_guard(self):
        p=self.params
        c=p["c"]; D=p["D"]
        dt_wave = min(self.dx,self.dy)/(np.sqrt(2)*max(1e-12,c))
        dt_diff = 0.25*min(self.dx*self.dx,self.dy*self.dy)/max(1e-12,D)
        return 0.9*min(dt_wave, dt_diff)

def n2_parity_error(N=64, dx=1/64, dy=1/64):
    rng=np.random.default_rng(0)
    u=rng.standard_normal((N,N))
    from numpy.fft import rfftn, irfftn, rfftfreq, fftfreq
    ky = fftfreq(N, d=dy)*2*np.pi; kx = rfftfreq(N, d=dx)*2*np.pi
    KY,KX = np.meshgrid(ky,kx,indexing='ij'); K2 = KX*KX+KY*KY
    lapF = irfftn(-K2*rfftn(u), s=u.shape)
    lapS = ((np.roll(u,1,0)+np.roll(u,-1,0)-2*u)/(dy*dy) + (np.roll(u,1,1)+np.roll(u,-1,1)-2*u)/(dx*dx))
    num=np.linalg.norm(lapF - lapS); den=np.linalg.norm(lapF)+1e-12
    return float(num/den)
