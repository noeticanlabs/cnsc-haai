# GMOS LAB OPPOSING ARROWS  20251024  report

## Coherence Shells — attachment (20251024)

**CI verdict:** **WARN**  
- chi_wall: 0.0  
- monotonicity: 0.4748603351955307  
- xi (corr. length): 10.709794022036126

**Artifacts**
- Shells dossier: [md](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_SHELLS__20251024__report.md)
- Metrics: [json](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_SHELLS__20251024__metrics.json)
- Scaling: [json](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_SHELLS__20251024__scaling.json)
- CI gate: [json](sandbox:/mnt/data/GMOS_artifacts/GMOS_CI__20251024__SHELLS_GATE.json)
