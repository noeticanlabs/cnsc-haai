import json
import numpy as np
from scipy.fftpack import fft2, fftshift

# Load config
with open("glyph_cfg_v4_1.json") as f:
    cfg = json.load(f)

# Load fields
theta = np.load("sim_output_theta.npz")["theta"]

# Spectrum analysis
spec = np.abs(fftshift(fft2(theta)))**2
print("[✓] Spectrum computed.")

# Legality gate (simplified logic)
tau_index = cfg.get("temporal", {}).get("τ_index", 1)
if not is_prime(tau_index):
    print("[✘] Glyph emission blocked: τ_k={} is not prime.".format(tau_index))
else:
    print("[✓] Glyph emission allowed.")

def is_prime(n):
    if n < 2: return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0: return False
    return True
