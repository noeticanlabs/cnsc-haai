# LoC Theorem A3 — Spohn Entropy Production ≥ 0 — 20251024

**Verdict:** PASS (violation rate=0.0)

## Artifacts
- Metrics: [GMOS_THM_A3__20251024__A3_SPOHN_EP__metrics.json](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_A3__20251024__A3_SPOHN_EP__metrics.json)
- Time series (per T,ν): check folder for CSV/PNGs with 'timeseries_' and 'EP_'.
