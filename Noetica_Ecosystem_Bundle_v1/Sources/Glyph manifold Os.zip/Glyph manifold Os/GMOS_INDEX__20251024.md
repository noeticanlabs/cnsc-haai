# GMOS Index — 20251024

| Item | Verdict | Dossier | Metrics |
|---|---|---|---|
| LAB:Full PDE System | READY | [link](sandbox:/mnt/data/GMOS_artifacts/GMOS_LAB_FULL_PDE__20251024__report.md) | [manifest](sandbox:/mnt/data/GMOS_artifacts/GMOS_LAB_FULL_PDE__20251024__manifest.json) |
| LAB:Opposing Arrows | READY | [link](sandbox:/mnt/data/GMOS_artifacts/GMOS_LAB_OPPOSING_ARROWS__20251024__report.md) | [manifest](sandbox:/mnt/data/GMOS_artifacts/GMOS_LAB_OPPOSING_ARROWS__20251024__manifest.json) |