import numpy as np

def solve_theta_step(theta, params):
    c2 = params['c']**2
    beta = params['beta']
    gamma = params['gamma']
    V0 = params['V0']
    alpha = params['alpha']
    kappa = params['kappa']
    lam = params['lambda']
    mu = params['mu']
    dt = params['dt']
    rho = params.get('rho', np.ones_like(theta))
    T = params.get('T', np.zeros_like(theta))
    theta0 = params.get('theta0', 0)
    S_f = params.get('S_f', np.zeros_like(theta))

    laplacian = lambda f: np.gradient(np.gradient(f)[0])[0]
    grad_theta = np.gradient(theta)
    grad_sq = sum([g**2 for g in grad_theta])

    d2theta = (
        c2 * laplacian(theta) - beta * np.sin(theta) - gamma * np.gradient(theta)[0] +
        V0 * np.sin(theta - theta0) + alpha * np.divmod(rho * grad_theta[0], 1)[0] +
        kappa * laplacian(T) + S_f + lam * grad_sq - mu * theta**4
    )
    return theta + dt * d2theta