
import json, re, hashlib, time
from pathlib import Path

ROOT = Path("/mnt/data/GMOS_artifacts")

def _link(p: Path) -> str:
    return f"[{p.name}](sandbox:{p.as_posix()})" if p.exists() else f"*missing:* {p.name}"

def _read_json(p: Path):
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}

def _todaycode() -> str:
    return time.strftime("%Y%m%d")

# --- Bundlers per family -----------------------------------------------------

def bundle_pde_gpe2d(datecode: str, run_id: str) -> Path:
    prefix = f"GMOS_PDE_GPE2D__{datecode}__{run_id}__"
    files = {
        "well_json": ROOT / f"{prefix}qa_wellposed.json",
        "well_png":  ROOT / f"{prefix}qa_wellposed_overlay.png",
        "well_ts":   ROOT / f"{prefix}qa_wellposed_timeseries.csv",
        "energy":    ROOT / f"{prefix}qa_energy.json",
        "spectra":   ROOT / f"{prefix}qa_spectra.json",
        "vort":      ROOT / f"{prefix}qa_vortices.json",
        "policy":    ROOT / f"GMOS_QA_POLICY__{datecode}__continuity_bound.json"
    }
    verdict = _read_json(files["well_json"]).get("verdict", "UNKNOWN")
    md = f"""# GMOS Run — {run_id} (GPE2D) — {datecode}

**Continuity QA:** **{verdict}** (policy: `K_bound(t)=exp(0.01 t)`, t=0 excluded)

## Artifacts
- {_link(files["well_png"])}
- {_link(files["well_json"])}
- {_link(files["well_ts"])}
- Energy: {_link(files["energy"])}
- Spectra: {_link(files["spectra"])}
- Vortices: {_link(files["vort"])}
- Policy: {_link(files["policy"])}
"""
    out = ROOT / f"GMOS_RUN_{run_id}__{datecode}.md"
    out.write_text(md); return out

def bundle_qtls(datecode: str, run_id: str) -> Path:
    prefix = f"GMOS_QTLS__{datecode}__{run_id}__"
    files = {
        "scaling": ROOT / f"{prefix}scaling.json",
        "metrics": ROOT / f"{prefix}metrics.json",
        "times":   ROOT / f"{prefix}timeseries.csv",
        "plots":   [ROOT / f"{prefix}relative_entropy_T0p5K.png",
                    ROOT / f"{prefix}relative_entropy_T0p1K.png",
                    ROOT / f"{prefix}relative_entropy_T0p02K.png",
                    ROOT / f"{prefix}relative_entropy_T0p005K.png",
                    ROOT / f"{prefix}recovery_vs_beta.png"],
        "report":  ROOT / f"{prefix}run_report.txt",
    }
    mono = _read_json(files["metrics"]).get("qa",{}).get("monotone_relative_entropy")
    plots = ", ".join(_link(p) for p in files["plots"])
    md = f"""# GMOS Run — {run_id} (QTLS) — {datecode}

**Relative entropy monotonicity:** **{mono}**

## Artifacts
- Scaling: {_link(files["scaling"])}
- Metrics: {_link(files["metrics"])}
- Timeseries: {_link(files["times"])}
- Plots: {plots}
- Report: {_link(files["report"])}
"""
    out = ROOT / f"GMOS_RUN_{run_id}__{datecode}.md"
    out.write_text(md); return out

def bundle_qtls_variants(datecode: str, run_id: str) -> Path:
    prefix = f"GMOS_QTLS__{datecode}__{run_id}__"
    files = {
        "metrics": ROOT / f"{prefix}metrics.json",
        "csv":     ROOT / f"{prefix}recovery_final.csv",
        "plot":    ROOT / f"{prefix}recovery_variants_vs_beta.png",
        "report":  ROOT / f"{prefix}run_report.txt",
    }
    deltas = _read_json(files["metrics"]).get("summary", {})
    md = f"""# GMOS Run — {run_id} (QTLS Petz variants) — {datecode}

**Δ fidelity vs Petz:** {json.dumps(deltas)}

## Artifacts
- Metrics: {_link(files["metrics"])}
- CSV: {_link(files["csv"])}
- Plot: {_link(files["plot"])}
- Report: {_link(files["report"])}
"""
    out = ROOT / f"GMOS_RUN_{run_id}__{datecode}.md"
    out.write_text(md); return out

def bundle_theorem_A10(datecode: str, label: str) -> Path:
    prefix = f"GMOS_A10__{datecode}__{label}__"
    summary = _read_json(ROOT / f"{prefix}summary.json")
    table = ROOT / f"{prefix}qsl_bounds.csv"
    verdict = "unknown"
    tight = None
    try:
        import pandas as pd
        df = pd.read_csv(table)
        verdict = bool((df["violation_rate_cQ1"] < 0.01).all())
        tight = float(df["cQ_star"].max())
    except Exception:
        pass
    plot_links = ", ".join(_link(p) for p in ROOT.glob(f"{prefix}qsl_*.png"))
    md = f"""# LoC Theorem A10 — QSL Bound (empirical) — {datecode}

**Verdict:** **{verdict}** (c_Q=1); **max c_Q\\*** ≈ {tight if tight is not None else "n/a"}

## Artifacts
- Summary: {_link(ROOT / f"{prefix}summary.json")}
- Table: {_link(table)}
- Plots: {plot_links}
"""
    out = ROOT / f"GMOS_THEOREM_A10__{datecode}__{label}.md"
    out.write_text(md); return out

def bundle_theorem_A11(datecode: str, label: str) -> Path:
    prefix = f"GMOS_A11__{datecode}__{label}__"
    metrics = _read_json(ROOT / f"{prefix}metrics.json")
    md = f"""# LoC Theorem A11 — Coherence–Recovery Equality (dephasing) — {datecode}

**Metrics:** {json.dumps(metrics)}

## Artifacts
- Metrics: {_link(ROOT / f"{prefix}metrics.json")}
- Cases: {_link(ROOT / f"{prefix}petz_cases.csv")}
- Plot: {_link(ROOT / f"{prefix}petz_cases.png")}
"""
    out = ROOT / f"GMOS_THEOREM_A11__{datecode}__{label}.md"
    out.write_text(md); return out

# --- Dispatcher --------------------------------------------------------------
def bundle(run_key: str) -> Path:
    # run_key examples:
    #   PDE:GPE2D:R017
    #   QTLS:R022
    #   QTLSVAR:R023
    #   THM:A10:A10_QSL_001
    #   THM:A11:A11_EQ_001
    datecode = _todaycode()
    parts = run_key.split(":")
    if parts[0] == "PDE" and parts[1] == "GPE2D":
        return bundle_pde_gpe2d(datecode, parts[2])
    if parts[0] == "QTLS":
        return bundle_qtls(datecode, parts[1])
    if parts[0] == "QTLSVAR":
        return bundle_qtls_variants(datecode, parts[1])
    if parts[0] == "THM" and parts[1] == "A10":
        return bundle_theorem_A10(datecode, parts[2])
    if parts[0] == "THM" and parts[1] == "A11":
        return bundle_theorem_A11(datecode, parts[2])
    raise ValueError(f"Unknown run_key: {run_key}")

def bundle_all(known_keys=None):
    if known_keys is None:
        known_keys = [
            "PDE:GPE2D:R017",
            "PDE:GPE2D:R012",
            "QTLS:R022",
            "QTLSVAR:R023",
            "THM:A10:A10_QSL_001",
            "THM:A11:A11_EQ_001",
        ]
    outs = []
    for k in known_keys:
        try:
            outs.append(bundle(k).as_posix())
        except Exception as e:
            outs.append(f"ERROR:{k}:{e}")
    return outs
