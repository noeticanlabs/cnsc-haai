# LoC Theorem B1 — Petz Dominance (σ-typical ensemble) — 20251024

**Verdict:** PASS
**Means:** {"F_petz": 0.9936068284241807, "F_rot": 0.9936068283712095, "F_twirled": 0.9936068284241807}
**Margins (Petz minus variants):** {"rot": 5.2971182995520394e-11, "twirled": 0.0}

## Artifacts
- Metrics: [GMOS_THM_B1__20251024__B1_PETZ_DOM__metrics.json](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_B1__20251024__B1_PETZ_DOM__metrics.json)
- CSV: [GMOS_THM_B1__20251024__B1_PETZ_DOM__ensemble_fidelities.csv](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_B1__20251024__B1_PETZ_DOM__ensemble_fidelities.csv)
- Histograms: [GMOS_THM_B1__20251024__B1_PETZ_DOM__hist_petz_minus_rot.png](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_B1__20251024__B1_PETZ_DOM__hist_petz_minus_rot.png), [GMOS_THM_B1__20251024__B1_PETZ_DOM__hist_petz_minus_twirled.png](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_B1__20251024__B1_PETZ_DOM__hist_petz_minus_twirled.png)
