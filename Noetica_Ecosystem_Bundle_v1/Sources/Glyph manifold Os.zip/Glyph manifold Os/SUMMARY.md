# Expanded Thermal Fits (1‑D library, ridge path + stability gate)

## thermal_10g_series
- Best λ: **1.00e-04**  | Score: **0.7120**  | ||w||₂: 1.49e+05
- Glyph subset (∆, ◯, ⊕): **{'LAPL': 67301.95308752527, 'DAMP': 65495.23830980699, 'INJ': 59714.59383727184}**

## thermal_1g_series
- Best λ: **1.00e-04**  | Score: **0.7587**  | ||w||₂: 1.51e+05
- Glyph subset (∆, ◯, ⊕): **{'LAPL': 78147.64674951465, 'DAMP': 23602.699707135656, 'INJ': 19475.109909707964}**
