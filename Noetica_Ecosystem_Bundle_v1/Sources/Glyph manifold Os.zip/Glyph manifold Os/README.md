# GM-OS Checkpoint — 20251025_175034

## Gates (HARD)

[]

## Cold spectral suite (E10 & C23)

{
  "dir": "/mnt/data/GMOS_artifacts/artifacts/glyph_runs/ColdE10Try8_full.c47e7e3b",
  "ci": [
    {
      "schema": "GMOS.CI.E10.LPAmplitude.v1",
      "lp_amp": 0.09435558209909804,
      "threshold_max": 0.12,
      "verdict": "PASS",
      "level": "HARD"
    },
    {
      "schema": "GMOS.CI.C23.SpectralGap.v1",
      "gap_dk": 8.885765876316734,
      "threshold_min": 0.05,
      "verdict": "PASS",
      "level": "HARD"
    }
  ],
  "spectrum": {
    "lp_amp": 0.09435558209909804,
    "gap_dk": 8.885765876316734,
    "params": {
      "c": 1.0,
      "D": 0.04,
      "gamma": 0.16,
      "V0": 0.145,
      "K": 0.095,
      "tau": 1.25,
      "mu": 0.15,
      "xi": 0.065,
      "beta": 1.0,
      "delta": 0.05,
      "theta0": 0.0
    },
    "steps": 2400,
    "dt": 0.0004340277777690972
  },
  "scaling_present": true,
  "theta_final_exists": true
}

## Poincaré/Sobolev α-fits

_no alpha fits found_

## Arrow-of-Time AUC (long)

_no warm runs found_

## Solvers

[
  {
    "path": "/mnt/data/GMOS_artifacts/tools/glyph_solver_core_v1.py",
    "sha256": "8442c2325a390747725303a34b7070c0a3a91d3456e86ff69fd0e40f09af8a65",
    "bytes": 2240
  },
  {
    "path": "/mnt/data/GMOS_artifacts/tools/glyph_solver_full_v1.py",
    "sha256": "cf19f2f28415a6c0a9514cd36a4de96e1bfaf2e1430580ab5f2c284385955c40",
    "bytes": 3416
  }
]

## NPZ unit-stamp report

[
  {
    "path": "/mnt/data/optical_series.npz",
    "has_frequency_hz": false,
    "has_energy_mev": false,
    "omega_keys": []
  },
  {
    "path": "/mnt/data/thermal_10g_series.npz",
    "has_frequency_hz": false,
    "has_energy_mev": false,
    "omega_keys": []
  },
  {
    "path": "/mnt/data/thermal_1g_series.npz",
    "has_frequency_hz": false,
    "has_energy_mev": false,
    "omega_keys": []
  }
]