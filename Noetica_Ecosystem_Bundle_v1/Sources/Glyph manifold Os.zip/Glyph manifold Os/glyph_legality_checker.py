import numpy as np
from sympy import isprime

def is_prime_index(t, interval=1):
    return isprime(int(t / interval))

def check_emission_legality(t, PAS, PAS_zeta, glyph_status):
    τk = is_prime_index(t, interval=1)
    if PAS < glyph_status['θ']:
        return False
    if abs(PAS_zeta) > glyph_status['ε_drift']:
        return False
    return τk and glyph_status['GLYPHLOCK'] and glyph_status['AURA_OUT']