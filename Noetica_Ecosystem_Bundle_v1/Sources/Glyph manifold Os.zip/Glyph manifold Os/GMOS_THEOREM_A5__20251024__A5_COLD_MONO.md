# LoC Theorem A5 — Cold-limit Recovery Monotonicity — 20251024

**Verdict:** FAIL (Spearman ρ=0.9029411764705882)

## Artifacts
- Metrics: [GMOS_THM_A5__20251024__A5_COLD_MONO__metrics.json](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_A5__20251024__A5_COLD_MONO__metrics.json)
- Plot: [GMOS_THM_A5__20251024__A5_COLD_MONO__F_vs_beta.png](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_A5__20251024__A5_COLD_MONO__F_vs_beta.png)
