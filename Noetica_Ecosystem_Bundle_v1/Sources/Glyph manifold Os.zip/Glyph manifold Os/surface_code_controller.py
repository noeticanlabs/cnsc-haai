#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Surface Code++ controller — dynamic QEC modes for the Glyph Manifold
=====================================================================
Registers three time-dynamic physical code modes (hex, walking, iSWAP),
adds leakage/c-phase telemetry proxies, and a tiny policy that switches
modes on-the-fly. Also exposes a stub for decoder-prior RL updates and
integrates with the Coherence Contract orchestrator.

This file is designed to live alongside:
  • CoherentHybridRFE Integration — v1.0 (canvas)
  • coherence_contract_framework_v_1.py (uploaded)
  • glyph_quantum_hybrid_module.py (uploaded)

Run the demo() below to see mode switching and logging in action.
"""
from __future__ import annotations
import math
from dataclasses import dataclass
from typing import Dict, Any, Optional, Tuple

import numpy as np

# Local imports — for canvas/collab environment
import sys
sys.path.append("/mnt/data")

from coherence_contract_framework_v_1 import (
    CoherenceOrchestrator,
    Summarizer,
    DummySearch,
    LoCSim,
)

try:
    from Coherent_Hybrid_Rfe_Integration___V1 import CoherentHybridRFE
except Exception:
    from coherent_hybrid_rfe_integration_v1 import CoherentHybridRFE


# -----------------------------
# Telemetry proxies (fast, cheap)
# -----------------------------

def leakage_proxy(Psi: np.ndarray) -> float:
    theta = np.angle(Psi)
    F = np.fft.fft2(theta)
    mag = np.abs(F)
    h, w = mag.shape
    yy, xx = np.mgrid[0:h, 0:w]
    cx, cy = w // 2, h // 2
    r = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2)
    r_norm = r / (0.5 * max(h, w))
    tail_mask = r_norm > 0.6
    tail = float(np.mean(mag[tail_mask]))
    body = float(np.mean(mag[~tail_mask]) + 1e-12)
    return float(tail / body)

def cphase_proxy(Psi: np.ndarray, dx: float, dy: float) -> float:
    theta = np.angle(Psi)
    d2x = (np.roll(theta, -1, 0) - 2 * theta + np.roll(theta, 1, 0)) / (dx * dx)
    d2y = (np.roll(theta, -1, 1) - 2 * theta + np.roll(theta, 1, 1)) / (dy * dy)
    lap = np.abs(d2x + d2y)
    return float(np.mean(lap))


@dataclass
class QECMode:
    name: str
    curvature_hint: float
    lambda_weight: float
    steps_per_epoch: int

    def apply(self, rfe: CoherentHybridRFE):
        if self.name == "hex":
            rfe.params["Gamma"] = min(rfe.params.get("Gamma", 0.0), 0.02)
            rfe.params["g"] = rfe.params.get("g", 0.0)
        elif self.name == "walk":
            rfe.params["Gamma"] = max(0.01, rfe.params.get("Gamma", 0.0))
        elif self.name == "iswap":
            rfe.params["V0"] = 0.0
            rfe.params["g"] = rfe.params.get("g", 0.0) * 0.5
        rfe._engine.Gamma = rfe.params["Gamma"]
        rfe._engine.g = rfe.params["g"]
        rfe._engine.V0 = rfe.params["V0"]


HEX = QECMode("hex", curvature_hint=0.07, lambda_weight=1.6, steps_per_epoch=8)
WALK = QECMode("walk", curvature_hint=0.10, lambda_weight=1.4, steps_per_epoch=8)
ISWP = QECMode("iswap", curvature_hint=0.11, lambda_weight=1.3, steps_per_epoch=8)


class SurfaceCodeController:
    def __init__(self, rfe: CoherentHybridRFE, tau_leak: float = 0.15, phi_c: float = 0.08):
        self.rfe = rfe
        self.tau_leak = tau_leak
        self.phi_c = phi_c
        self.mode: QECMode = HEX
        self.decoder_prior: Dict[str, float] = {"bias": 0.0}
        self.history = []

    def policy(self, Psi: np.ndarray) -> QECMode:
        leak = leakage_proxy(Psi)
        phi = cphase_proxy(Psi, self.rfe.dx, self.rfe.dy)
        if leak > self.tau_leak:
            return WALK
        if phi > self.phi_c:
            return ISWP
        return HEX

    def rl_update_decoder_prior(self, logical_err_rate: float):
        self.decoder_prior["bias"] = float(np.clip(
            self.decoder_prior["bias"] - 0.1 * (logical_err_rate - 0.5), -1.0, 1.0))

    def step_epoch(self, Psi: np.ndarray, n_steps: Optional[int] = None) -> Dict[str, Any]:
        self.mode = self.policy(Psi)
        self.mode.apply(self.rfe)
        k = n_steps or self.mode.steps_per_epoch
        out = self.rfe.call({"Psi": Psi, "n_steps": k})
        Psi_next = out.get("Psi_next", Psi)
        metrics = out.get("metrics", {})
        logical_err = max(0.0, 1.0 - float(metrics.get("coherence", 0.0)))
        self.rl_update_decoder_prior(logical_err)
        rec = {
            "mode": self.mode.name,
            "leakage_proxy": leakage_proxy(Psi_next),
            "cphase_proxy": cphase_proxy(Psi_next, self.rfe.dx, self.rfe.dy),
            "coherence": metrics.get("coherence", 0.0),
            "latency_ms": metrics.get("latency_ms", 0.0),
            "logical_err_proxy": logical_err,
            "decoder_prior": dict(self.decoder_prior),
        }
        self.history.append(rec)
        return {"Psi": Psi_next, "record": rec}


def build_pipeline(nx: int = 64, ny: int = 64) -> Tuple[CoherenceOrchestrator, SurfaceCodeController, np.ndarray]:
    rfe = CoherentHybridRFE(nx=nx, ny=ny, dt=0.02, params=dict(g=0.2, V0=0.4, Gamma=0.01))
    mods = [DummySearch(), Summarizer(), LoCSim(), rfe]
    orch = CoherenceOrchestrator(mods)
    x = np.linspace(0, 2 * math.pi, nx, endpoint=False)
    y = np.linspace(0, 2 * math.pi, ny, endpoint=False)
    X, Y = np.meshgrid(x, y, indexing='ij')
    Psi0 = np.exp(1j * (2.0 * X + 1.0 * Y)) * (1.0 + 0.05 * (np.random.rand(nx, ny) - 0.5))
    ctrl = SurfaceCodeController(rfe)
    return orch, ctrl, Psi0


def demo(epochs: int = 10, seed: int = 0) -> Dict[str, Any]:
    np.random.seed(seed)
    orch, ctrl, Psi = build_pipeline()
    report = {"records": []}
    for _ in range(epochs):
        step = ctrl.step_epoch(Psi)
        Psi = step["Psi"]
        report["records"].append(step["record"])
        orch.adapt()
    modes = [r["mode"] for r in report["records"]]
    avg_coh = float(np.mean([r["coherence"] for r in report["records"]]))
    report.update({
        "modes": modes,
        "avg_coherence": round(avg_coh, 3),
        "final_decoder_prior": report["records"][-1]["decoder_prior"],
    })
    return report
