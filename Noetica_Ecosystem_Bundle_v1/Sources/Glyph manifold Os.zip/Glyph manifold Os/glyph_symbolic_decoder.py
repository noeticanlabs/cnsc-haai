# Mapping symbolic glyphs to physical particle roles
GLYPH_MAP = {
    'e⁻': {'type': 'lepton', 'charge': -1, 'mass': '0.511 MeV', 'glyph': 'ϵ'},
    'μ⁻': {'type': 'lepton', 'charge': -1, 'mass': '105.7 MeV', 'glyph': 'μ'},
    'τ⁻': {'type': 'lepton', 'charge': -1, 'mass': '1776 MeV', 'glyph': 'τ'},
    'u': {'type': 'quark', 'charge': +2/3, 'mass': '2.3 MeV', 'glyph': 'υ'},
    'd': {'type': 'quark', 'charge': -1/3, 'mass': '4.8 MeV', 'glyph': 'δ'},
    'W⁺': {'type': 'boson', 'charge': +1, 'mass': '80.4 GeV', 'glyph': 'ω⁺'},
    'H⁰': {'type': 'boson', 'charge': 0, 'mass': '125.1 GeV', 'glyph': 'η'}
}

def decode_field_to_symbols(theta_field):
    symbolic_map = []
    for value in np.nditer(theta_field):
        if value > 2.0:
            symbolic_map.append('τ⁻')
        elif value > 1.5:
            symbolic_map.append('μ⁻')
        elif value > 1.0:
            symbolic_map.append('e⁻')
        else:
            symbolic_map.append('ϕ')
    return symbolic_map