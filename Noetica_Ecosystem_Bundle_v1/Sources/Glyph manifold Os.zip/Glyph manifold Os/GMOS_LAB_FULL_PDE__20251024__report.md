# Full PDE System — Lab Report — 20251024

**Attachments added**
- E7/E10 bundle: [zip](sandbox:/mnt/data/GMOS_THM_E7_E10__20251024__bundle.zip), [bundle md](sandbox:/mnt/data/GMOS_artifacts/GMOS_THM_E7_E10__20251024__bundle.md)
- Constants (NIST-patched): [json](sandbox:/mnt/data/GMOS_artifacts/GMOS_CONSTANTS__20251024.json)
- A6 provable bound dossier: [md](sandbox:/mnt/data/GMOS_artifacts/GMOS_THEOREM_A6__20251024__A6_PROVABLE_LB.md)
- Coherence basis audit: [md](sandbox:/mnt/data/GMOS_artifacts/GMOS_COH_BASIS_AUDIT__20251024__R022_FINAL.md)

**Spectral summaries (Hz & meV axes) + dimensionless scaling**
_No series metrics found._
